<?php
require dirname(__FILE__) . '/includes/bootstrap.php';
$p = isset($_GET['p']) ? $_GET['p'] : 'home';
$allowed = array(
    'home', 'login', 'register', 'forgot', 'logout',
    'mood', 'dashboard', 'plan', 'today', 'library',
    'periods', 'period', 'reports', 'profile', 'settings', 'about', 'support', 'learn',
    'jooje', // (B5) جوجهٔ من — مرحلهٔ ۱
    'journal', // (B7) دفترچهٔ جوما
    'rights',        // (فاز ۴) حقوق داده
    'admin_console', // (فاز ۴) کنسول مدیر
    'admin_recovery', // (B1-2) صدور کد بازیابی رمز — فقط مدیر
);
// JOMA-HAMMASIR-BEGIN
// اتصال حداقلی ماژول «هم‌مسیر» (Phase 1B — D26/D28/D29؛ fail-closed)
// با Flag خاموش: فقط همین فایل کانفیگ کوچک خوانده می‌شود؛ هیچ query،
// include توابع هم‌مسیر، صفحه یا تغییر رفتاری رخ نمی‌دهد و $allowed همان مقدار قبلی می‌ماند.
// اگر کانفیگ/توابع موجود نباشند یا خطایی رخ دهد، این بلوک کاملاً بی‌اثر می‌ماند (fail-closed؛ PC-4).
// لود توابع هم‌مسیر فقط برای route خود هم‌مسیر انجام می‌شود (نه همه‌ی صفحات).
try {
    $__hammasir_cfg_file = dirname(__FILE__) . '/config/hammasir_config.php';
    if (is_file($__hammasir_cfg_file)) {
        $HAMMASIR_CONFIG = array();
        include $__hammasir_cfg_file;
        if (isset($HAMMASIR_CONFIG['hammasir_enabled']) && $HAMMASIR_CONFIG['hammasir_enabled'] === true) {
            // صفحات ماژول (حکم PO — بخش دو): صفحه‌ی مرکزی + دو صفحه‌ی مستقل مدیریت
            $__hammasir_pages = array('hammasir', 'hammasir_providers', 'hammasir_admins');
            if (in_array($p, $__hammasir_pages, true) && !defined('JOMA_IN_APP')) {
                define('JOMA_IN_APP', true);
            }
            if (in_array($p, $__hammasir_pages, true)) {
                $__hammasir_functions = dirname(__FILE__) . '/functions/hammasir.php';
                if (is_file($__hammasir_functions)) {
                    include_once $__hammasir_functions;
                }
            }
            foreach ($__hammasir_pages as $__hammasir_page) {
                $allowed[] = $__hammasir_page;
            }
            unset($__hammasir_page, $__hammasir_pages);
        }
        unset($HAMMASIR_CONFIG);
    }
    unset($__hammasir_cfg_file);
} catch (Throwable $e) {
    // fail-closed: هیچ خروجی؛ route باز نمی‌شود؛ فقط لاگ امن با پیام ثابت (PC-4)
    error_log('hammasir module kept disabled: safe load of hammasir config/functions failed.');
}
// JOMA-HAMMASIR-END
if (!in_array($p, $allowed, true)) $p = 'home';
maybe_mood_gate($p);
// (C2) در حالت مشاور، صفحه‌های شخصی با آدرس مستقیم هم باز نمی‌شوند.
// یک نقطهٔ گارد در Router — نه سه فایل صفحه. اگر تابع نبود، هیچ رفتاری عوض نمی‌شود.
if (function_exists('joma_role_guard')) joma_role_guard($p);
$file = dirname(__FILE__) . '/pages/' . $p . '.php';
if (!file_exists($file)) $p = 'home';
require dirname(__FILE__) . '/pages/' . $p . '.php';
