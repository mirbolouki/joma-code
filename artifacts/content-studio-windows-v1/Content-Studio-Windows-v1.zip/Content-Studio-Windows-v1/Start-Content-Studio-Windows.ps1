$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

function Stop-WithMessage([string]$Message) {
    Write-Host ""
    Write-Host $Message -ForegroundColor Red
    exit 1
}

# Prefer a registered Python 3.12+ installation via the Windows Python Launcher.
$PythonExe = $null
$PythonLauncher = Get-Command "py" -ErrorAction SilentlyContinue
if ($PythonLauncher) {
    foreach ($Minor in 20..12) {
        $Candidate = & $PythonLauncher.Source "-3.$Minor" -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $Candidate) {
            $PythonExe = $Candidate.Trim()
            break
        }
    }
}

# Fallback to the default `python` on PATH (also accepts Python 3.12+).
if (-not $PythonExe) {
    $PythonCommand = Get-Command "python" -ErrorAction SilentlyContinue
    if ($PythonCommand) {
        $Candidate = & $PythonCommand.Source -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $Candidate) {
            $PythonExe = $Candidate.Trim()
        }
    }
}

if (-not $PythonExe) {
    Stop-WithMessage "Python 3.12 or newer was not found. Install 64-bit Python 3.12+ and try again."
}
$PythonVersion = & $PythonExe -c "import sys; print('%d.%d' % (sys.version_info.major, sys.version_info.minor))"
if ($LASTEXITCODE -ne 0) {
    Stop-WithMessage "Python could not be started. Repair the Python installation and try again."
}
$ParsedPythonVersion = [version]::Parse($PythonVersion.Trim() + ".0")
if ($ParsedPythonVersion -lt [version]"3.12.0") {
    Stop-WithMessage "Python 3.12 or newer is required; the detected version is $($PythonVersion.Trim())."
}
$PythonBits = & $PythonExe -c "import struct; print(struct.calcsize('P') * 8)"
if ($LASTEXITCODE -ne 0 -or $PythonBits.Trim() -ne "64") {
    Stop-WithMessage "Install 64-bit x64 Python 3.12 or newer; 32-bit Python is not supported by this bundle."
}

$NodeCommand = Get-Command "node" -ErrorAction SilentlyContinue
if (-not $NodeCommand) {
    Stop-WithMessage "Node.js 18 or newer was not found. Install 64-bit Node.js 22 LTS, then reopen this launcher."
}
$NodeVersion = & $NodeCommand.Source -p "process.versions.node"
if ($LASTEXITCODE -ne 0 -or -not $NodeVersion) {
    Stop-WithMessage "Node.js could not be started. Repair the Node.js installation and try again."
}
$NodeMajor = [int]($NodeVersion.Trim().Split('.')[0])
if ($NodeMajor -lt 18) {
    Stop-WithMessage "Node.js 18 or newer is required; the detected version is $($NodeVersion.Trim())."
}
$NodeArchitecture = & $NodeCommand.Source -p "process.arch"
if ($LASTEXITCODE -ne 0 -or $NodeArchitecture.Trim() -ne "x64") {
    Stop-WithMessage "Install 64-bit x64 Node.js 18 or newer; other Windows architectures are not validated."
}
$NpmCommand = Get-Command "npm" -ErrorAction SilentlyContinue
if (-not $NpmCommand) {
    Stop-WithMessage "npm was not found. Reinstall Node.js with npm included, then reopen this launcher."
}

$Port = "8000"
if (-not [string]::IsNullOrWhiteSpace($env:STUDIO_TEST_PORT)) {
    $Port = $env:STUDIO_TEST_PORT.Trim()
}
$PortNumber = 0
if (-not [int]::TryParse($Port, [ref]$PortNumber) -or $PortNumber -lt 1 -or $PortNumber -gt 65535) {
    Stop-WithMessage "STUDIO_TEST_PORT must be a number from 1 to 65535."
}
$env:STUDIO_TEST_PORT = $Port

$VenvPath = Join-Path $Root ".venv"
$VenvPython = Join-Path $VenvPath "Scripts\python.exe"
$InstallMarker = Join-Path $VenvPath ".content-studio-windows-v1-installed"
$CanvasPackage = Join-Path $Root "node_modules\@napi-rs\canvas"

if (-not (Test-Path $VenvPython)) {
    Write-Host "Creating the private Python environment..."
    & $PythonExe -m venv $VenvPath
    if ($LASTEXITCODE -ne 0) {
        Stop-WithMessage "Could not create the Python environment. Check that Python's venv component is installed."
    }
}

if (-not (Test-Path $InstallMarker) -or -not (Test-Path $CanvasPackage)) {
    Write-Host "Installing the Python dependencies from pyproject.toml..."
    & $VenvPython -m pip install --disable-pip-version-check --no-input -e "."
    if ($LASTEXITCODE -ne 0) {
        Stop-WithMessage "Python dependency installation failed. Check your internet connection and retry."
    }

    Write-Host "Installing the locked renderer dependency from package-lock.json..."
    & $NpmCommand.Source ci --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) {
        Stop-WithMessage "Renderer installation failed. Check your internet connection and retry."
    }
    Set-Content -Path $InstallMarker -Value "Content Studio Windows local v1" -Encoding ascii
}

$HarnessPath = Join-Path $Root "test-harness"
$env:PYTHONPATH = if ([string]::IsNullOrWhiteSpace($env:PYTHONPATH)) {
    "$HarnessPath;$Root"
} else {
    "$HarnessPath;$Root;$($env:PYTHONPATH)"
}
$env:DJANGO_SETTINGS_MODULE = "content_studio_windows_settings"
$env:DJANGO_DEBUG = "1"
$env:DJANGO_SECRET_KEY = "content-studio-windows-local-test-only-not-for-production"
$env:STUDIO_TEST_MODE = "1"
$env:STUDIO_TEST_PASSWORD = "StudioTestV1!24"

Write-Host "Applying local SQLite migrations..."
& $VenvPython manage.py migrate --noinput
if ($LASTEXITCODE -ne 0) {
    Stop-WithMessage "Database initialization failed. Keep this window open and share the final error lines (never share private data)."
}

Write-Host "Preparing or verifying the synthetic TEST_ONLY demo..."
& $VenvPython test-harness\seed_demo.py
if ($LASTEXITCODE -ne 0) {
    Stop-WithMessage "The local demo could not be prepared. Existing data was not reset; review the error above."
}

Write-Host ""
Write-Host "Django is starting; wait for its 'Starting development server at' line below."
Write-Host "The server will be bound to this PC only. See README-WINDOWS-FA.md for the test login."
Write-Host "Press Ctrl+C in this window to stop the server."
$BindAddress = "127.0.0.1:{0}" -f $Port
& $VenvPython manage.py runserver $BindAddress --noreload --nothreading
