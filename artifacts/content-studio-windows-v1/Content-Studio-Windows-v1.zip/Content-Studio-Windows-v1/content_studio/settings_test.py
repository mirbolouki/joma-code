import os

# Base settings validate secret configuration during import; force an explicit test-only key.
os.environ["DJANGO_DEBUG"] = "1"
os.environ["DJANGO_SECRET_KEY"] = "tests-only-not-a-secret"

from .settings import *  # noqa: F403

DEBUG = True
SECRET_KEY = "tests-only-not-a-secret"
# Fixture upload and simulated TEST_ONLY review routes are enabled only in this isolated test profile.
STUDIO_TEST_MODE = True
DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}}
CELERY_TASK_ALWAYS_EAGER = True
PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]
PRIVATE_MEDIA_ROOT = BASE_DIR / "var" / "test-private-media"  # noqa: F405
STORAGES = {
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {"BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage"},
}
# Django's view tests do not need static middleware; its production behavior is tested separately.
MIDDLEWARE = [item for item in MIDDLEWARE if item != "whitenoise.middleware.WhiteNoiseMiddleware"]  # noqa: F405
