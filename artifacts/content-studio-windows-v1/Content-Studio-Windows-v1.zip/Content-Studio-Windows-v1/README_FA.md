# استودیوی مستقل محتوای فارسی

> **برای اجرای این بسته روی Windows:** راهنمای اصلی `README-WINDOWS-FA.md` و فایل `Start-Content-Studio-Windows.bat` را دنبال کنید. بخش Compose پایین راهنمای توسعهٔ چندسرویسی است و برای شروع محلی این بسته لازم نیست.

این دایرکتوری اپلیکیشن مستقل Content Studio است؛ هیچ کدی، دیتایی یا dependencyای از Joma/Clinic در آن مصرف نمی‌شود. ZIPهای قدیمی و dumpهای SQL ورودی build نیستند. این محصول هنوز **داخلی و در حال پیاده‌سازی** است؛ M0/M1 تحویل MVP نیستند.

## دامنهٔ محصول نهایی

MVP قابل‌استفاده باید یک Carousel ایستا را واقعاً از Idea تا فایل نهایی و ZIP پیش ببرد. providerهای LLM/Search/Image هنوز غیرفعال‌اند؛ تصویر پایه می‌تواند فقط از مسیر upload کاربر و با تأیید حقوق استفاده، به‌صورت `user_input` ثبت شود و هرگز خروجی AI نامیده نمی‌شود. وجود فایل نهایی یا ZIP fixture به‌تنهایی اثبات محصول نیست؛ تکمیل فقط پس از اجرای یک پروژهٔ واقعی، بازبینی انسانی، سه QA مستقل و ZIP همان پروژه قابل‌ادعاست.

## Baseline مصوب

- Python 3.12+
- Django 5.2 LTS
- PostgreSQL 18
- Celery + Redis برای jobهای async
- Docker Compose برای محیط چندسرویسی
- Renderer فعلی: `@napi-rs/canvas` با Skia/HarfBuzz و Noto Sans Arabic (OFL-1.1). یک PNG محلی با فارسی/RTL، نیم‌فاصله، لاتین/URL، اعداد، wrapping و safe-area تولید و بصری بررسی شده؛ target کانتینری هنوز build نشده و verified production نیست.

## اجرای محلی با Compose

1. نصب Docker Engine و Docker Compose v2 روی محیط توسعه.
2. `cp .env.example .env` و تعیین `DJANGO_SECRET_KEY` و رمز محلی PostgreSQL.
3. `docker compose up --build`.
4. ساخت کاربر مدیریتی: `docker compose exec web python manage.py createsuperuser`.
5. ساخت Brand Profile از `/admin/`؛ هیچ brand یا دادهٔ نمونه به‌صورت خودکار seed نمی‌شود.
6. ورود به `/login/` و ایجاد پروژه.

فایل‌های کاربر در private volume قرار می‌گیرند و از مسیر عمومی static/media سرو نمی‌شوند. قبل از هر محیط واقعی باید secret، backup/restore، allowed hosts، TLS، retention و حساب دسترسی بازبینی شوند. این Compose برای توسعه است، نه production-ready hosting.

## Providerها

این MVP در حالت local/manual قفل است: ساخت پروژه و «بازآوری وضعیت» provider را نمی‌خوانند و هیچ API، Celery queue یا سرویس بیرونی را فراخوانی نمی‌کنند؛ upload تصویر فقط `user_input` است. متغیرهای `STUDIO_LLM_PROVIDER`، `STUDIO_SEARCH_PROVIDER` و `STUDIO_IMAGE_PROVIDER` در UI دستی فعال‌کننده نیستند. برای هر API آینده باید پیش از هر فعال‌سازی، قیمت، کیفیت، محدودیت‌ها، مجوز استفاده، data retention و شرایط privacy جداگانه بررسی و تأیید صریح گرفته شود. هیچ کلید API در repository نگهداری نمی‌شود.

## Claim/Source/Slide provenance

Claim، منبع و پیوند به اسلاید رکوردهای جدا هستند. شاهد Claim باید عیناً در متن منبع ثبت‌شده و بخش Claim باید عیناً در متن اسلاید وجود داشته باشد؛ هر دو پیوند توسط انسان بازبینی می‌شوند. snapshotهای hash جداگانه تغییر Claim، URL/متن منبع، شاهد یا متن اسلاید/پیوند را می‌گیرند و بازبینی متناظر را باطل می‌کنند. Claim factual منبع می‌خواهد؛ محتوای opinion/creative/general-advice فقط با دلیل ثبت‌شدهٔ منبع‌نخواستن و وضعیت بازبینی مستقل عبور می‌کند. ثبت دستی متن اسلاید فقط `user_input` است، نه تولید محتوا. این نگاشت خودکار تشخیص نمی‌دهد که تمام ادعاهای یک متن پوشش داده شده‌اند؛ آن بررسی همچنان نیازمند بازبینی انسانی است.

## تست

- Python هدف پروژه `>=3.12` است. در محیط توسعه، از ریشهٔ همین دایرکتوری اجرا کنید: `python -m pip install -e '.[test]'` سپس `pytest`.
- آزمون‌ها از `content_studio.settings_test` و SQLite استفاده می‌کنند؛ این جایگزین migration/test روی PostgreSQL 18 نیست. تست‌ها pytest-function هستند، بنابراین `manage.py test` آن‌ها را کشف نمی‌کند.
- آخرین suite محلی: ۴۶ تست پاس، ۱ تست جایگزین Pillow/RAQM به‌علت نبود RAQM skip شد؛ Python 3.11.2 زیر نسخهٔ target است. `manage.py check` و `makemigrations --check --dry-run` در settings تست پاس شده‌اند؛ این‌ها جای Docker/PostgreSQL 18 و اجرای روی Python 3.12 را نمی‌گیرند. جریان QA/ZIP در تست از تصاویر synthetic fixture استفاده می‌کند و E2E محصول واقعی محسوب نمی‌شود.
- Dockerfile شامل Node/Skia و ساخت Pillow با RAQM است و در صورت نبود وابستگی‌ها build را fail می‌کند. Docker build هنوز در sandbox اجرا نشده است.
- آزمون نهایی MVP باید با پروژهٔ واقعی، تصویرهای واقعیِ دارای حق استفاده (با منشأ `user_input` یا provider جداگانه‌تأییدشده)، golden tests فارسی، بازبینی انسانی و ZIP قابل‌بازکردن از همان پروژه اجرا شود. تا target کانتینری و این E2E کامل نشوند، capability production `verified` نیست.
