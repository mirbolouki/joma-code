@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Content-Studio-Windows.ps1"
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
  echo.
  echo Content Studio stopped with exit code %EXITCODE%.
)
echo.
echo To stop a running server, press Ctrl+C in this window.
pause
exit /b %EXITCODE%
