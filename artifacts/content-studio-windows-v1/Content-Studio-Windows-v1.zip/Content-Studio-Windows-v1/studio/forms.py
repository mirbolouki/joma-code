from django import forms
from django.core.validators import URLValidator

from .enums import AssetRightsBasis, FormatChoice, PipelineStage, QualityAxis, QualityStatus, ResearchLevel
from .models import (
    BrandProfile,
    CarouselSlide,
    ClaimSlideLink,
    ClaimSourceLink,
    ContentClaim,
    Project,
    ResearchDecision,
    ResearchSource,
)
from .services.uploads import InvalidImageUpload, normalize_uploaded_image


class ProjectCreateForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ("brand", "idea", "requested_format")
        widgets = {
            "idea": forms.Textarea(attrs={"rows": 5, "maxlength": 8000, "placeholder": "موضوع یا ایدهٔ اولیه را بنویسید…"}),
        }
        labels = {"brand": "Brand Profile", "idea": "ایده", "requested_format": "فرمت درخواستی"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["brand"].queryset = BrandProfile.objects.filter(is_active=True)
        self.fields["brand"].empty_label = "یک Brand Profile انتخاب کنید"
        self.fields["requested_format"].initial = FormatChoice.AUTO

    def clean_idea(self):
        value = self.cleaned_data["idea"].strip()
        if not value:
            raise forms.ValidationError("ایده نمی‌تواند خالی باشد.")
        return value


class ResearchDecisionForm(forms.ModelForm):
    class Meta:
        model = ResearchDecision
        fields = ("level", "rationale")
        widgets = {"rationale": forms.Textarea(attrs={"rows": 3, "maxlength": 4000})}
        labels = {"level": "سطح پژوهش", "rationale": "دلیل تصمیم"}

    def clean_rationale(self):
        value = self.cleaned_data["rationale"].strip()
        if not value:
            raise forms.ValidationError("دلیل Research Decision را ثبت کنید.")
        return value


class ResearchSourceForm(forms.ModelForm):
    url = forms.URLField(
        label="URL واقعی منبع",
        assume_scheme="https",
        widget=forms.URLInput(attrs={"dir": "ltr"}),
    )

    class Meta:
        model = ResearchSource
        fields = ("url", "title", "publisher", "author", "published_at", "excerpt")
        widgets = {
            "published_at": forms.DateInput(attrs={"type": "date"}),
            "excerpt": forms.Textarea(attrs={"rows": 4, "maxlength": 6000}),
        }
        labels = {
            "url": "URL واقعی منبع",
            "title": "عنوان",
            "publisher": "ناشر",
            "author": "نویسنده",
            "published_at": "تاریخ انتشار",
            "excerpt": "متن منبعِ قابل‌ردیابی برای سنجش شاهد (نقل‌قول/بخش دقیق)",
        }


class ContentClaimForm(forms.ModelForm):
    class Meta:
        model = ContentClaim
        fields = (
            "key",
            "text",
            "claim_type",
            "requires_source",
            "source_requirement_reason",
            "rationale",
        )
        widgets = {
            "text": forms.Textarea(attrs={"rows": 3, "maxlength": 4000}),
            "source_requirement_reason": forms.Textarea(attrs={"rows": 2, "maxlength": 2000}),
            "rationale": forms.Textarea(attrs={"rows": 2, "maxlength": 2000}),
        }
        labels = {
            "key": "شناسهٔ کوتاه claim",
            "text": "متن claim",
            "claim_type": "نوع claim",
            "requires_source": "برای تحویل منبع لازم دارد",
            "source_requirement_reason": "اگر منبع لازم نیست، دلیلِ غیرfactual بودن را بنویسید",
            "rationale": "یادداشت/قید claim",
        }


class ClaimSourceLinkForm(forms.ModelForm):
    class Meta:
        model = ClaimSourceLink
        fields = ("claim", "source", "relation", "evidence_excerpt")
        widgets = {"evidence_excerpt": forms.Textarea(attrs={"rows": 3, "maxlength": 6000})}
        labels = {
            "claim": "Claim",
            "source": "منبع همین پروژه",
            "relation": "نسبت منبع با claim",
            "evidence_excerpt": "بخش دقیق/شاهد قابل‌ردیابی",
        }

    def __init__(self, *args, project: Project, **kwargs):
        super().__init__(*args, **kwargs)
        self.project = project
        self.fields["claim"].queryset = project.claims.all()
        self.fields["source"].queryset = project.research_sources.all()
        self.fields["claim"].empty_label = "یک claim انتخاب کنید"
        self.fields["source"].empty_label = "یک منبع انتخاب کنید"

    def clean(self):
        cleaned_data = super().clean()
        claim = cleaned_data.get("claim")
        source = cleaned_data.get("source")
        if claim and claim.project_id != self.project.pk:
            self.add_error("claim", "Claim باید به همین پروژه تعلق داشته باشد.")
        if source and source.project_id != self.project.pk:
            self.add_error("source", "منبع باید به همین پروژه تعلق داشته باشد.")
        if claim and source and claim.project_id != source.project_id:
            self.add_error("source", "Claim و منبع باید متعلق به یک پروژه باشند.")
        return cleaned_data


class CarouselSlideForm(forms.ModelForm):
    class Meta:
        model = CarouselSlide
        fields = ("role", "copy_text")
        widgets = {"copy_text": forms.Textarea(attrs={"rows": 4, "maxlength": 4000})}
        labels = {"role": "نقش اسلاید", "copy_text": "متن فارسی اسلاید"}

    def clean_copy_text(self):
        value = self.cleaned_data["copy_text"].strip()
        if not value:
            raise forms.ValidationError("متن اسلاید نمی‌تواند خالی باشد.")
        return value


class ManualStageInputForm(forms.Form):
    stage = forms.ChoiceField(
        label="مرحلهٔ تحریریهٔ دستی",
        choices=(
            (PipelineStage.OPPORTUNITY_ANALYSIS, "تحلیل فرصت محتوا"),
            (PipelineStage.STRATEGY, "استراتژی"),
            (PipelineStage.HOOK, "Hook"),
            (PipelineStage.CONTENT_STRUCTURE, "ساختار محتوا"),
        ),
    )
    content = forms.CharField(
        label="یادداشت این مرحله (بدون دادهٔ شخصی)",
        max_length=6000,
        widget=forms.Textarea(attrs={"rows": 4, "maxlength": 6000}),
    )

    def clean_content(self):
        value = self.cleaned_data["content"].strip()
        if not value:
            raise forms.ValidationError("یادداشت مرحله نمی‌تواند خالی باشد.")
        return value


class LocalTestFixtureUploadForm(forms.Form):
    image = forms.FileField(
        label="تصویر محلی آزمایشی (TEST_ONLY؛ بدون نوشته)",
        widget=forms.FileInput(attrs={"accept": "image/png,image/jpeg"}),
    )

    def clean_image(self):
        try:
            return normalize_uploaded_image(self.cleaned_data["image"])
        except InvalidImageUpload as exc:
            raise forms.ValidationError(str(exc)) from exc


class ClaimSlideLinkForm(forms.ModelForm):
    class Meta:
        model = ClaimSlideLink
        fields = ("claim", "slide", "copy_excerpt")
        widgets = {"copy_excerpt": forms.Textarea(attrs={"rows": 3, "maxlength": 2000})}
        labels = {
            "claim": "Claim ثبت‌شده",
            "slide": "اسلاید همین پروژه",
            "copy_excerpt": "بخش دقیق متن اسلاید که این Claim را بیان می‌کند",
        }

    def __init__(self, *args, project: Project, **kwargs):
        super().__init__(*args, **kwargs)
        self.project = project
        self.fields["claim"].queryset = project.claims.all()
        self.fields["slide"].queryset = project.slides.all()
        self.fields["claim"].empty_label = "یک claim انتخاب کنید"
        self.fields["slide"].empty_label = "یک اسلاید انتخاب کنید"

    def clean(self):
        cleaned_data = super().clean()
        claim = cleaned_data.get("claim")
        slide = cleaned_data.get("slide")
        if claim and claim.project_id != self.project.pk:
            self.add_error("claim", "Claim باید به همین پروژه تعلق داشته باشد.")
        if slide and slide.project_id != self.project.pk:
            self.add_error("slide", "اسلاید باید به همین پروژه تعلق داشته باشد.")
        return cleaned_data


class SlideImageUploadForm(forms.Form):
    image = forms.FileField(
        label="تصویر پایهٔ PNG/JPEG ثابت (حداکثر ۱۲ مگابایت)",
        widget=forms.FileInput(attrs={"accept": "image/png,image/jpeg"}),
    )
    rights_basis = forms.ChoiceField(
        label="مبنای حق استفاده",
        choices=AssetRightsBasis.choices,
    )
    rights_note = forms.CharField(
        label="توضیح مجوز/مالکیت",
        max_length=500,
        widget=forms.TextInput(attrs={"maxlength": 500}),
    )
    rights_source_url = forms.URLField(
        label="URL مجوز یا منبع (اختیاری)",
        required=False,
        assume_scheme="https",
        widget=forms.URLInput(attrs={"dir": "ltr"}),
    )
    rights_confirmed = forms.BooleanField(
        label="تأیید می‌کنم حق بارگذاری و استفاده از این تصویر را دارم.",
        required=True,
    )

    def clean_image(self):
        try:
            return normalize_uploaded_image(self.cleaned_data["image"])
        except InvalidImageUpload as exc:
            raise forms.ValidationError(str(exc)) from exc

    def clean_rights_note(self):
        value = self.cleaned_data["rights_note"].strip()
        if len(value) < 4:
            raise forms.ValidationError("مبنای حق استفاده را دست‌کم با چهار نویسه توضیح دهید.")
        return value


class QualityReviewForm(forms.Form):
    status = forms.ChoiceField(
        label="نتیجهٔ بازبینی انسانی",
        choices=((QualityStatus.PASS, "قبول"), (QualityStatus.FAIL, "رد")),
    )
    policy_pack_id = forms.CharField(
        label="شناسهٔ معیار/نسخهٔ قواعد",
        max_length=120,
        required=False,
    )
    policy_pack_version = forms.CharField(
        label="نسخهٔ معیار",
        max_length=64,
        required=False,
    )
    source_urls = forms.CharField(
        label="URL معیارهای رسمی (هر URL در یک خط)",
        required=False,
        widget=forms.Textarea(attrs={"rows": 2, "dir": "ltr"}),
    )
    findings = forms.CharField(
        label="معیارهایی که واقعاً بررسی و نتیجهٔ هرکدام (هر مورد در یک خط)",
        widget=forms.Textarea(attrs={"rows": 3}),
    )
    blockers = forms.CharField(
        label="Blockerهای باز (هر مورد در یک خط; برای PASS خالی بگذارید)",
        required=False,
        widget=forms.Textarea(attrs={"rows": 2}),
    )

    def __init__(self, *args, axis: str, test_only: bool = False, **kwargs):
        if axis not in QualityAxis.values:
            raise ValueError("Unknown quality axis.")
        self.axis = axis
        self.test_only = test_only
        super().__init__(*args, **kwargs)

    def clean_policy_pack_id(self):
        return self.cleaned_data["policy_pack_id"].strip()

    def clean_policy_pack_version(self):
        return self.cleaned_data["policy_pack_version"].strip()

    def clean_source_urls(self):
        validator = URLValidator(schemes=["http", "https"])
        urls = [line.strip() for line in self.cleaned_data["source_urls"].splitlines() if line.strip()]
        for url in urls:
            try:
                validator(url)
            except forms.ValidationError as exc:
                raise forms.ValidationError(f"URL نامعتبر است: {url}") from exc
        return urls

    def clean_findings(self):
        findings = [line.strip() for line in self.cleaned_data["findings"].splitlines() if line.strip()]
        if not findings:
            raise forms.ValidationError("دست‌کم یک مورد بررسی‌شده را ثبت کنید.")
        return findings

    def clean_blockers(self):
        return [line.strip() for line in self.cleaned_data["blockers"].splitlines() if line.strip()]

    def clean(self):
        cleaned_data = super().clean()
        status = cleaned_data.get("status")
        blockers = cleaned_data.get("blockers") or []
        if status == QualityStatus.PASS and blockers:
            self.add_error("blockers", "برای PASS نباید blocker باز ثبت شده باشد.")
        if status == QualityStatus.FAIL and not blockers:
            self.add_error("blockers", "برای FAIL دست‌کم یک blocker ثبت کنید.")
        if self.axis in {QualityAxis.PLATFORM_COMPLIANCE, QualityAxis.PLATFORM_BEST_PRACTICES}:
            if not cleaned_data.get("policy_pack_id"):
                self.add_error("policy_pack_id", "شناسهٔ قواعد برای این محور لازم است.")
            if not cleaned_data.get("policy_pack_version"):
                self.add_error("policy_pack_version", "نسخهٔ قواعد برای این محور لازم است.")
        if (
            self.axis == QualityAxis.PLATFORM_COMPLIANCE
            and not self.test_only
            and not (cleaned_data.get("source_urls") or [])
        ):
            self.add_error("source_urls", "برای Platform Compliance دست‌کم یک URL رسمی لازم است.")
        return cleaned_data
