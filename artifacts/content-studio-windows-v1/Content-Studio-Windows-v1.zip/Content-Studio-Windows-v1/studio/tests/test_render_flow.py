import hashlib
import io

import pytest
from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse
from PIL import Image

from studio.enums import (
    ArtifactProvenance,
    AssetKind,
    CapabilityStatus,
    PipelineStage,
    RunStatus,
)
from studio.exporter import _delivery_blockers
from studio.models import ProjectArtifact, StageRun
from studio.storage import PrivateLocalStore
from studio.tests.factories import create_project, create_user


def _base_png() -> bytes:
    image = Image.new("RGB", (1200, 1600), (68, 88, 104))
    output = io.BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()


@pytest.mark.django_db
def test_ui_local_fixture_render_and_preview_use_same_private_file(tmp_path, client, settings, monkeypatch):
    settings.STUDIO_TEST_MODE = True
    project = create_project()
    reviewer = create_user("render-ui-user")
    project.created_by = reviewer
    project.save(update_fields=["created_by", "updated_at"])
    slide = project.slides.create(
        position=1,
        role="renderer test fixture",
        copy_text="اتصال حروف و نیم‌فاصله: می‌توانیم. English API v2.0، اعداد ۱۲۳ و 42.",
    )
    store = PrivateLocalStore(tmp_path / "private")
    monkeypatch.setattr("studio.services.uploads.PrivateLocalStore", lambda: store)
    monkeypatch.setattr("studio.services.rendering.PrivateLocalStore", lambda: store)
    monkeypatch.setattr("studio.views.PrivateLocalStore", lambda: store)
    client.force_login(reviewer)

    prefix = f"fixture-{slide.pk}"
    upload_response = client.post(
        reverse("studio:upload_slide_base_image", kwargs={"project_id": project.pk, "slide_id": slide.pk}),
        {
            f"{prefix}-image": SimpleUploadedFile("local-test-fixture.png", _base_png(), content_type="image/png"),
        },
        HTTP_X_STUDIO_TEST_FIXTURE="1",
    )
    assert upload_response.status_code == 302
    base = project.assets.get(slide=slide, kind=AssetKind.IMAGE_PLAIN)
    assert base.provenance == ArtifactProvenance.TEST_FIXTURE
    assert base.provider_id == base.model_name == ""
    assert base.rights_confirmed_by is None
    assert base.rights_confirmed_at is None

    render_response = client.post(
        reverse("studio:render_slide_asset", kwargs={"project_id": project.pk, "slide_id": slide.pk})
    )
    assert render_response.status_code == 302
    final = project.assets.get(slide=slide, kind=AssetKind.IMAGE_FINAL)
    preview = project.assets.get(slide=slide, kind=AssetKind.PREVIEW)
    final_bytes = store.read(final.storage_key)
    preview_bytes = store.read(preview.storage_key)

    assert final.provenance == ArtifactProvenance.SYSTEM_GENERATED
    assert final.mime_type == "image/png"
    assert final.width == 1080 and final.height == 1350
    assert final.sha256 == hashlib.sha256(final_bytes).hexdigest()
    assert preview.sha256 == final.sha256
    assert preview_bytes == final_bytes
    assert len(final.render_input_hash) == 64
    assert StageRun.objects.filter(
        project=project,
        stage=PipelineStage.IMAGE_GENERATION,
        status=RunStatus.COMPLETED,
    ).exists()
    assert StageRun.objects.filter(
        project=project,
        stage=PipelineStage.PERSIAN_OVERLAY,
        status=RunStatus.COMPLETED,
        capability_status=CapabilityStatus.NOT_VERIFIED,
    ).exists()
    rendered_artifact = ProjectArtifact.objects.get(project=project, artifact_type="rendered_slide")
    assert rendered_artifact.payload["base_provenance"] == ArtifactProvenance.TEST_FIXTURE
    assert rendered_artifact.payload["final_sha256"] == final.sha256

    detail = client.get(reverse("studio:project_detail", kwargs={"project_id": project.pk}))
    assert detail.status_code == 200
    assert reverse(
        "studio:preview_final_asset",
        kwargs={"project_id": project.pk, "asset_id": final.pk},
    ).encode() in detail.content
    assert "TEST_FIXTURE محلی؛ برای محصول یا انتشار نیست" in detail.content.decode()

    preview_response = client.get(
        reverse("studio:preview_final_asset", kwargs={"project_id": project.pk, "asset_id": final.pk})
    )
    assert preview_response.status_code == 200
    assert preview_response["Content-Type"] == "image/png"
    assert b"".join(preview_response.streaming_content) == final_bytes

    slide.copy_text = "متن تغییر کرد؛ تصویر قبلی نباید آمادهٔ تحویل بماند."
    slide.save(update_fields=["copy_text", "updated_at"])
    blockers = _delivery_blockers(project, store)
    assert any("با تصویر پایه/متن فعلی منطبق نیست" in blocker for blocker in blockers)
