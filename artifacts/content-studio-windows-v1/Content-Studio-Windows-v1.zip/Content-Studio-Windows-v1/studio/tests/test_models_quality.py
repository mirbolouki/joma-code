import pytest
from django.db import IntegrityError, transaction

from studio.enums import CapabilityStatus, PipelineStage, QualityAxis, QualityStatus
from studio.models import CarouselSlide, Project, QualityReport
from studio.quality import ensure_initial_quality_reports, final_delivery_blockers
from studio.tests.factories import create_brand, create_project


@pytest.mark.django_db
def test_projects_are_scoped_to_distinct_brand_profiles():
    first_brand = create_brand(slug="brand-one", name="Brand One")
    second_brand = create_brand(slug="brand-two", name="Brand Two")
    first = create_project(brand=first_brand)
    second = create_project(brand=second_brand)

    assert first.brand_id != second.brand_id
    assert first_brand.projects.get() == first
    assert second_brand.projects.get() == second


@pytest.mark.django_db
def test_carousel_slide_position_is_unique_per_project():
    project = create_project()
    CarouselSlide.objects.create(project=project, position=1)
    with pytest.raises(IntegrityError), transaction.atomic():
        CarouselSlide.objects.create(project=project, position=1)


@pytest.mark.django_db
def test_initial_quality_reports_are_three_independent_not_run_records():
    project = create_project()

    reports = ensure_initial_quality_reports(project)

    assert {report.axis for report in reports} == set(QualityAxis.values)
    assert {report.status for report in reports} == {QualityStatus.NOT_RUN}
    assert all(report.blockers for report in reports)
    assert len(final_delivery_blockers(project)) == 3


@pytest.mark.django_db
def test_manual_review_status_does_not_count_as_quality_pass():
    project = create_project()
    ensure_initial_quality_reports(project)
    report = project.quality_reports.get(axis=QualityAxis.CREATIVE_QUALITY)
    report.status = QualityStatus.MANUAL_REVIEW
    report.save(update_fields=["status", "updated_at"])

    assert any("PASS انسانی" in item for item in final_delivery_blockers(project))


@pytest.mark.django_db
def test_capability_status_vocabulary_is_explicit_and_closed():
    assert set(CapabilityStatus.values) == {
        "verified",
        "available",
        "requires_provider",
        "requires_dependency",
        "not_verified",
        "not_available",
    }
    assert PipelineStage.IDEA in PipelineStage.values
