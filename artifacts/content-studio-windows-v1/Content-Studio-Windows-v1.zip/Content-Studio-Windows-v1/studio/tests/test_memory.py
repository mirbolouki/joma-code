import pytest
from django.utils import timezone

from studio.enums import ArtifactProvenance, MemoryKind, MemoryStatus
from studio.models import BrandMemoryEntry
from studio.services.memory import find_exact_brand_memory_match, normalize_memory_text
from studio.tests.factories import create_brand, create_user


@pytest.mark.django_db
def test_exact_memory_lookup_normalizes_persian_and_stays_within_brand():
    brand = create_brand(slug="memory-brand", name="Memory Brand")
    other_brand = create_brand(slug="other-memory-brand", name="Other Memory Brand")
    reviewer = create_user("memory-reviewer")
    stored_text = "يک   نکته‌یادآوری"
    normalized = normalize_memory_text(stored_text)
    approved = BrandMemoryEntry.objects.create(
        brand=brand,
        kind=MemoryKind.HOOK,
        text=stored_text,
        normalized_text=normalized,
        status=MemoryStatus.APPROVED,
        provenance=ArtifactProvenance.USER_INPUT,
        reviewed_by=reviewer,
        reviewed_at=timezone.now(),
    )
    BrandMemoryEntry.objects.create(
        brand=brand,
        kind=MemoryKind.HOOK,
        text="یادداشت تأییدنشده",
        normalized_text=normalize_memory_text("یادداشت تأییدنشده"),
        status=MemoryStatus.DRAFT,
        provenance=ArtifactProvenance.USER_INPUT,
    )
    BrandMemoryEntry.objects.create(
        brand=other_brand,
        kind=MemoryKind.HOOK,
        text="یادداشت برند دیگر",
        normalized_text=normalized,
        status=MemoryStatus.PUBLISHED,
        provenance=ArtifactProvenance.MANUAL_REVIEW,
        reviewed_by=reviewer,
        reviewed_at=timezone.now(),
    )

    matches = find_exact_brand_memory_match(brand.pk, "یک نکته‌یادآوری", kind=MemoryKind.HOOK)

    assert list(matches) == [approved]
    assert "\u200c" in normalized
