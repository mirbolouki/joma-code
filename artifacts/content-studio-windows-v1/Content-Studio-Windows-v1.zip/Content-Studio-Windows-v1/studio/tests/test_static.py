import pytest
from django.conf import settings
from django.contrib.staticfiles.storage import staticfiles_storage
from django.core.management import call_command
from django.test import Client, override_settings


@pytest.mark.django_db
def test_collected_css_is_served_by_whitenoise(tmp_path):
    production_storages = {
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {"BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage"},
    }
    production_middleware = list(settings.MIDDLEWARE)
    production_middleware.insert(1, "whitenoise.middleware.WhiteNoiseMiddleware")

    with override_settings(
        STATIC_ROOT=tmp_path / "staticfiles",
        STORAGES=production_storages,
        MIDDLEWARE=production_middleware,
    ):
        call_command("collectstatic", interactive=False, clear=True, verbosity=0)
        css_url = staticfiles_storage.url("studio/app.css")
        response = Client().get(css_url)

    assert response.status_code == 200
    assert b"--ink" in b"".join(response.streaming_content)
