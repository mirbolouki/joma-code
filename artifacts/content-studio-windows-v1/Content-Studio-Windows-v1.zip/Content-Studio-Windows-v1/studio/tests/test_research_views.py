import pytest
from django.urls import reverse

from studio.enums import (
    ArtifactProvenance,
    ClaimSourceRelation,
    ClaimStatus,
    ResearchSourceStatus,
)
from studio.models import ClaimSlideLink, ClaimSourceLink, ContentClaim, ProjectArtifact, ResearchSource
from studio.tests.factories import create_project, create_user


@pytest.mark.django_db
def test_manual_research_source_is_unreviewed_until_explicit_review(client):
    user = create_user()
    project = create_project()
    project.created_by = user
    project.save(update_fields=["created_by", "updated_at"])
    client.force_login(user)

    response = client.post(
        reverse("studio:add_research_source", kwargs={"project_id": project.pk}),
        {
            "url": "https://example.org/real-source",
            "title": "Real source submitted by reviewer",
            "publisher": "Example Publisher",
        },
    )

    source = ResearchSource.objects.get(project=project)
    assert response.status_code == 302
    assert source.review_status == ResearchSourceStatus.UNREVIEWED
    assert source.accessed_at is not None
    assert source.reviewed_by_id is None


@pytest.mark.django_db
def test_claim_source_and_slide_provenance_are_separate_unreviewed_records(client):
    user = create_user()
    project = create_project()
    project.created_by = user
    project.save(update_fields=["created_by", "updated_at"])
    client.force_login(user)
    source = ResearchSource.objects.create(
        project=project,
        url="https://example.org/evidence",
        title="Evidence source",
        excerpt="متن دقیق پشتیبان از منبع.",
        review_status=ResearchSourceStatus.UNREVIEWED,
    )

    claim_response = client.post(
        reverse("studio:add_content_claim", kwargs={"project_id": project.pk}),
        {
            "key": "sleep-and-focus",
            "text": "خواب کافی می‌تواند به تمرکز روزانه کمک کند.",
            "claim_type": "scientific",
            "requires_source": "on",
            "rationale": "",
        },
    )
    claim = ContentClaim.objects.get(project=project)
    source_link_response = client.post(
        reverse("studio:link_claim_source", kwargs={"project_id": project.pk}),
        {
            "claim": str(claim.pk),
            "source": str(source.pk),
            "relation": ClaimSourceRelation.SUPPORTS,
            "evidence_excerpt": "متن دقیق پشتیبان از منبع.",
        },
    )
    slide_response = client.post(
        reverse("studio:add_carousel_slide", kwargs={"project_id": project.pk}),
        {"role": "body", "copy_text": "خواب کافی می‌تواند به تمرکز روزانه کمک کند."},
    )
    slide = project.slides.get(position=1)
    slide_link_response = client.post(
        reverse("studio:link_claim_to_slide", kwargs={"project_id": project.pk}),
        {
            "claim": str(claim.pk),
            "slide": str(slide.pk),
            "copy_excerpt": "خواب کافی می‌تواند به تمرکز روزانه کمک کند.",
        },
    )

    claim.refresh_from_db()
    source_link = ClaimSourceLink.objects.get(claim=claim, source=source)
    slide_link = ClaimSlideLink.objects.get(claim=claim, slide=slide)
    artifacts = ProjectArtifact.objects.filter(project=project)

    assert all(
        response.status_code == 302
        for response in (claim_response, source_link_response, slide_response, slide_link_response)
    )
    assert claim.status == ClaimStatus.DRAFT
    assert claim.reviewed_by_id is None
    assert source_link.reviewed_by_id is None
    assert slide_link.reviewed_by_id is None
    assert artifacts.get(artifact_type="content_claim").provenance == ArtifactProvenance.USER_INPUT
    assert artifacts.get(artifact_type="claim_source_link").source_urls == [source.url]
    assert artifacts.get(artifact_type="carousel_slide_copy").payload["copy_text"] == slide.copy_text
    slide_link_artifact = artifacts.get(artifact_type="claim_slide_link")
    assert slide_link_artifact.provenance == ArtifactProvenance.USER_INPUT
    assert slide_link_artifact.payload["claim_key"] == claim.key
    assert slide_link_artifact.payload["slide_position"] == slide.position
    assert slide_link_artifact.payload["copy_excerpt"] == slide_link.copy_excerpt

    detail = client.get(reverse("studio:project_detail", kwargs={"project_id": project.pk}))
    assert detail.status_code == 200
    assert "Claim → Source → Slide provenance" in detail.content.decode()
    assert "بازبینی‌نشده" in detail.content.decode()
