import io

import pytest
from PIL import Image, ImageDraw

from studio.rendering.pillow_raqm import RenderSpec
from studio.rendering.skia_canvas import SkiaCanvasRenderer, TextOverflowError


PERSIAN_RENDER_TEXT = (
    "اتصال حروف: سلام؛ نیم‌فاصله: می‌توانیم، خانه‌ها.\n"
    "متن ترکیبی: English / API v2.0 / example.org/fa?step=1\n"
    "عددها ۱۲۳۴۵ و 67890؛ پرانتز (آزمایش) و شکست خطوط باید امن بمانند."
)


def _source_image() -> bytes:
    image = Image.new("RGB", (1200, 1600), (30, 54, 77))
    draw = ImageDraw.Draw(image)
    for x in range(0, 1200, 120):
        draw.rounded_rectangle((x, 0, x + 70, 1600), radius=30, fill=(42, 88, 104))
    draw.ellipse((690, 250, 1240, 800), fill=(148, 108, 69))
    output = io.BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()


def test_skia_renderer_shapes_persian_and_measures_safe_layout():
    renderer = SkiaCanvasRenderer()
    readiness = renderer.check_ready()
    rendered, metrics = renderer.render_overlay_with_metrics(
        _source_image(),
        PERSIAN_RENDER_TEXT,
        RenderSpec(font_size=48, top=140, max_text_height=760, line_spacing=16),
    )

    with Image.open(io.BytesIO(rendered)) as image:
        assert image.format == "PNG"
        assert image.size == (1080, 1350)
        image.verify()
    assert readiness["ready"] is True
    assert readiness["renderer"] == "@napi-rs/canvas (Skia/HarfBuzz)"
    assert metrics["engine"] == "@napi-rs/canvas (Skia/HarfBuzz)"
    assert metrics["line_count"] >= 5
    line_text = "\n".join(line["text"] for line in metrics["lines"])
    assert "سلام" in line_text
    assert "می\u200cتوانیم" in line_text
    assert "English" in line_text and "API v2.0" in line_text
    assert "example.org/fa?step=1" in line_text
    assert "۱۲۳۴۵" in line_text and "67890" in line_text
    assert "آزمایش" in line_text

    safe = metrics["safe_area"]
    panel = metrics["panel"]
    assert panel["left"] >= safe["left"]
    assert panel["right"] <= safe["right"]
    assert panel["top"] >= safe["top"]
    assert panel["bottom"] <= safe["bottom"]
    assert all(
        line["x"] >= safe["left"]
        and line["right"] <= safe["right"]
        and line["y"] >= safe["top"]
        and line["bottom"] <= safe["bottom"]
        for line in metrics["lines"]
    )

    with pytest.raises(TextOverflowError):
        renderer.render_overlay(
            _source_image(),
            PERSIAN_RENDER_TEXT,
            RenderSpec(font_size=48, max_text_height=1),
        )
