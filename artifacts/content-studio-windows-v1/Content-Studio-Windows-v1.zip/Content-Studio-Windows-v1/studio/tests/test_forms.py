import pytest

from studio.enums import ClaimType, ClaimSourceRelation, QualityAxis, QualityStatus
from studio.forms import (
    CarouselSlideForm,
    ClaimSlideLinkForm,
    ClaimSourceLinkForm,
    ContentClaimForm,
    ProjectCreateForm,
    QualityReviewForm,
    ResearchSourceForm,
)
from studio.tests.factories import create_brand, create_project


def test_quality_review_form_requires_evidence_and_fail_blocker():
    axis = QualityAxis.PLATFORM_COMPLIANCE
    prefix = f"qa-{axis}"
    data = {
        f"{prefix}-status": QualityStatus.FAIL,
        f"{prefix}-policy_pack_id": "official-policy-fixture",
        f"{prefix}-policy_pack_version": "fixture-v1",
        f"{prefix}-source_urls": "https://example.org/fixture-policy",
        f"{prefix}-findings": "بررسی شد؛ نقص وجود دارد.",
        f"{prefix}-blockers": "عدم انطباق ثبت‌شده.",
    }

    form = QualityReviewForm(data=data, prefix=prefix, axis=axis)

    assert form.is_valid(), form.errors
    assert form.cleaned_data["status"] == QualityStatus.FAIL
    assert form.cleaned_data["blockers"] == ["عدم انطباق ثبت‌شده."]

    data[f"{prefix}-blockers"] = ""
    invalid_form = QualityReviewForm(data=data, prefix=prefix, axis=axis)
    assert not invalid_form.is_valid()
    assert "blocker" in str(invalid_form.errors["blockers"])


@pytest.mark.django_db
def test_project_form_only_offers_active_brands():
    active = create_brand(slug="active", name="Active")
    inactive = create_brand(slug="inactive", name="Inactive")
    inactive.is_active = False
    inactive.save(update_fields=["is_active", "updated_at"])

    form = ProjectCreateForm()

    assert list(form.fields["brand"].queryset) == [active]


@pytest.mark.django_db
def test_research_source_form_has_no_json_claim_linking():
    form = ResearchSourceForm(data={"url": "https://example.org/source"})

    assert form.is_valid(), form.errors
    assert "linked_claims_json" not in form.fields


@pytest.mark.django_db
def test_content_claim_form_creates_a_structured_claim():
    form = ContentClaimForm(
        data={
            "key": "sleep-and-focus",
            "text": "خواب کافی می‌تواند به تمرکز روزانه کمک کند.",
            "claim_type": ClaimType.SCIENTIFIC,
            "requires_source": "on",
            "source_requirement_reason": "",
            "rationale": "",
        }
    )

    assert form.is_valid(), form.errors
    claim = form.save(commit=False)
    assert claim.key == "sleep-and-focus"
    assert claim.requires_source is True


@pytest.mark.django_db
def test_nonfactual_claim_needs_an_explicit_reason_for_not_requiring_source():
    data = {
        "key": "gentle-reminder",
        "text": "می‌توانی از یک قدم کوچک شروع کنی.",
        "claim_type": ClaimType.GENERAL_ADVICE,
        "requires_source": "",
        "source_requirement_reason": "این جمله یک پیشنهاد عمومی است، نه ادعای علمی یا آماری.",
        "rationale": "",
    }
    form = ContentClaimForm(data=data)

    assert form.is_valid(), form.errors
    claim = form.save(commit=False)
    assert claim.requires_source is False
    assert claim.source_requirement_reason.startswith("این جمله")

    missing_reason = ContentClaimForm(data={**data, "source_requirement_reason": ""})
    assert not missing_reason.is_valid()
    assert "source_requirement_reason" in missing_reason.errors


@pytest.mark.django_db
def test_factual_claim_cannot_be_marked_source_free():
    form = ContentClaimForm(
        data={
            "key": "psych-claim",
            "text": "یک گزارهٔ روان‌شناختی برای آزمایش.",
            "claim_type": ClaimType.PSYCHOLOGICAL,
            "requires_source": "",
            "source_requirement_reason": "نیازی به منبع نیست.",
            "rationale": "",
        }
    )

    assert not form.is_valid()
    assert "requires_source" in form.errors


@pytest.mark.django_db
def test_claim_source_link_form_limits_choices_to_same_project():
    project = create_project()
    claim = project.claims.create(key="claim-1", text="یک گزارهٔ قابل بررسی")
    source = project.research_sources.create(
        url="https://example.org/source",
        title="منبع نمونه",
        excerpt="متن دقیق پشتیبان از منبع.",
    )
    other_project = create_project(brand=create_brand(slug="other-brand", name="Other Brand"))
    other_claim = other_project.claims.create(key="other-claim", text="گزارهٔ پروژهٔ دیگر")
    other_source = other_project.research_sources.create(url="https://example.net/source", title="منبع دیگر")
    form = ClaimSourceLinkForm(
        data={
            "claim": str(claim.pk),
            "source": str(source.pk),
            "relation": ClaimSourceRelation.SUPPORTS,
            "evidence_excerpt": "متن دقیق پشتیبان از منبع.",
        },
        project=project,
    )

    mismatched_evidence_form = ClaimSourceLinkForm(
        data={
            "claim": str(claim.pk),
            "source": str(source.pk),
            "relation": ClaimSourceRelation.SUPPORTS,
            "evidence_excerpt": "این متن در منبع ثبت نشده است.",
        },
        project=project,
    )
    assert not mismatched_evidence_form.is_valid()
    assert "evidence_excerpt" in mismatched_evidence_form.errors

    assert form.is_valid(), form.errors
    link = form.save()
    assert link.claim == claim
    assert link.source == source
    assert list(form.fields["claim"].queryset) == [claim]
    assert list(form.fields["source"].queryset) == [source]

    cross_project_form = ClaimSourceLinkForm(
        data={
            "claim": str(other_claim.pk),
            "source": str(other_source.pk),
            "relation": ClaimSourceRelation.SUPPORTS,
            "evidence_excerpt": "شاهد.",
        },
        project=project,
    )
    assert not cross_project_form.is_valid()
    assert "claim" in cross_project_form.errors or "source" in cross_project_form.errors


@pytest.mark.django_db
def test_claim_slide_link_requires_exact_excerpt_from_same_project():
    project = create_project()
    claim = project.claims.create(key="sleep-focus", text="خواب کافی به تمرکز کمک می‌کند.")
    slide = project.slides.create(
        position=1,
        role="body",
        copy_text="خواب کافی به تمرکز روزانه کمک می‌کند.",
    )
    other_project = create_project(brand=create_brand(slug="slide-other", name="Other"))
    other_claim = other_project.claims.create(key="other-claim", text="ادعای دیگر")
    other_slide = other_project.slides.create(position=1, copy_text="متن پروژه دیگر")

    form = ClaimSlideLinkForm(
        data={
            "claim": str(claim.pk),
            "slide": str(slide.pk),
            "copy_excerpt": "خواب کافی به تمرکز روزانه کمک می‌کند.",
        },
        project=project,
    )
    assert form.is_valid(), form.errors
    link = form.save(commit=False)
    assert link.claim == claim
    assert link.slide == slide

    invalid_excerpt = ClaimSlideLinkForm(
        data={
            "claim": str(claim.pk),
            "slide": str(slide.pk),
            "copy_excerpt": "این جمله در اسلاید نیست.",
        },
        project=project,
    )
    assert not invalid_excerpt.is_valid()
    assert "copy_excerpt" in invalid_excerpt.errors

    cross_project = ClaimSlideLinkForm(
        data={
            "claim": str(other_claim.pk),
            "slide": str(other_slide.pk),
            "copy_excerpt": "متن پروژه دیگر",
        },
        project=project,
    )
    assert not cross_project.is_valid()
    assert "claim" in cross_project.errors or "slide" in cross_project.errors


def test_manual_carousel_slide_form_rejects_blank_copy():
    form = CarouselSlideForm(data={"role": "cover", "copy_text": "   "})
    assert not form.is_valid()
    assert "copy_text" in form.errors
