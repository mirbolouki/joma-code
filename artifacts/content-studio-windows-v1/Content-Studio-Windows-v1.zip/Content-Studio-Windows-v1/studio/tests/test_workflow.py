import pytest
from django.test import override_settings

from studio.enums import CapabilityStatus, PipelineStage, ProjectStatus, RunStatus
from studio.models import ProjectArtifact, StageRun
from studio.providers.exceptions import ProviderAdapterUnavailable, ProviderNotConfigured
from studio.providers.registry import get_text_provider
from studio.services.workflow import start_or_resume_project
from studio.tests.factories import create_project


@pytest.mark.django_db
def test_manual_start_creates_blocker_without_mock_output():
    project = create_project()

    with override_settings(STUDIO_LLM_PROVIDER=""):
        result = start_or_resume_project(str(project.pk))

    project.refresh_from_db()
    run = StageRun.objects.get(project=project)
    assert result.status == RunStatus.BLOCKED
    assert result.capability_status == CapabilityStatus.REQUIRES_PROVIDER
    assert run.stage == PipelineStage.OPPORTUNITY_ANALYSIS
    assert "حالت محلی/دستی" in run.message
    assert run.details == {
        "mode": "manual_local",
        "provider_called": False,
        "queue_called": False,
        "test_only": False,
    }
    assert project.status == ProjectStatus.BLOCKED
    assert not ProjectArtifact.objects.filter(project=project).exists()


@pytest.mark.django_db
def test_configured_provider_is_ignored_in_manual_mode():
    project = create_project()

    with override_settings(STUDIO_LLM_PROVIDER="provider-not-approved"):
        result = start_or_resume_project(str(project.pk))

    run = StageRun.objects.get(project=project)
    assert result.status == RunStatus.BLOCKED
    assert result.capability_status == CapabilityStatus.REQUIRES_PROVIDER
    assert run.details["provider_called"] is False
    assert "هیچ API" in result.message
    assert not ProjectArtifact.objects.filter(project=project).exists()


def test_provider_registry_has_no_live_default_adapter():
    with override_settings(STUDIO_LLM_PROVIDER=""):
        with pytest.raises(ProviderNotConfigured):
            get_text_provider()

    with override_settings(STUDIO_LLM_PROVIDER="provider-not-approved"):
        with pytest.raises(ProviderAdapterUnavailable):
            get_text_provider()
