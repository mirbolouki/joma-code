import hashlib

import pytest
from django.utils import timezone

from studio.enums import (
    ClaimSourceRelation,
    ClaimStatus,
    ClaimType,
    FormatChoice,
    ProjectStatus,
    ResearchLevel,
    ResearchSourceStatus,
)
from studio.exporter import (
    ExportNotReady,
    _claim_delivery_blockers,
    _claim_slide_delivery_blockers,
    build_project_zip,
)
from studio.models import (
    CarouselSlide,
    ClaimSlideLink,
    ClaimSourceLink,
    ContentClaim,
    ResearchDecision,
    ResearchSource,
)
from studio.storage import PrivateLocalStore, UnsafeStorageKey
from studio.tests.factories import create_project, create_user


@pytest.mark.django_db
def test_private_storage_saves_hash_and_rejects_traversal(tmp_path):
    store = PrivateLocalStore(tmp_path / "private")
    content = b"private fixture"
    key, digest, byte_size = store.save("2a0d223b-fd1e-4bd2-b5df-fba25b777909", "txt", content)

    assert key.startswith("projects/2a0d223b-fd1e-4bd2-b5df-fba25b777909/")
    assert digest == hashlib.sha256(content).hexdigest()
    assert byte_size == len(content)
    assert store.read(key) == content
    assert store.exists(key)
    assert not (tmp_path / "public" / key).exists()
    with pytest.raises(UnsafeStorageKey):
        store.read("projects/../outside.txt")


@pytest.mark.django_db
def test_exporter_fails_closed_for_incomplete_project(tmp_path):
    project = create_project()

    with pytest.raises(ExportNotReady) as error:
        build_project_zip(str(project.pk), PrivateLocalStore(tmp_path / "private"))

    assert error.value.blockers
    assert any("آمادهٔ تحویل" in blocker for blocker in error.value.blockers)
    assert any("اسلاید" in blocker or "Research Decision" in blocker for blocker in error.value.blockers)


@pytest.mark.django_db
def test_required_research_needs_reviewed_source_before_export(tmp_path):
    project = create_project(status=ProjectStatus.READY)
    project.selected_format = FormatChoice.CAROUSEL
    project.save(update_fields=["selected_format", "updated_at"])
    reviewer = create_user("research-reviewer")
    ResearchDecision.objects.create(
        project=project,
        level=ResearchLevel.REQUIRED,
        rationale="برای claimها پژوهش لازم است.",
        confirmed_by=reviewer,
        confirmed_at=timezone.now(),
    )
    ResearchSource.objects.create(
        project=project,
        url="https://example.org/source",
        title="Fixture Source",
        review_status=ResearchSourceStatus.UNREVIEWED,
    )

    with pytest.raises(ExportNotReady) as error:
        build_project_zip(str(project.pk), PrivateLocalStore(tmp_path / "private"))

    assert any("منبع بازبینی‌شده" in blocker for blocker in error.value.blockers)


@pytest.mark.django_db
def test_claim_delivery_gate_requires_reviewed_claim_and_supporting_source():
    project = create_project()
    reviewer = create_user("claim-reviewer")
    source = ResearchSource.objects.create(
        project=project,
        url="https://example.org/claim-evidence",
        review_status=ResearchSourceStatus.UNREVIEWED,
    )
    claim = ContentClaim.objects.create(
        project=project,
        key="review-needed",
        text="یک ادعای نمونه",
        status=ClaimStatus.DRAFT,
    )
    link = ClaimSourceLink.objects.create(
        claim=claim,
        source=source,
        relation=ClaimSourceRelation.SUPPORTS,
        evidence_excerpt="",
    )

    blockers = _claim_delivery_blockers(project)
    assert any("منبع واقعی" in blocker for blocker in blockers)
    assert any("شاهدِ عیناً" in blocker for blocker in blockers)

    reviewed_at = timezone.now()
    source.excerpt = "پیش‌درآمد شاهد متنی دقیق ادامهٔ بخش نقل‌شده"
    source.save(update_fields=["excerpt", "updated_at"])
    source.refresh_from_db()
    source.review_status = ResearchSourceStatus.REVIEWED
    source.reviewed_by = reviewer
    source.reviewed_at = reviewed_at
    source.save(update_fields=["review_status", "reviewed_by", "reviewed_at", "updated_at"])
    claim.status = ClaimStatus.SUPPORTED
    claim.reviewed_by = reviewer
    claim.reviewed_at = reviewed_at
    claim.save(update_fields=["status", "reviewed_by", "reviewed_at", "updated_at"])
    link.evidence_excerpt = "شاهد متنی دقیق"
    link.save(update_fields=["evidence_excerpt", "updated_at"])
    link.refresh_from_db()
    link.reviewed_by = reviewer
    link.reviewed_at = reviewed_at
    link.save(update_fields=["reviewed_by", "reviewed_at", "updated_at"])

    assert _claim_delivery_blockers(project) == []

    link.evidence_excerpt = "ادامهٔ بخش نقل‌شده"
    link.save(update_fields=["evidence_excerpt", "updated_at"])
    link.refresh_from_db()
    assert link.reviewed_by_id is None
    assert any("پیوند شاهد/منبع هنوز بازبینی انسانی ندارد" in blocker for blocker in _claim_delivery_blockers(project))

    source.url = "https://example.org/revised-source"
    source.save(update_fields=["url", "updated_at"])
    source.refresh_from_db()
    assert source.review_status == ResearchSourceStatus.UNREVIEWED
    assert source.reviewed_by_id is None
    assert any(
        "منبع متصل هنوز بازبینی انسانی ندارد" in blocker
        or "پیوند شاهد/منبع بعد از بازبینی" in blocker
        for blocker in _claim_delivery_blockers(project)
    )


@pytest.mark.django_db
def test_claim_slide_gate_requires_exact_reviewed_copy_mapping():
    project = create_project()
    reviewer = create_user("claim-slide-reviewer")
    claim = ContentClaim.objects.create(project=project, key="slide-claim", text="یک ادعای قابل‌ردیابی")
    slide = CarouselSlide.objects.create(
        project=project,
        position=1,
        role="body",
        copy_text="عبارت دقیق در متن فارسی اسلاید.",
    )

    assert any("به هیچ اسلایدی" in blocker for blocker in _claim_slide_delivery_blockers(project))

    link = ClaimSlideLink.objects.create(
        claim=claim,
        slide=slide,
        copy_excerpt="عبارتی که در متن نیست",
    )
    blockers = _claim_slide_delivery_blockers(project)
    assert any("پیدا نشد" in blocker for blocker in blockers)
    assert any("بازبینی انسانی ندارد" in blocker for blocker in blockers)

    link.copy_excerpt = "عبارت دقیق در متن فارسی اسلاید."
    link.save(update_fields=["copy_excerpt", "updated_at"])
    link.refresh_from_db()
    assert link.reviewed_by_id is None

    link.reviewed_by = reviewer
    link.reviewed_at = timezone.now()
    link.save(update_fields=["reviewed_by", "reviewed_at", "updated_at"])
    assert _claim_slide_delivery_blockers(project) == []

    slide.copy_text += " بازنویسی شد."
    slide.save(update_fields=["copy_text", "updated_at"])
    blockers = _claim_slide_delivery_blockers(project)
    assert any("بعد از ثبت پیوند تغییر کرده" in blocker for blocker in blockers)

    link.save()
    link.refresh_from_db()
    assert link.reviewed_by_id is None
    assert any("بازبینی انسانی ندارد" in blocker for blocker in _claim_slide_delivery_blockers(project))


@pytest.mark.django_db
def test_nonfactual_claim_requires_reason_and_distinct_human_review_status():
    project = create_project()
    reviewer = create_user("nonfactual-reviewer")
    claim = ContentClaim.objects.create(
        project=project,
        key="gentle-advice",
        text="می‌توانی از یک قدم کوچک شروع کنی.",
        claim_type=ClaimType.GENERAL_ADVICE,
        requires_source=False,
        source_requirement_reason="این جمله توصیهٔ عمومی است و ادعای تجربی/علمی ندارد.",
        status=ClaimStatus.REVIEWED_NONFACTUAL,
        reviewed_by=reviewer,
        reviewed_at=timezone.now(),
    )

    assert _claim_delivery_blockers(project) == []

    ungrounded_factual_claim = ContentClaim.objects.create(
        project=project,
        key="ungrounded-psychology",
        text="ادعای روان‌شناختی بی‌منبع",
        claim_type=ClaimType.PSYCHOLOGICAL,
        requires_source=False,
        source_requirement_reason="دلیل نامعتبر برای تست gate.",
    )
    assert any("factual است" in blocker for blocker in _claim_delivery_blockers(project))
    ungrounded_factual_claim.delete()

    claim.text = "این متن را تغییر دادیم."
    claim.save(update_fields=["text", "updated_at"])
    claim.refresh_from_db()
    assert claim.status == ClaimStatus.DRAFT
    assert claim.reviewed_by_id is None
    assert any("غیرfactual" in blocker for blocker in _claim_delivery_blockers(project))
