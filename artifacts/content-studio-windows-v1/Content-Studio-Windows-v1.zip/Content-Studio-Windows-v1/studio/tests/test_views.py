import pytest
from django.urls import reverse

from studio.enums import CapabilityStatus, ProjectStatus, RunStatus
from studio.models import GeneratedAsset, Project, ProjectArtifact, StageRun
from studio.tests.factories import create_brand, create_user


@pytest.mark.django_db
def test_dashboard_and_project_detail_render_for_authenticated_user(client):
    user = create_user()
    brand = create_brand()
    project = Project.objects.create(
        brand=brand,
        idea="آموزش عمومی دربارهٔ خواب",
        status=ProjectStatus.BLOCKED,
        created_by=user,
    )
    StageRun.objects.create(
        project=project,
        stage="opportunity_analysis",
        status=RunStatus.BLOCKED,
        capability_status=CapabilityStatus.REQUIRES_PROVIDER,
        message="provider غیرفعال است و خروجی mock ساخته نشد.",
    )
    client.force_login(user)

    dashboard = client.get(reverse("studio:dashboard"))
    detail = client.get(reverse("studio:project_detail", kwargs={"project_id": project.pk}))

    assert dashboard.status_code == 200
    assert "پروژه‌های محتوا" in dashboard.content.decode()
    assert detail.status_code == 200
    assert "مسیر کامل Carousel" in detail.content.decode()
    assert "PNG نهایی برای هیچ اسلایدی ساخته نشده است" in detail.content.decode()


@pytest.mark.django_db
def test_dashboard_creates_project_and_records_local_manual_blocker(client, settings):
    user = create_user()
    brand = create_brand()
    client.force_login(user)
    settings.STUDIO_LLM_PROVIDER = "configured-provider-is-ignored-in-manual-mode"

    response = client.post(
        reverse("studio:dashboard"),
        {"brand": str(brand.pk), "idea": "ایدهٔ آموزشی بدون دادهٔ شخصی", "requested_format": "carousel"},
    )

    project = Project.objects.get()
    assert response.status_code == 302
    assert response.url == reverse("studio:project_detail", kwargs={"project_id": project.pk})
    assert project.created_by == user
    assert project.status == ProjectStatus.BLOCKED
    assert set(project.quality_reports.values_list("axis", flat=True)) == {
        "platform_compliance",
        "platform_best_practices",
        "creative_quality",
    }
    run = StageRun.objects.get(project=project, status=RunStatus.BLOCKED)
    assert "هیچ API، provider، صف Celery یا سرویس بیرونی فراخوانی نمی‌شود" in run.message
    assert run.details == {
        "mode": "manual_local",
        "provider_called": False,
        "queue_called": False,
        "test_only": False,
    }
    assert not ProjectArtifact.objects.filter(project=project).exists()


@pytest.mark.django_db
def test_manual_mode_never_calls_provider_or_celery_queue(client, settings, monkeypatch):
    from studio.tasks import start_project_pipeline

    user = create_user("manual-only-user")
    brand = create_brand()
    client.force_login(user)
    settings.STUDIO_LLM_PROVIDER = "configured-but-not-approved"

    def unexpected(*args, **kwargs):
        raise AssertionError("manual-only project creation must not call a provider or enqueue Celery")

    monkeypatch.setattr("studio.providers.registry.get_text_provider", unexpected)
    monkeypatch.setattr(start_project_pipeline, "delay", unexpected)
    response = client.post(
        reverse("studio:dashboard"),
        {"brand": str(brand.pk), "idea": "ایدهٔ دستی بدون دادهٔ شخصی", "requested_format": "carousel"},
    )

    assert response.status_code == 302
    assert Project.objects.filter(created_by=user).count() == 1
    assert StageRun.objects.filter(project__created_by=user, status=RunStatus.BLOCKED).exists()


@pytest.mark.django_db
def test_manual_retry_does_not_call_provider_or_enqueue(client, settings, monkeypatch):
    from studio.tasks import start_project_pipeline

    user = create_user("manual-retry-user")
    project = Project.objects.create(brand=create_brand(), idea="ایدهٔ محلی", created_by=user)
    client.force_login(user)
    settings.STUDIO_LLM_PROVIDER = "configured-but-ignored"

    def unexpected(*args, **kwargs):
        raise AssertionError("manual retry must not call a provider or enqueue Celery")

    monkeypatch.setattr("studio.providers.registry.get_text_provider", unexpected)
    monkeypatch.setattr(start_project_pipeline, "delay", unexpected)
    response = client.post(reverse("studio:retry_pipeline", kwargs={"project_id": project.pk}), follow=True)

    project.refresh_from_db()
    assert response.status_code == 200
    assert project.status == ProjectStatus.BLOCKED
    assert "هیچ API، provider، صف Celery یا سرویس بیرونی فراخوانی نمی‌شود" in response.content.decode()


@pytest.mark.django_db
def test_blocked_project_zip_request_is_refused_and_not_stored(client, settings, tmp_path):
    user = create_user()
    project = Project.objects.create(brand=create_brand(), idea="ادعای نیازمند بازبینی", created_by=user)
    client.force_login(user)
    settings.PRIVATE_MEDIA_ROOT = tmp_path / "private-storage"

    response = client.post(
        reverse("studio:download_project_zip", kwargs={"project_id": project.pk}),
        follow=True,
    )

    assert response.status_code == 200
    assert "خروجی نهایی هنوز آماده نیست" in response.content.decode()
    assert not GeneratedAsset.objects.filter(project=project, kind="zip").exists()
    assert not list((tmp_path / "private-storage").rglob("*.zip"))


@pytest.mark.django_db
def test_dashboard_requires_authentication(client):
    response = client.get(reverse("studio:dashboard"))
    assert response.status_code == 302
    assert response.url.startswith("/login/")
