import pytest
from django.db import connection
from django.db.migrations.executor import MigrationExecutor


@pytest.mark.django_db(transaction=True)
def test_legacy_claim_keys_are_preserved_as_unresolved_audit_artifacts():
    migration_0002 = [("studio", "0002_alter_qualityreport_status")]
    migration_latest = [("studio", "0011_project_test_only_qualityreport_test_only_and_more")]

    try:
        executor = MigrationExecutor(connection)
        executor.migrate(migration_0002)
        old_apps = executor.loader.project_state(migration_0002).apps
        BrandProfile = old_apps.get_model("studio", "BrandProfile")
        Project = old_apps.get_model("studio", "Project")
        ResearchSource = old_apps.get_model("studio", "ResearchSource")

        brand = BrandProfile.objects.create(slug="migration-brand", name="Migration Brand")
        project = Project.objects.create(brand=brand, idea="Migration fixture")
        ResearchSource.objects.create(
            project=project,
            url="https://example.org/legacy",
            linked_claims=["claim-without-text"],
        )

        executor = MigrationExecutor(connection)
        executor.migrate(migration_latest)
        new_apps = executor.loader.project_state(migration_latest).apps
        ProjectArtifact = new_apps.get_model("studio", "ProjectArtifact")
        artifact = ProjectArtifact.objects.get(
            project_id=project.pk,
            artifact_type="legacy_claim_link_import",
        )

        assert artifact.payload["legacy_linked_claims"] == ["claim-without-text"]
        assert artifact.payload["resolution_status"] == "unresolved"
        assert artifact.payload["source_url"] == "https://example.org/legacy"
        assert artifact.provenance == "user_input"
    finally:
        MigrationExecutor(connection).migrate(migration_latest)
