import io

import pytest
from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse
from PIL import Image

from studio.enums import (
    ArtifactProvenance,
    AssetKind,
    AssetRightsBasis,
    PipelineStage,
    QualityStatus,
    RunStatus,
)
from studio.forms import SlideImageUploadForm
from studio.models import GeneratedAsset, ProjectArtifact, QualityReport, StageRun
from studio.storage import PrivateLocalStore
from studio.tests.factories import create_brand, create_project, create_user
from studio.services.uploads import MAX_UPLOAD_BYTES, InvalidImageUpload, normalize_uploaded_image


def _image_bytes(image_format="PNG", size=(1200, 1600), exif=None):
    image = Image.new("RGB", size, (94, 122, 140))
    output = io.BytesIO()
    save_args = {"format": image_format}
    if exif is not None:
        save_args["exif"] = exif
    image.save(output, **save_args)
    return output.getvalue()


def _upload_form_data(slide_id, *, rights_basis=AssetRightsBasis.OWNED, rights_note="تصویر را خودم ساخته‌ام.", source_url=""):
    prefix = f"upload-{slide_id}"
    return {
        f"{prefix}-rights_basis": rights_basis,
        f"{prefix}-rights_note": rights_note,
        f"{prefix}-rights_source_url": source_url,
        f"{prefix}-rights_confirmed": "on",
    }


@pytest.mark.parametrize("image_format", ["PNG", "JPEG"])
def test_upload_normalizer_accepts_png_and_jpeg_and_removes_exif(image_format):
    exif = Image.Exif()
    exif[271] = "private-camera-model"
    original = _image_bytes(image_format, exif=exif)
    uploaded = SimpleUploadedFile("ignore-this-name.bin", original, content_type="text/plain")

    normalized = normalize_uploaded_image(uploaded)
    with Image.open(io.BytesIO(normalized.content)) as image:
        assert image.format == image_format
        assert image.size == (1200, 1600)
        assert not image.getexif()

    assert normalized.mime_type == ("image/png" if image_format == "PNG" else "image/jpeg")
    assert len(normalized.sha256) == 64
    assert "ignore-this-name" not in normalized.content.decode("latin1", errors="ignore")


def test_upload_normalizer_rejects_bad_format_tiny_and_oversized_files():
    gif = io.BytesIO()
    Image.new("RGB", (800, 800), (1, 2, 3)).save(gif, format="GIF")
    with pytest.raises(InvalidImageUpload, match="PNG یا JPEG"):
        normalize_uploaded_image(SimpleUploadedFile("animated.gif", gif.getvalue()))

    with pytest.raises(InvalidImageUpload, match="حداقل ۵۱۲"):
        normalize_uploaded_image(SimpleUploadedFile("tiny.png", _image_bytes(size=(256, 256))))

    with pytest.raises(InvalidImageUpload, match="۱۲ مگابایت"):
        normalize_uploaded_image(SimpleUploadedFile("huge.png", b"x" * (MAX_UPLOAD_BYTES + 1)))

    with pytest.raises(InvalidImageUpload, match="خراب"):
        normalize_uploaded_image(SimpleUploadedFile("broken.png", b"not an image"))


@pytest.mark.django_db
def test_authenticated_owner_uploads_local_test_fixture_then_replacement_invalidates_renders(
    tmp_path, client, settings, monkeypatch
):
    settings.STUDIO_TEST_MODE = True
    user = create_user("image-owner")
    project = create_project()
    project.created_by = user
    project.save(update_fields=["created_by", "updated_at"])
    slide = project.slides.create(position=1, role="local image fixture", copy_text="تصویر محلی آزمایشی بدون ادعای علمی.")
    store = PrivateLocalStore(tmp_path / "private")
    monkeypatch.setattr("studio.services.uploads.PrivateLocalStore", lambda: store)
    client.force_login(user)
    route = reverse(
        "studio:upload_slide_base_image",
        kwargs={"project_id": project.pk, "slide_id": slide.pk},
    )

    first_bytes = _image_bytes("JPEG")
    response = client.post(
        route,
        {
            f"fixture-{slide.pk}-image": SimpleUploadedFile(
                "local-fixture.jpg",
                first_bytes,
                content_type="image/jpeg",
            ),
        },
        HTTP_X_STUDIO_TEST_FIXTURE="1",
        follow=True,
    )

    asset = project.assets.get(slide=slide, kind=AssetKind.IMAGE_PLAIN)
    assert response.status_code == 200
    assert asset.provenance == ArtifactProvenance.TEST_FIXTURE
    assert asset.provider_id == asset.model_name == ""
    assert asset.rights_basis == ""
    assert asset.rights_confirmed_by is None
    assert asset.rights_confirmed_at is None
    assert asset.rights_source_url == ""
    assert asset.is_private
    assert asset.storage_key.startswith(f"projects/{project.pk}/")
    assert "private-name" not in asset.storage_key
    normalized_first = store.read(asset.storage_key)
    with Image.open(io.BytesIO(normalized_first)) as stored:
        assert stored.format == "JPEG"
        assert not stored.getexif()

    upload_artifact = ProjectArtifact.objects.get(
        project=project,
        artifact_type="local_test_fixture_base_image",
        version=1,
    )
    assert upload_artifact.provenance == ArtifactProvenance.TEST_FIXTURE
    assert upload_artifact.payload["provenance"] == ArtifactProvenance.TEST_FIXTURE
    assert upload_artifact.payload["test_only"] is True
    assert upload_artifact.payload["provider_called"] is False
    image_run = StageRun.objects.get(project=project, stage=PipelineStage.IMAGE_GENERATION)
    assert image_run.status == RunStatus.COMPLETED
    assert image_run.details["source_provenance"] == ArtifactProvenance.TEST_FIXTURE
    assert "TEST_FIXTURE" in image_run.message

    old_final_key, _, old_size = store.save(str(project.pk), "png", _image_bytes())
    old_final = GeneratedAsset.objects.create(
        project=project,
        slide=slide,
        kind=AssetKind.IMAGE_FINAL,
        storage_key=old_final_key,
        mime_type="image/png",
        width=1200,
        height=1600,
        byte_size=old_size,
        sha256="a" * 64,
        provenance=ArtifactProvenance.SYSTEM_GENERATED,
        is_private=True,
    )
    QualityReport.objects.create(
        project=project,
        axis="creative_quality",
        status=QualityStatus.PASS,
        version=2,
        reviewed_by=user,
        test_only=True,
    )

    response = client.post(
        route,
        {
            f"fixture-{slide.pk}-image": SimpleUploadedFile("replacement.png", _image_bytes()),
        },
        HTTP_X_STUDIO_TEST_FIXTURE="1",
        follow=True,
    )
    asset.refresh_from_db()

    assert response.status_code == 200
    assert asset.provenance == ArtifactProvenance.TEST_FIXTURE
    assert asset.rights_basis == ""
    assert asset.sha256 != upload_artifact.payload["sha256"]
    assert not GeneratedAsset.objects.filter(pk=old_final.pk).exists()
    assert not store.exists(old_final_key)
    report = QualityReport.objects.filter(project=project, axis="creative_quality").order_by("-version").first()
    assert report.status == QualityStatus.NOT_RUN
    assert report.reviewed_by_id is None and report.reviewed_at is None
    assert report.blockers == ["تصویر پایه تغییر کرده؛ بازبینی انسانی باید دوباره انجام شود."]
    assert ProjectArtifact.objects.filter(project=project, artifact_type="local_test_fixture_base_image").count() == 2


@pytest.mark.django_db
def test_upload_is_login_required_and_project_scoped(client, tmp_path, monkeypatch):
    owner = create_user("image-owner-scope")
    other_user = create_user("not-image-owner")
    project = create_project()
    project.created_by = owner
    project.save(update_fields=["created_by", "updated_at"])
    slide = project.slides.create(position=1, role="access fixture", copy_text="متن")
    route = reverse(
        "studio:upload_slide_base_image",
        kwargs={"project_id": project.pk, "slide_id": slide.pk},
    )
    store = PrivateLocalStore(tmp_path / "private")
    monkeypatch.setattr("studio.services.uploads.PrivateLocalStore", lambda: store)

    anonymous_response = client.post(
        route,
        {
            **_upload_form_data(slide.pk),
            f"upload-{slide.pk}-image": SimpleUploadedFile("image.png", _image_bytes()),
        },
    )
    assert anonymous_response.status_code == 302
    client.force_login(other_user)
    foreign_response = client.post(
        route,
        {
            **_upload_form_data(slide.pk),
            f"upload-{slide.pk}-image": SimpleUploadedFile("image.png", _image_bytes()),
        },
    )
    assert foreign_response.status_code == 404
    assert not project.assets.exists()
    assert not list((tmp_path / "private").rglob("*.png"))

    detail_response = client.get(reverse("studio:project_detail", kwargs={"project_id": project.pk}))
    dashboard_response = client.get(reverse("studio:dashboard"))
    assert detail_response.status_code == 404
    assert dashboard_response.status_code == 200
    assert str(project.pk) not in dashboard_response.content.decode()


@pytest.mark.django_db
def test_upload_rejects_missing_rights_confirmation_and_cross_project_slide(client):
    owner = create_user("image-upload-owner")
    project = create_project()
    project.created_by = owner
    project.save(update_fields=["created_by", "updated_at"])
    slide = project.slides.create(position=1, role="access fixture", copy_text="متن")
    other_project = create_project(brand=create_brand(slug="brand-other", name="Brand Other"))
    other_project.created_by = owner
    other_project.save(update_fields=["created_by", "updated_at"])
    foreign_slide = other_project.slides.create(position=1, role="foreign", copy_text="متن")
    client.force_login(owner)

    route = reverse(
        "studio:upload_slide_base_image",
        kwargs={"project_id": project.pk, "slide_id": slide.pk},
    )
    no_confirmation = {
        f"upload-{slide.pk}-rights_basis": AssetRightsBasis.OWNED,
        f"upload-{slide.pk}-rights_note": "تصویر خودم",
        f"upload-{slide.pk}-image": SimpleUploadedFile("image.png", _image_bytes()),
    }
    response = client.post(route, no_confirmation, follow=True)
    assert response.status_code == 200
    assert not project.assets.exists()

    cross_project_route = reverse(
        "studio:upload_slide_base_image",
        kwargs={"project_id": project.pk, "slide_id": foreign_slide.pk},
    )
    cross_project_response = client.post(cross_project_route)
    assert cross_project_response.status_code == 404
