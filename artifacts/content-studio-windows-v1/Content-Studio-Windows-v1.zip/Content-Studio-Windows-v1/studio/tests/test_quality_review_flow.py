import io
import json
import os
import zipfile
from pathlib import Path

import pytest
from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse
from PIL import Image, ImageDraw

from studio.enums import (
    ArtifactProvenance,
    AssetKind,
    CapabilityStatus,
    PipelineStage,
    QualityAxis,
    QualityStatus,
    ResearchLevel,
    RunStatus,
)
from studio.models import Project, ProjectArtifact, QualityReport, StageRun
from studio.quality import ensure_initial_quality_reports, final_delivery_blockers
from studio.storage import PrivateLocalStore
from studio.tests.factories import create_brand, create_user


def _local_generated_background(position: int) -> bytes:
    """Draw a no-text geometric TEST_FIXTURE locally; never a user or AI image."""
    palette = [
        ((22, 50, 69), (46, 108, 113), (201, 139, 89)),
        ((35, 48, 75), (63, 91, 130), (206, 154, 102)),
        ((27, 64, 67), (61, 117, 96), (221, 176, 117)),
        ((42, 47, 74), (93, 89, 126), (220, 166, 112)),
        ((31, 57, 70), (64, 123, 110), (218, 173, 114)),
    ]
    base, accent, highlight = palette[(position - 1) % len(palette)]
    image = Image.new("RGB", (1200, 1600), base)
    draw = ImageDraw.Draw(image)
    for band in range(8):
        top = band * 220 - 150
        tint = tuple(min(255, int(base[channel] * 0.45 + accent[channel] * 0.55 + band * 2)) for channel in range(3))
        draw.rounded_rectangle((40 + band * 32, top, 1160 - band * 25, top + 300), radius=95, fill=tint)
    center_x = 180 + ((position * 173) % 790)
    center_y = 320 + ((position * 211) % 920)
    draw.ellipse((center_x - 270, center_y - 270, center_x + 270, center_y + 270), fill=highlight)
    draw.ellipse((center_x - 178, center_y - 178, center_x + 178, center_y + 178), fill=accent)
    draw.arc((90, 180, 1110, 1390), start=35 + position * 12, end=285 + position * 8, fill=highlight, width=24)
    draw.line(
        [(90, 1300 - position * 35), (340, 990), (640, 1120), (980, 520 + position * 24)],
        fill=(235, 211, 169),
        width=11,
        joint="curve",
    )
    output = io.BytesIO()
    image.save(output, format="PNG", optimize=True)
    return output.getvalue()


def _qa_form_data(axis):
    prefix = f"qa-{axis}"
    return {
        f"{prefix}-status": QualityStatus.PASS,
        f"{prefix}-policy_pack_id": f"TEST_ONLY-{axis}",
        f"{prefix}-policy_pack_version": "local-test-v1",
        f"{prefix}-source_urls": "",
        f"{prefix}-findings": "TEST_ONLY: route/gate exercised; no official platform audit or real human approval performed.",
        f"{prefix}-blockers": "",
    }


@pytest.mark.django_db
def test_quality_route_blocks_without_final_rasters_and_keeps_not_run(client, settings):
    settings.STUDIO_TEST_MODE = True
    reviewer = create_user("qa-blocked-reviewer")
    project = Project.objects.create(
        brand=create_brand(slug="qa-blocked-brand"),
        idea="TEST_ONLY: موضوع آزمایشی",
        created_by=reviewer,
        test_only=True,
    )
    ensure_initial_quality_reports(project)
    client.force_login(reviewer)

    response = client.post(
        reverse(
            "studio:record_quality_review",
            kwargs={"project_id": project.pk, "axis": QualityAxis.PLATFORM_COMPLIANCE},
        ),
        _qa_form_data(QualityAxis.PLATFORM_COMPLIANCE),
        HTTP_X_STUDIO_TEST_ONLY="1",
        follow=True,
    )

    assert response.status_code == 200
    assert set(project.quality_reports.values_list("status", flat=True)) == {QualityStatus.NOT_RUN}
    assert "QA ثبت نشد" in response.content.decode()
    assert not ProjectArtifact.objects.filter(project=project, artifact_type="human_quality_review").exists()


@pytest.mark.django_db
def test_test_only_local_manual_carousel_runs_real_app_routes_and_downloads_zip(
    tmp_path, client, settings, monkeypatch
):
    settings.STUDIO_TEST_MODE = True
    reviewer = create_user("test-only-editor")
    brand = create_brand(slug="test-only-carousel", name="TEST_ONLY — نمونهٔ محلی")
    client.force_login(reviewer)
    store = PrivateLocalStore(tmp_path / "private")
    monkeypatch.setattr("studio.services.uploads.PrivateLocalStore", lambda: store)
    monkeypatch.setattr("studio.services.rendering.PrivateLocalStore", lambda: store)
    monkeypatch.setattr("studio.views.PrivateLocalStore", lambda: store)

    create_response = client.post(
        reverse("studio:dashboard"),
        {
            "brand": str(brand.pk),
            "idea": "TEST_ONLY: چرا بعضی عادت‌ها را با وجود تصمیم قبلی تکرار می‌کنیم؟",
            "requested_format": "carousel",
        },
        HTTP_X_STUDIO_TEST_ONLY="1",
    )
    assert create_response.status_code == 302
    project = Project.objects.get(created_by=reviewer)
    assert project.test_only is True
    assert project.selected_format == "carousel"
    assert project.quality_reports.count() == 3
    assert StageRun.objects.get(project=project, stage=PipelineStage.OPPORTUNITY_ANALYSIS).details["queue_called"] is False

    manual_stage_inputs = (
        (
            PipelineStage.OPPORTUNITY_ANALYSIS,
            "TEST_ONLY: موضوع را به شکل پرسش روایی قاب‌بندی کن؛ علت روان‌شناختی یا ادعای تجربی مطرح نشود.",
        ),
        (
            PipelineStage.STRATEGY,
            "TEST_ONLY: مسیر روایت از تصمیم، به لحظهٔ آشنا، سپس مکث و دعوتی کوچک می‌رسد؛ بدون نتیجه‌گیری علمی.",
        ),
        (PipelineStage.HOOK, "TEST_ONLY: قول دادی این بار تکرارش نکنی…"),
        (
            PipelineStage.CONTENT_STRUCTURE,
            "TEST_ONLY: پنج فریم خلاقانه: قول، لحظه، استعارهٔ صفحهٔ تکراری، مکث، دعوت به شروع دوباره.",
        ),
    )
    for stage, content in manual_stage_inputs:
        stage_response = client.post(
            reverse("studio:record_manual_stage_input", kwargs={"project_id": project.pk}),
            {"stage": stage, "content": content},
            HTTP_X_STUDIO_TEST_ONLY="1",
        )
        assert stage_response.status_code == 302
        artifact = project.artifacts.filter(stage=stage, artifact_type="manual_stage_input").latest("version")
        assert artifact.provenance == ArtifactProvenance.TEST_FIXTURE
        assert artifact.payload["test_only"] is True
        assert artifact.payload["provider_called"] is False

    research_response = client.post(
        reverse("studio:save_research_decision", kwargs={"project_id": project.pk}),
        {
            "level": ResearchLevel.NONE,
            "rationale": "TEST_ONLY: متن صرفاً استعاری/خلاقه است؛ ادعای factual یا روان‌شناختی ندارد و منبعی جعل نشده است.",
        },
        HTTP_X_STUDIO_TEST_ONLY="1",
    )
    assert research_response.status_code == 302
    decision = project.research_decision
    assert decision.test_only is True
    assert decision.level == ResearchLevel.NONE
    assert not project.research_sources.exists()
    assert not project.claims.exists()

    copy_texts = (
        "قول دادی این بار تکرارش نکنی…",
        "بعد، یک لحظهٔ آشنا جلویت می‌ایستد.",
        "و قصه، انگار از همان صفحه ورق می‌خورد.",
        "این بار یک مکث کوچک؛ فقط برای دیدن انتخابت.",
        "به‌جای سرزنش: یک شروع تازه برای همین لحظه.",
    )
    roles = ("cover", "moment", "metaphor", "pause", "invitation")
    for position, (role, copy_text) in enumerate(zip(roles, copy_texts), start=1):
        slide_response = client.post(
            reverse("studio:add_carousel_slide", kwargs={"project_id": project.pk}),
            {"role": role, "copy_text": copy_text},
            HTTP_X_STUDIO_TEST_ONLY="1",
        )
        assert slide_response.status_code == 302
        slide = project.slides.get(position=position)
        copy_artifact = project.artifacts.filter(
            stage=PipelineStage.PERSIAN_COPY,
            artifact_type="carousel_slide_copy",
        ).latest("version")
        assert copy_artifact.provenance == ArtifactProvenance.TEST_FIXTURE
        assert copy_artifact.payload["test_only"] is True

        uploaded = client.post(
            reverse("studio:upload_slide_base_image", kwargs={"project_id": project.pk, "slide_id": slide.pk}),
            {
                f"fixture-{slide.pk}-image": SimpleUploadedFile(
                    f"local-generated-{position}.png",
                    _local_generated_background(position),
                    content_type="image/png",
                ),
            },
            HTTP_X_STUDIO_TEST_FIXTURE="1",
        )
        assert uploaded.status_code == 302
        base = project.assets.get(slide=slide, kind=AssetKind.IMAGE_PLAIN)
        assert base.provenance == ArtifactProvenance.TEST_FIXTURE
        assert base.rights_confirmed_by_id is None
        assert base.provider_id == base.model_name == ""

        rendered = client.post(
            reverse("studio:render_slide_asset", kwargs={"project_id": project.pk, "slide_id": slide.pk})
        )
        assert rendered.status_code == 302
        final = project.assets.get(slide=slide, kind=AssetKind.IMAGE_FINAL)
        preview = project.assets.get(slide=slide, kind=AssetKind.PREVIEW)
        final_bytes = store.read(final.storage_key)
        preview_bytes = store.read(preview.storage_key)
        assert final.provenance == ArtifactProvenance.SYSTEM_GENERATED
        assert final.mime_type == "image/png" and (final.width, final.height) == (1080, 1350)
        assert final_bytes == preview_bytes
        assert final.sha256 == preview.sha256
        assert len(final.render_input_hash) == 64

        preview_response = client.get(
            reverse("studio:preview_final_asset", kwargs={"project_id": project.pk, "asset_id": final.pk})
        )
        assert preview_response.status_code == 200
        assert b"".join(preview_response.streaming_content) == final_bytes

    for axis in QualityAxis:
        review_response = client.post(
            reverse("studio:record_quality_review", kwargs={"project_id": project.pk, "axis": axis}),
            _qa_form_data(axis),
            HTTP_X_STUDIO_TEST_ONLY="1",
        )
        assert review_response.status_code == 302
        report = project.quality_reports.filter(axis=axis).order_by("-version").first()
        assert report.status == QualityStatus.PASS
        assert report.test_only is True
        assert report.reviewed_by == reviewer
        assert len(report.reviewed_content_hash) == 64
        assert report.source_urls == []
        assert report.provider_id == report.model_name == ""

    project.refresh_from_db()
    assert project.status == "needs_review"  # A TEST_ONLY suite never marks a product ready.
    assert ProjectArtifact.objects.filter(
        project=project,
        artifact_type="human_quality_review",
        provenance=ArtifactProvenance.TEST_FIXTURE,
    ).count() == 3
    assert StageRun.objects.filter(
        project=project,
        stage__in=[
            PipelineStage.PLATFORM_COMPLIANCE,
            PipelineStage.PLATFORM_BEST_PRACTICES,
            PipelineStage.CREATIVE_QUALITY,
        ],
        status=RunStatus.COMPLETED,
        capability_status=CapabilityStatus.NOT_VERIFIED,
        details__test_only=True,
    ).count() == 3

    detail = client.get(reverse("studio:project_detail", kwargs={"project_id": project.pk}))
    assert detail.status_code == 200
    assert "TEST_ONLY project" in detail.content.decode()
    assert "TEST_ONLY — تأیید واقعی نیست" in detail.content.decode()

    download_response = client.post(reverse("studio:download_project_zip", kwargs={"project_id": project.pk}))
    assert download_response.status_code == 200
    archive_bytes = b"".join(download_response.streaming_content)
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
        assert archive.testzip() is None
        names = set(archive.namelist())
        assert {f"test-only/final/{position:02d}.final.png" for position in range(1, 6)} <= names
        assert {f"previews/slide-{position:02d}.png" for position in range(1, 6)} <= names
        assert not any(name.startswith("publish-ready/") for name in names)
        manifest = json.loads(archive.read("manifest.json"))
        assert "TEST_ONLY" in archive.read("README_FA.txt").decode()
    assert manifest["test_only"] is True
    assert manifest["project_test_only"] is True
    assert manifest["research_decision"]["test_only"] is True
    assert manifest["claims"] == [] and manifest["sources"] == []
    assert len(manifest["assets"]) == 15
    assert all(
        asset["provenance"] == ArtifactProvenance.TEST_FIXTURE
        for asset in manifest["assets"]
        if asset["kind"] == AssetKind.IMAGE_PLAIN
    )
    latest_reports = {}
    for report in manifest["quality_reports"]:
        if report["axis"] not in latest_reports or report["version"] > latest_reports[report["axis"]]["version"]:
            latest_reports[report["axis"]] = report
    assert set(latest_reports) == set(QualityAxis.values)
    assert all(report["status"] == QualityStatus.PASS and report["test_only"] for report in latest_reports.values())
    assert manifest["provider_credentials_included"] is False

    zip_asset = project.assets.get(kind=AssetKind.ZIP)
    assert zip_asset.is_private is True
    assert store.read(zip_asset.storage_key) == archive_bytes

    output_root = os.getenv("STUDIO_E2E_OUTPUT")
    if output_root:
        output_dir = Path(output_root)
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "carousel-test-only.zip").write_bytes(archive_bytes)
        (output_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
            (output_dir / "README_FA.txt").write_bytes(archive.read("README_FA.txt"))
            for position in range(1, 6):
                slide_dir = output_dir / "slides"
                preview_dir = output_dir / "previews"
                slide_dir.mkdir(exist_ok=True)
                preview_dir.mkdir(exist_ok=True)
                (slide_dir / f"{position:02d}.final.png").write_bytes(
                    archive.read(f"test-only/final/{position:02d}.final.png")
                )
                (preview_dir / f"{position:02d}.preview.png").write_bytes(
                    archive.read(f"previews/slide-{position:02d}.png")
                )
        (output_dir / "EVIDENCE_TEST_ONLY.txt").write_text(
            "TEST_ONLY — Django Test Client exercised project creation, manual editorial inputs, local fixture upload, Skia/HarfBuzz rendering, authenticated preview, three TEST_ONLY QA submissions, and the app ZIP download view.\n"
            f"Project ID: {project.pk}\n"
            "Factual/psychological claims: none; Research Decision: no external research.\n"
            "Images: locally drawn geometric PNG backgrounds, provenance TEST_FIXTURE; not USER_INPUT, not AI, not release assets.\n"
            "Reviews: simulated TEST_ONLY forms, not human approval.\n",
            encoding="utf-8",
        )

    first_slide = project.slides.order_by("position").first()
    first_slide.copy_text += " (revision)"
    first_slide.save(update_fields=["copy_text", "updated_at"])
    stale_blockers = final_delivery_blockers(project)
    assert sum("پس از آخرین تغییر محتوا/تصویر بازبینی نشده است" in blocker for blocker in stale_blockers) == 3
    blocked_download = client.post(
        reverse("studio:download_project_zip", kwargs={"project_id": project.pk}),
        follow=True,
    )
    assert blocked_download.status_code == 200
    assert "هنوز آماده نیست" in blocked_download.content.decode()
