from django.contrib.auth import get_user_model

from studio.enums import FormatChoice, PipelineStage, ProjectStatus
from studio.models import BrandProfile, Project


def create_brand(*, slug: str = "brand-a", name: str = "Brand A") -> BrandProfile:
    return BrandProfile.objects.create(slug=slug, name=name)


def create_project(
    *,
    brand: BrandProfile | None = None,
    idea: str = "آموزش عمومی دربارهٔ سلامت خواب",
    status: str = ProjectStatus.DRAFT,
    current_stage: str = PipelineStage.OPPORTUNITY_ANALYSIS,
) -> Project:
    brand = brand or create_brand()
    return Project.objects.create(
        brand=brand,
        idea=idea,
        requested_format=FormatChoice.CAROUSEL,
        status=status,
        current_stage=current_stage,
    )


def create_user(username: str = "studio-user"):
    user_model = get_user_model()
    return user_model.objects.create_user(username=username, password="test-only-password")
