from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any

from .pillow_raqm import RenderSpec, RendererNotReady, TextOverflowError


class SkiaCanvasRenderer:
    """Render a private PNG with Skia/HarfBuzz using bundled, OFL-licensed Noto fonts."""

    def __init__(self, node_binary: str | None = None, script_path: str | Path | None = None):
        self.node_binary = node_binary or os.environ.get("STUDIO_NODE_BINARY", "node")
        self.script_path = Path(script_path or Path(__file__).with_name("skia_render.cjs"))
        self.font_dir = self.script_path.parent / "fonts"

    def check_ready(self) -> dict[str, Any]:
        if not shutil.which(self.node_binary) and not Path(self.node_binary).is_file():
            raise RendererNotReady(f"Node.js executable is unavailable: {self.node_binary}")
        required_fonts = (
            "noto-sans-arabic-arabic-400-normal.woff2",
            "noto-sans-arabic-arabic-700-normal.woff2",
            "noto-sans-arabic-latin-400-normal.woff2",
            "noto-sans-arabic-latin-700-normal.woff2",
            "OFL-1.1.txt",
        )
        missing = [name for name in required_fonts if not (self.font_dir / name).is_file()]
        if missing:
            raise RendererNotReady(f"Bundled Persian renderer files are missing: {', '.join(missing)}")
        try:
            result = subprocess.run(
                [self.node_binary, str(self.script_path), "--probe"],
                capture_output=True,
                check=False,
                timeout=15,
                env=self._environment(),
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise RendererNotReady(f"Skia renderer probe could not run: {exc}") from exc
        if result.returncode != 0:
            detail = result.stderr.decode("utf-8", errors="replace").strip()
            raise RendererNotReady(f"Skia renderer is not ready: {detail or result.returncode}")
        try:
            return json.loads(result.stdout.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RendererNotReady("Skia renderer returned an invalid readiness response.") from exc

    def render_input_hash(self, base_image_sha256: str, text: str, spec: RenderSpec | None = None) -> str:
        if len(base_image_sha256) != 64:
            raise ValueError("The base image must have a valid SHA-256 before render fingerprinting.")
        spec = spec or RenderSpec()
        font_hashes = {
            name: hashlib.sha256((self.font_dir / name).read_bytes()).hexdigest()
            for name in (
                "noto-sans-arabic-arabic-400-normal.woff2",
                "noto-sans-arabic-arabic-700-normal.woff2",
                "noto-sans-arabic-latin-400-normal.woff2",
                "noto-sans-arabic-latin-700-normal.woff2",
            )
        }
        snapshot = {
            "engine": "@napi-rs/canvas-1.0.13/skia-harfbuzz-v1",
            "font_hashes": font_hashes,
            "base_image_sha256": base_image_sha256,
            "text": text,
            "spec": {
                "width": spec.width,
                "height": spec.height,
                "font_size": spec.font_size,
                "font_weight": spec.font_weight,
                "margin_x": spec.margin_x,
                "top": spec.top,
                "max_text_height": spec.max_text_height,
                "line_spacing": spec.line_spacing,
                "panel_padding": spec.panel_padding,
                "panel_radius": spec.panel_radius,
                "text_color": spec.text_color,
                "panel_color": spec.panel_color,
            },
        }
        encoded = json.dumps(snapshot, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()

    def render_overlay(self, image_bytes: bytes, text: str, spec: RenderSpec | None = None) -> bytes:
        rendered, _ = self.render_overlay_with_metrics(image_bytes, text, spec)
        return rendered

    def render_overlay_with_metrics(
        self,
        image_bytes: bytes,
        text: str,
        spec: RenderSpec | None = None,
    ) -> tuple[bytes, dict[str, Any]]:
        if not image_bytes:
            raise ValueError("A real base image is required before Persian overlay rendering.")
        if not text.strip():
            raise ValueError("Overlay text must not be empty.")
        spec = spec or RenderSpec()
        payload = {
            "image_base64": base64.b64encode(image_bytes).decode("ascii"),
            "text": text,
            "spec": {
                "width": spec.width,
                "height": spec.height,
                "font_size": spec.font_size,
                "font_weight": spec.font_weight,
                "margin_x": spec.margin_x,
                "top": spec.top,
                "max_text_height": spec.max_text_height,
                "line_spacing": spec.line_spacing,
                "panel_padding": spec.panel_padding,
                "panel_radius": spec.panel_radius,
                "text_color": list(spec.text_color),
                "panel_color": list(spec.panel_color),
            },
            "include_metrics": True,
        }
        try:
            result = subprocess.run(
                [self.node_binary, str(self.script_path)],
                input=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                capture_output=True,
                check=False,
                timeout=45,
                env=self._environment(),
            )
        except subprocess.TimeoutExpired as exc:
            raise RendererNotReady("Skia renderer exceeded the 45-second render budget.") from exc
        except OSError as exc:
            raise RendererNotReady(f"Skia renderer could not start: {exc}") from exc

        if result.returncode != 0:
            detail = result.stderr.decode("utf-8", errors="replace").strip()
            if detail.startswith("TextOverflowError:"):
                raise TextOverflowError(detail.removeprefix("TextOverflowError:").strip())
            raise RendererNotReady(f"Skia renderer failed: {detail or result.returncode}")

        try:
            metrics = json.loads(result.stderr.decode("utf-8").strip())
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RendererNotReady("Skia renderer omitted or corrupted its layout metrics.") from exc
        if not result.stdout.startswith(b"\x89PNG\r\n\x1a\n"):
            raise RendererNotReady("Skia renderer did not return a PNG image.")
        return result.stdout, metrics

    def _environment(self) -> dict[str, str]:
        environment = os.environ.copy()
        local_modules = Path(__file__).resolve().parents[2] / "node_modules"
        module_roots = [item for item in (str(local_modules), environment.get("NODE_PATH", "")) if item]
        if module_roots:
            environment["NODE_PATH"] = os.pathsep.join(module_roots)
        return environment
