"use strict";

const fs = require("node:fs");
const path = require("node:path");
const {
  createCanvas,
  GlobalFonts,
  loadImage,
  version: canvasVersion,
} = require("@napi-rs/canvas");

const FONT_DIR = path.join(__dirname, "fonts");
const FONT_FILES = [
  ["noto-sans-arabic-arabic-400-normal.woff2", "Noto Sans Arabic"],
  ["noto-sans-arabic-arabic-700-normal.woff2", "Noto Sans Arabic"],
  ["noto-sans-arabic-latin-400-normal.woff2", "Noto Sans Latin"],
  ["noto-sans-arabic-latin-700-normal.woff2", "Noto Sans Latin"],
];

function registerFonts() {
  for (const [filename, family] of FONT_FILES) {
    const fontPath = path.join(FONT_DIR, filename);
    if (!fs.existsSync(fontPath)) throw new Error(`Renderer font is missing: ${fontPath}`);
    if (!GlobalFonts.registerFromPath(fontPath, family)) {
      throw new Error(`Could not register renderer font: ${fontPath}`);
    }
  }
}

function readStdin() {
  return new Promise((resolve, reject) => {
    const chunks = [];
    process.stdin.on("data", (chunk) => chunks.push(chunk));
    process.stdin.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    process.stdin.on("error", reject);
  });
}

function positiveInteger(value, name, min, max) {
  const number = Number(value);
  if (!Number.isInteger(number) || number < min || number > max) {
    throw new Error(`${name} must be an integer from ${min} to ${max}.`);
  }
  return number;
}

function rgba(value, name) {
  if (!Array.isArray(value) || value.length !== 4 || value.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) {
    throw new Error(`${name} must be an RGBA array with integer channels from 0 to 255.`);
  }
  return `rgba(${value[0]}, ${value[1]}, ${value[2]}, ${value[3] / 255})`;
}

function makeLines(ctx, text, maxWidth, font) {
  ctx.font = font;
  ctx.direction = "rtl";
  const lines = [];
  const paragraphs = String(text).replace(/\r\n?/g, "\n").split("\n");

  for (const paragraph of paragraphs) {
    const words = paragraph.trim().split(/\s+/u).filter(Boolean);
    if (!words.length) {
      lines.push({ text: "", width: 0, blank: true });
      continue;
    }

    let line = words[0];
    let width = ctx.measureText(line).width;
    if (width > maxWidth) throw new Error("TextOverflowError: One unbreakable token exceeds the safe width.");

    for (const word of words.slice(1)) {
      const candidate = `${line} ${word}`;
      const candidateWidth = ctx.measureText(candidate).width;
      if (candidateWidth <= maxWidth) {
        line = candidate;
        width = candidateWidth;
      } else {
        lines.push({ text: line, width, blank: false });
        const wordWidth = ctx.measureText(word).width;
        if (wordWidth > maxWidth) throw new Error("TextOverflowError: One unbreakable token exceeds the safe width.");
        line = word;
        width = wordWidth;
      }
    }
    lines.push({ text: line, width, blank: false });
  }
  return lines;
}

function buildRenderSpec(input) {
  const source = input.spec || {};
  const width = positiveInteger(source.width ?? 1080, "width", 64, 4096);
  const height = positiveInteger(source.height ?? 1350, "height", 64, 4096);
  const fontSize = positiveInteger(source.font_size ?? 58, "font_size", 8, 300);
  const marginX = positiveInteger(source.margin_x ?? 88, "margin_x", 0, Math.floor(Math.min(width, height) / 3));
  const top = positiveInteger(source.top ?? 130, "top", 0, height);
  const maxTextHeight = positiveInteger(source.max_text_height ?? 660, "max_text_height", 1, height);
  const lineSpacing = positiveInteger(source.line_spacing ?? 18, "line_spacing", 0, 200);
  const panelPadding = positiveInteger(source.panel_padding ?? 34, "panel_padding", 0, 300);
  const panelRadius = positiveInteger(source.panel_radius ?? 24, "panel_radius", 0, 300);
  const fontWeight = positiveInteger(source.font_weight ?? 400, "font_weight", 400, 700);
  if (![400, 700].includes(fontWeight)) throw new Error("font_weight must be either 400 or 700.");
  if (2 * marginX + 2 * panelPadding >= width) throw new Error("Horizontal safe area is too small for the panel padding.");
  return {
    width,
    height,
    fontSize,
    marginX,
    top,
    maxTextHeight,
    lineSpacing,
    panelPadding,
    panelRadius,
    fontWeight,
    textColor: rgba(source.text_color ?? [255, 255, 255, 255], "text_color"),
    panelColor: rgba(source.panel_color ?? [12, 18, 28, 168], "panel_color"),
  };
}

async function render(input) {
  if (!input || typeof input.image_base64 !== "string" || !input.image_base64.length) {
    throw new Error("A base64 PNG or JPEG source image is required.");
  }
  if (typeof input.text !== "string" || !input.text.trim()) throw new Error("Overlay text must not be empty.");

  const spec = buildRenderSpec(input);
  const canvas = createCanvas(spec.width, spec.height);
  const ctx = canvas.getContext("2d");
  const imageBytes = Buffer.from(input.image_base64, "base64");
  if (!imageBytes.length) throw new Error("Source image could not be decoded from base64.");
  const source = await loadImage(imageBytes);
  if (!source.width || !source.height) throw new Error("Source image has invalid dimensions.");

  // Cover-fit and center-crop; the unmodified base image remains a separate asset.
  const scale = Math.max(spec.width / source.width, spec.height / source.height);
  const cropWidth = spec.width / scale;
  const cropHeight = spec.height / scale;
  const cropX = (source.width - cropWidth) / 2;
  const cropY = (source.height - cropHeight) / 2;
  ctx.drawImage(source, cropX, cropY, cropWidth, cropHeight, 0, 0, spec.width, spec.height);

  const font = `${spec.fontWeight} ${spec.fontSize}px "Noto Sans Arabic", "Noto Sans Latin", sans-serif`;
  ctx.font = font;
  ctx.direction = "rtl";
  ctx.textAlign = "right";
  ctx.textBaseline = "alphabetic";
  const maxTextWidth = spec.width - 2 * spec.marginX - 2 * spec.panelPadding;
  const lines = makeLines(ctx, input.text, maxTextWidth, font);

  const layoutLines = lines.map((line) => {
    if (line.blank) {
      const step = Math.ceil(spec.fontSize * 0.8) + spec.lineSpacing;
      return { ...line, ascent: 0, descent: 0, lineHeight: step };
    }
    const metrics = ctx.measureText(line.text);
    const ascent = Math.ceil(metrics.actualBoundingBoxAscent || spec.fontSize * 0.85);
    const descent = Math.ceil(metrics.actualBoundingBoxDescent || spec.fontSize * 0.25);
    const lineHeight = Math.max(Math.ceil(spec.fontSize * 1.2), ascent + descent) + spec.lineSpacing;
    return { ...line, ascent, descent, lineHeight };
  });
  const textHeight = layoutLines.reduce((sum, line) => sum + line.lineHeight, 0) - spec.lineSpacing;
  const maxLineWidth = Math.max(0, ...layoutLines.map((line) => line.width));
  const panelWidth = maxLineWidth + 2 * spec.panelPadding;
  const panelRight = spec.width - spec.marginX;
  const panelLeft = panelRight - panelWidth;
  const panelBottom = spec.top + textHeight + 2 * spec.panelPadding;

  if (textHeight > spec.maxTextHeight) {
    throw new Error(`TextOverflowError: Text block needs ${textHeight}px but layout allows ${spec.maxTextHeight}px.`);
  }
  if (panelLeft < spec.marginX || panelBottom > spec.height - spec.marginX) {
    throw new Error("TextOverflowError: Text panel would cross the configured safe area.");
  }

  ctx.fillStyle = spec.panelColor;
  ctx.beginPath();
  ctx.roundRect(panelLeft, spec.top, panelWidth, panelBottom - spec.top, spec.panelRadius);
  ctx.fill();

  const baselinePositions = [];
  let cursorY = spec.top + spec.panelPadding;
  ctx.fillStyle = spec.textColor;
  for (const line of layoutLines) {
    if (!line.blank) {
      const baseline = cursorY + line.ascent;
      const left = panelRight - spec.panelPadding - line.width;
      const right = panelRight - spec.panelPadding;
      const bottom = baseline + line.descent;
      if (left < spec.marginX || right > spec.width - spec.marginX || bottom > spec.height - spec.marginX) {
        throw new Error("TextOverflowError: A rendered line would cross the configured safe area.");
      }
      ctx.fillText(line.text, right, baseline);
      baselinePositions.push({
        text: line.text,
        x: left,
        y: baseline - line.ascent,
        right,
        bottom,
        width: line.width,
      });
    }
    cursorY += line.lineHeight;
  }

  return {
    png: canvas.toBuffer("image/png"),
    metrics: {
      engine: "@napi-rs/canvas (Skia/HarfBuzz)",
      canvas: { width: spec.width, height: spec.height },
      safe_area: {
        left: spec.marginX,
        top: spec.marginX,
        right: spec.width - spec.marginX,
        bottom: spec.height - spec.marginX,
      },
      panel: { left: panelLeft, top: spec.top, right: panelRight, bottom: panelBottom },
      text_height: textHeight,
      line_count: baselinePositions.length,
      lines: baselinePositions,
    },
  };
}

async function main() {
  registerFonts();
  if (process.argv.includes("--probe")) {
    process.stdout.write(JSON.stringify({
      ready: true,
      renderer: "@napi-rs/canvas (Skia/HarfBuzz)",
      canvas_version: canvasVersion,
      node_version: process.version,
      font_families: ["Noto Sans Arabic", "Noto Sans Latin"],
    }));
    return;
  }

  const inputText = await readStdin();
  const input = JSON.parse(inputText);
  const result = await render(input);
  process.stdout.write(result.png);
  if (input.include_metrics) process.stderr.write(`${JSON.stringify(result.metrics)}\n`);
}

main().catch((error) => {
  process.stderr.write(`${error.message || String(error)}\n`);
  process.exitCode = 1;
});
