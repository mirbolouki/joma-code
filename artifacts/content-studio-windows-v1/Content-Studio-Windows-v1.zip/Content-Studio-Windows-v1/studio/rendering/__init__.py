"""Raster rendering adapters: Skia/HarfBuzz plus a fail-closed Pillow/RAQM alternate."""
