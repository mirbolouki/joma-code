from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps, features


class RendererNotReady(RuntimeError):
    pass


class TextOverflowError(ValueError):
    pass


@dataclass(frozen=True)
class RenderSpec:
    width: int = 1080
    height: int = 1350
    font_size: int = 58
    font_weight: int = 400
    margin_x: int = 88
    top: int = 130
    max_text_height: int = 660
    line_spacing: int = 18
    text_color: tuple[int, int, int, int] = (255, 255, 255, 255)
    panel_color: tuple[int, int, int, int] = (12, 18, 28, 168)
    panel_padding: int = 34
    panel_radius: int = 24


class PillowRaqmRenderer:
    """PNG compositor that refuses output unless Pillow's RAQM path is available."""

    def __init__(self, font_path: str | Path, bold_font_path: str | Path | None = None):
        self.font_path = Path(font_path)
        self.bold_font_path = Path(bold_font_path) if bold_font_path else None

    @staticmethod
    def raqm_available() -> bool:
        try:
            return bool(features.check_feature("raqm"))
        except (ValueError, AttributeError):
            return False

    def check_ready(self) -> None:
        if not self.raqm_available():
            raise RendererNotReady("Pillow RAQM is unavailable; do not create a final Persian raster.")
        required_fonts = [self.font_path, *([self.bold_font_path] if self.bold_font_path else [])]
        for font_path in required_fonts:
            if not font_path.is_file():
                raise RendererNotReady(f"Persian renderer font is missing: {font_path}")
            try:
                ImageFont.truetype(str(font_path), 24, layout_engine=ImageFont.Layout.RAQM)
            except Exception as exc:
                raise RendererNotReady(f"Configured font cannot be opened by RAQM: {exc}") from exc
    def render_overlay(self, image_bytes: bytes, text: str, spec: RenderSpec | None = None) -> bytes:
        self.check_ready()
        if not text.strip():
            raise ValueError("Overlay text must not be empty.")
        spec = spec or RenderSpec()
        if spec.width <= 0 or spec.height <= 0 or spec.font_size <= 0:
            raise ValueError("Canvas and font dimensions must be positive.")
        if spec.font_weight not in {400, 700}:
            raise ValueError("Font weight must be either 400 or 700.")
        font_path = self.bold_font_path if spec.font_weight == 700 and self.bold_font_path else self.font_path

        font = ImageFont.truetype(
            str(font_path),
            spec.font_size,
            layout_engine=ImageFont.Layout.RAQM,
        )
        with Image.open(BytesIO(image_bytes)) as opened:
            source = ImageOps.exif_transpose(opened).convert("RGBA")
            canvas = ImageOps.fit(
                source,
                (spec.width, spec.height),
                method=Image.Resampling.LANCZOS,
                centering=(0.5, 0.5),
            )

        draw = ImageDraw.Draw(canvas, "RGBA")
        max_width = spec.width - 2 * spec.margin_x - 2 * spec.panel_padding
        lines = self._wrap_text(text, font, max_width)
        rendered_text = "\n".join(lines)
        bbox = draw.multiline_textbbox(
            (0, 0),
            rendered_text,
            font=font,
            spacing=spec.line_spacing,
            align="right",
            direction="rtl",
            language="fa",
        )
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        if text_height > spec.max_text_height:
            raise TextOverflowError(
                f"Text block needs {text_height}px but layout allows {spec.max_text_height}px."
            )
        if text_width > max_width:
            raise TextOverflowError("A rendered line exceeds the configured safe width.")

        right = spec.width - spec.margin_x
        left = right - text_width - 2 * spec.panel_padding
        top = spec.top
        bottom = top + text_height + 2 * spec.panel_padding
        if left < spec.margin_x or bottom > spec.height - spec.margin_x:
            raise TextOverflowError("Text panel would cross the configured safe area.")
        draw.rounded_rectangle(
            (left, top, right, bottom),
            radius=spec.panel_radius,
            fill=spec.panel_color,
        )
        draw.multiline_text(
            (right - spec.panel_padding, top + spec.panel_padding),
            rendered_text,
            font=font,
            fill=spec.text_color,
            spacing=spec.line_spacing,
            align="right",
            anchor="ra",
            direction="rtl",
            language="fa",
        )

        output = BytesIO()
        canvas.convert("RGB").save(output, format="PNG", optimize=True)
        return output.getvalue()

    def _wrap_text(self, text: str, font: ImageFont.FreeTypeFont, max_width: int) -> list[str]:
        result: list[str] = []
        for paragraph in text.splitlines() or [text]:
            words = paragraph.split()
            if not words:
                result.append("")
                continue
            line = words[0]
            for word in words[1:]:
                candidate = f"{line} {word}"
                if self._text_width(font, candidate) <= max_width:
                    line = candidate
                else:
                    if self._text_width(font, word) > max_width:
                        raise TextOverflowError("One unbreakable token exceeds the text safe width.")
                    result.append(line)
                    line = word
            result.append(line)
        return result

    @staticmethod
    def _text_width(font: ImageFont.FreeTypeFont, text: str) -> float:
        return font.getlength(text, direction="rtl", language="fa")
