from django.db import models


class CapabilityStatus(models.TextChoices):
    VERIFIED = "verified", "تأییدشده با آزمون واقعی"
    AVAILABLE = "available", "قابل‌استفاده پس از پیکربندی"
    REQUIRES_PROVIDER = "requires_provider", "نیازمند provider"
    REQUIRES_DEPENDENCY = "requires_dependency", "نیازمند dependency"
    NOT_VERIFIED = "not_verified", "هنوز آزموده/اثبات نشده"
    NOT_AVAILABLE = "not_available", "در محیط جاری موجود نیست"


class PipelineStage(models.TextChoices):
    IDEA = "idea", "Idea"
    OPPORTUNITY_ANALYSIS = "opportunity_analysis", "Opportunity Analysis"
    RESEARCH_DECISION = "research_decision", "Research Decision"
    RESEARCH = "research", "Research"
    STRATEGY = "strategy", "Strategy"
    HOOK = "hook", "Hook"
    CONTENT_STRUCTURE = "content_structure", "Content Structure"
    PERSIAN_COPY = "persian_copy", "Persian Copy"
    VISUAL_DIRECTION = "visual_direction", "Visual Direction"
    IMAGE_GENERATION = "image_generation", "Real Image Generation"
    PERSIAN_OVERLAY = "persian_overlay", "Persian Text Overlay"
    LAYOUT = "layout", "Layout"
    PREVIEW = "preview", "Preview"
    PLATFORM_COMPLIANCE = "platform_compliance", "Platform Compliance"
    PLATFORM_BEST_PRACTICES = "platform_best_practices", "Platform Best Practices"
    CREATIVE_QUALITY = "creative_quality", "Creative Quality"
    FINAL_ASSETS = "final_assets", "Final Assets"
    MANIFEST = "manifest", "Manifest"
    ZIP = "zip", "ZIP"


class RunStatus(models.TextChoices):
    PENDING = "pending", "در انتظار"
    RUNNING = "running", "در حال اجرا"
    COMPLETED = "completed", "کامل‌شده"
    BLOCKED = "blocked", "متوقف به‌علت وابستگی"
    FAILED = "failed", "ناموفق"
    NOT_RUN = "not_run", "اجرا نشده"


class ProjectStatus(models.TextChoices):
    DRAFT = "draft", "پیش‌نویس"
    IN_PROGRESS = "in_progress", "در حال ساخت"
    BLOCKED = "blocked", "مسدود تا رفع وابستگی"
    NEEDS_REVIEW = "needs_review", "نیازمند بازبینی انسانی"
    READY = "ready", "آمادهٔ تحویل"
    COMPLETED = "completed", "تحویل‌شده"


class FormatChoice(models.TextChoices):
    AUTO = "auto", "پیشنهاد خودکار"
    CAROUSEL = "carousel", "Carousel"
    REEL = "reel", "Reel"
    STORY = "story", "Story"
    SINGLE_POST = "single_post", "Single Post"


class ResearchLevel(models.TextChoices):
    NONE = "none", "بدون جست‌وجوی بیرونی"
    LIGHT = "light", "بررسی محدود"
    REQUIRED = "required", "پژوهش لازم است"


class ResearchSourceStatus(models.TextChoices):
    UNREVIEWED = "unreviewed", "بررسی‌نشده"
    REVIEWED = "reviewed", "بازبینی‌شده"
    REJECTED = "rejected", "ردشده"


class ClaimType(models.TextChoices):
    FACTUAL = "factual", "واقعی/قابل‌بررسی"
    SCIENTIFIC = "scientific", "علمی"
    MEDICAL = "medical", "پزشکی"
    PSYCHOLOGICAL = "psychological", "روان‌شناختی"
    STATISTICAL = "statistical", "آماری"
    PROMOTIONAL = "promotional", "تبلیغاتی"
    OPINION = "opinion", "نظر/برداشت"
    CREATIVE = "creative", "محتوای خلاقه"
    GENERAL_ADVICE = "general_advice", "توصیهٔ عمومی/غیرتجربی"


class ClaimStatus(models.TextChoices):
    DRAFT = "draft", "پیش‌نویس"
    SUPPORTED = "supported", "پشتیبانی‌شده با منبع بازبینی‌شده"
    REVIEWED_NONFACTUAL = "reviewed_nonfactual", "بازبینی‌شده؛ منبع لازم نیست"
    DISPUTED = "disputed", "دارای تعارض منبع"
    REJECTED = "rejected", "ردشده"


class ClaimSourceRelation(models.TextChoices):
    SUPPORTS = "supports", "پشتیبانی می‌کند"
    CONTRADICTS = "contradicts", "در تعارض است"
    CONTEXT = "context", "زمینه/توضیح"


class MemoryKind(models.TextChoices):
    TOPIC = "topic", "موضوع"
    ANGLE = "angle", "زاویهٔ روایت"
    HOOK = "hook", "Hook"
    STRUCTURE = "structure", "ساختار"
    FORMAT = "format", "فرمت"
    FEEDBACK = "feedback", "بازخورد"


class MemoryStatus(models.TextChoices):
    DRAFT = "draft", "پیش‌نویس"
    APPROVED = "approved", "تأییدشده برای حافظه"
    PUBLISHED = "published", "منتشرشده"


class ArtifactProvenance(models.TextChoices):
    USER_INPUT = "user_input", "ورودی کاربر"
    PROVIDER_OUTPUT = "provider_output", "خروجی provider واقعی"
    SYSTEM_GENERATED = "system_generated", "تولیدشده با منطق سیستم"
    MANUAL_REVIEW = "manual_review", "بازبینی انسانی"
    TEST_FIXTURE = "test_fixture", "دادهٔ آزمایشی محلی (TEST_ONLY)"


class AssetKind(models.TextChoices):
    IMAGE_PLAIN = "image_plain", "تصویر پایهٔ بی‌متن"
    IMAGE_FINAL = "image_final", "تصویر نهایی با متن"
    PREVIEW = "preview", "پیش‌نمایش"
    ZIP = "zip", "بستهٔ ZIP"


class AssetRightsBasis(models.TextChoices):
    OWNED = "owned", "ساخته/متعلق به بارگذار"
    LICENSED = "licensed", "دارای مجوز استفاده"
    PUBLIC_DOMAIN = "public_domain", "مالکیت عمومی"
    OTHER = "other", "مبنای دیگر"


class QualityAxis(models.TextChoices):
    PLATFORM_COMPLIANCE = "platform_compliance", "Platform Compliance"
    PLATFORM_BEST_PRACTICES = "platform_best_practices", "Platform Best Practices"
    CREATIVE_QUALITY = "creative_quality", "Creative Quality"


class QualityStatus(models.TextChoices):
    NOT_RUN = "not_run", "اجرا نشده"
    REQUIRES_PROVIDER = "requires_provider", "نیازمند provider"
    MANUAL_REVIEW = "manual_review", "بازبینی انسانی ثبت‌شده"
    PASS = "pass", "قبول"
    FAIL = "fail", "رد"
