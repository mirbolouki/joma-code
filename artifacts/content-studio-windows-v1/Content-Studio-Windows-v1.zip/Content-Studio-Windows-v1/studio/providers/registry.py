from django.conf import settings

from .exceptions import ProviderAdapterUnavailable, ProviderNotConfigured

# Concrete adapters are intentionally absent until cost, quality, limits, privacy,
# retention and usage terms have been reviewed and the owner approves activation.
_ADAPTERS: dict[str, dict[str, object]] = {"llm": {}, "search": {}, "image": {}}
_SETTINGS = {
    "llm": "STUDIO_LLM_PROVIDER",
    "search": "STUDIO_SEARCH_PROVIDER",
    "image": "STUDIO_IMAGE_PROVIDER",
}


def register_adapter(capability: str, provider_id: str, factory: object) -> None:
    if capability not in _ADAPTERS:
        raise ValueError(f"Unknown provider capability: {capability}")
    _ADAPTERS[capability][provider_id] = factory


def get_provider(capability: str):
    setting_name = _SETTINGS.get(capability)
    if setting_name is None:
        raise ValueError(f"Unknown provider capability: {capability}")
    provider_id = getattr(settings, setting_name, "")
    if not provider_id:
        raise ProviderNotConfigured(capability)
    factory = _ADAPTERS[capability].get(provider_id)
    if factory is None:
        raise ProviderAdapterUnavailable(capability, provider_id)
    return factory()


def get_text_provider():
    return get_provider("llm")


def get_search_provider():
    return get_provider("search")


def get_image_provider():
    return get_provider("image")
