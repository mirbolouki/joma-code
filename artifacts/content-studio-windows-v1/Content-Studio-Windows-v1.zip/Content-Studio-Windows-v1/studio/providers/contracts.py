from dataclasses import dataclass
from typing import Any, Mapping, Protocol, Sequence


@dataclass(frozen=True)
class SearchResult:
    url: str
    title: str
    snippet: str = ""
    publisher: str = ""


@dataclass(frozen=True)
class FetchedPage:
    url: str
    title: str
    text: str
    publisher: str = ""
    author: str = ""
    published_at: str | None = None
    retrieved_at: str | None = None


@dataclass(frozen=True)
class GeneratedImage:
    content: bytes
    mime_type: str
    width: int
    height: int
    provider_id: str
    model_name: str
    provider_request_id: str | None = None


class TextProvider(Protocol):
    provider_id: str
    model_name: str

    def generate_structured(self, *, stage: str, payload: Mapping[str, Any]) -> Mapping[str, Any]: ...


class SearchProvider(Protocol):
    provider_id: str

    def search(self, query: str) -> Sequence[SearchResult]: ...

    def fetch(self, url: str) -> FetchedPage: ...


class ImageProvider(Protocol):
    provider_id: str
    model_name: str

    def generate_image(
        self,
        *,
        prompt: str,
        negative_prompt: str,
        width: int,
        height: int,
        reference_images: Sequence[bytes] = (),
    ) -> GeneratedImage: ...
