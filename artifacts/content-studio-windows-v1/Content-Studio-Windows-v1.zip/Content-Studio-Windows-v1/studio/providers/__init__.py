"""Provider ports and a fail-closed registry; no real provider is enabled by default."""
