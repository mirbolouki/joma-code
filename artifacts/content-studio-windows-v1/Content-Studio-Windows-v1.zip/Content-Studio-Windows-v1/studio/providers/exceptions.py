class ProviderError(RuntimeError):
    """Base class for provider configuration or call failures."""


class ProviderNotConfigured(ProviderError):
    def __init__(self, capability: str):
        self.capability = capability
        super().__init__(f"{capability} provider is not configured or approved.")


class ProviderAdapterUnavailable(ProviderError):
    def __init__(self, capability: str, provider_id: str):
        self.capability = capability
        self.provider_id = provider_id
        super().__init__(f"No implemented adapter is registered for {capability}: {provider_id}.")
