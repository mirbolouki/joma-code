from django.urls import path

from . import views

app_name = "studio"
urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("projects/<uuid:project_id>/", views.project_detail, name="project_detail"),
    path("projects/<uuid:project_id>/research-decision/", views.save_research_decision, name="save_research_decision"),
    path("projects/<uuid:project_id>/sources/", views.add_research_source, name="add_research_source"),
    path("projects/<uuid:project_id>/claims/", views.add_content_claim, name="add_content_claim"),
    path("projects/<uuid:project_id>/claim-sources/", views.link_claim_source, name="link_claim_source"),
    path("projects/<uuid:project_id>/slides/", views.add_carousel_slide, name="add_carousel_slide"),
    path("projects/<uuid:project_id>/claim-slides/", views.link_claim_to_slide, name="link_claim_to_slide"),
    path("projects/<uuid:project_id>/manual-stage/", views.record_manual_stage_input, name="record_manual_stage_input"),
    path("projects/<uuid:project_id>/quality/<slug:axis>/", views.record_quality_review, name="record_quality_review"),
    path("projects/<uuid:project_id>/slides/<int:slide_id>/image/", views.upload_slide_base_image, name="upload_slide_base_image"),
    path("projects/<uuid:project_id>/slides/<int:slide_id>/render/", views.render_slide_asset, name="render_slide_asset"),
    path("projects/<uuid:project_id>/assets/<int:asset_id>/preview/", views.preview_final_asset, name="preview_final_asset"),
    path("projects/<uuid:project_id>/run/", views.retry_pipeline, name="retry_pipeline"),
    path("projects/<uuid:project_id>/export.zip", views.download_project_zip, name="download_project_zip"),
]
