from celery import shared_task

from studio.services.workflow import start_or_resume_project


@shared_task(bind=True, acks_late=True, reject_on_worker_lost=True)
def start_project_pipeline(self, project_id: str) -> dict[str, str]:
    result = start_or_resume_project(project_id)
    return {
        "project_id": result.project_id,
        "stage": result.stage,
        "status": result.status,
        "capability_status": result.capability_status,
        "message": result.message,
    }
