from __future__ import annotations

import hashlib
import io
import json

from django.conf import settings
from django.db import transaction
from django.utils import timezone

from studio.enums import (
    ArtifactProvenance,
    AssetKind,
    AssetRightsBasis,
    PipelineStage,
    ProjectStatus,
    QualityAxis,
    QualityStatus,
)
from studio.models import Project, ProjectArtifact, QualityReport, ResearchDecision

AXES = (
    QualityAxis.PLATFORM_COMPLIANCE,
    QualityAxis.PLATFORM_BEST_PRACTICES,
    QualityAxis.CREATIVE_QUALITY,
)

_AXIS_STAGE = {
    QualityAxis.PLATFORM_COMPLIANCE: PipelineStage.PLATFORM_COMPLIANCE,
    QualityAxis.PLATFORM_BEST_PRACTICES: PipelineStage.PLATFORM_BEST_PRACTICES,
    QualityAxis.CREATIVE_QUALITY: PipelineStage.CREATIVE_QUALITY,
}


def _text_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def quality_subject_hash(project: Project) -> str:
    """Fingerprint all creative, provenance, and raster inputs a human QA reviewed."""
    brand = project.brand
    slides = []
    for slide in project.slides.order_by("position"):
        slide_assets = []
        for asset in project.assets.filter(
            slide=slide,
            kind__in=(AssetKind.IMAGE_PLAIN, AssetKind.PREVIEW, AssetKind.IMAGE_FINAL),
        ).order_by("kind", "created_at"):
            slide_assets.append(
                {
                    "kind": asset.kind,
                    "sha256": asset.sha256,
                    "render_input_hash": asset.render_input_hash,
                    "provenance": asset.provenance,
                    "provider_id": asset.provider_id,
                    "model_name": asset.model_name,
                    "mime_type": asset.mime_type,
                    "width": asset.width,
                    "height": asset.height,
                    "byte_size": asset.byte_size,
                    "is_private": asset.is_private,
                    "rights_basis": asset.rights_basis,
                    "rights_note": asset.rights_note,
                    "rights_source_url": asset.rights_source_url,
                    "rights_confirmed_by_id": asset.rights_confirmed_by_id,
                    "rights_confirmed_at": asset.rights_confirmed_at.isoformat() if asset.rights_confirmed_at else None,
                }
            )
        slides.append(
            {
                "position": slide.position,
                "role": slide.role,
                "copy_text": slide.copy_text,
                "visual_direction": slide.visual_direction,
                "image_prompt": slide.image_prompt,
                "layout": slide.layout,
                "assets": slide_assets,
                "claim_links": [
                    {
                        "claim_key": link.claim.key,
                        "copy_excerpt_hash": _text_hash(link.copy_excerpt),
                        "reviewed_content_hash": link.reviewed_content_hash,
                    }
                    for link in slide.claim_links.select_related("claim").order_by("claim__key", "pk")
                ],
            }
        )

    claims = []
    for claim in project.claims.order_by("key"):
        claims.append(
            {
                "key": claim.key,
                "current_content_hash": claim.current_content_hash(),
                "reviewed_content_hash": claim.reviewed_content_hash,
                "status": claim.status,
                "source_links": [
                    {
                        "relation": link.relation,
                        "evidence_excerpt_hash": _text_hash(link.evidence_excerpt),
                        "reviewed_content_hash": link.reviewed_content_hash,
                        "source_content_hash": link.source.current_content_hash(),
                        "source_review_status": link.source.review_status,
                    }
                    for link in claim.source_links.select_related("source").order_by("source__url", "pk")
                ],
            }
        )

    source_snapshot = [
        {
            "url": source.url,
            "current_content_hash": source.current_content_hash(),
            "reviewed_content_hash": source.reviewed_content_hash,
            "review_status": source.review_status,
        }
        for source in project.research_sources.order_by("url")
    ]
    brand_snapshot = {
        "name": brand.name,
        "description": brand.description,
        "audience": brand.audience,
        "tone_guidelines": brand.tone_guidelines,
        "content_pillars": brand.content_pillars,
        "approved_claims": brand.approved_claims,
        "prohibited_claims": brand.prohibited_claims,
    }
    try:
        decision = project.research_decision
    except ResearchDecision.DoesNotExist:
        decision = None
    decision_snapshot = (
        {
            "level": decision.level,
            "rationale": decision.rationale,
            "claim_types": decision.claim_types,
            "test_only": decision.test_only,
            "confirmed_by_id": decision.confirmed_by_id,
            "confirmed_at": decision.confirmed_at.isoformat() if decision.confirmed_at else None,
        }
        if decision
        else None
    )
    snapshot = {
        "project_id": str(project.pk),
        "idea_sha256": _text_hash(project.idea),
        "requested_format": project.requested_format,
        "selected_format": project.selected_format,
        "project_test_only": project.test_only,
        "research_decision": decision_snapshot,
        "brand_sha256": _text_hash(json.dumps(brand_snapshot, sort_keys=True, ensure_ascii=False, separators=(",", ":"))),
        "slides": slides,
        "claims": claims,
        "sources": source_snapshot,
    }
    encoded = json.dumps(snapshot, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def quality_input_blockers(project: Project, store=None) -> list[str]:
    """Require the same private, hash-checked raster files before any QA result is recorded."""
    from PIL import Image, UnidentifiedImageError

    from studio.rendering.pillow_raqm import RenderSpec
    from studio.rendering.skia_canvas import RendererNotReady, SkiaCanvasRenderer
    from studio.storage import PrivateLocalStore

    store = store or PrivateLocalStore()
    slides = list(project.slides.order_by("position"))
    blockers: list[str] = []
    if not 5 <= len(slides) <= 7:
        blockers.append("QA برای تحویل فقط روی Carousel دارای ۵ تا ۷ اسلاید اجرا می‌شود.")
    renderer = SkiaCanvasRenderer()

    for slide in slides:
        by_kind = {
            kind: list(project.assets.filter(slide=slide, kind=kind).order_by("created_at"))
            for kind in (AssetKind.IMAGE_PLAIN, AssetKind.PREVIEW, AssetKind.IMAGE_FINAL)
        }
        if any(len(assets) != 1 for assets in by_kind.values()):
            blockers.append(f"اسلاید {slide.position}: برای QA دقیقاً یک base، preview و final لازم است.")
            continue
        content_by_kind = {}
        for kind, assets in by_kind.items():
            asset = assets[0]
            if not asset.is_private or not store.exists(asset.storage_key):
                blockers.append(f"اسلاید {slide.position}: فایل خصوصی {kind} در دسترس نیست.")
                continue
            try:
                content = store.read(asset.storage_key)
            except (OSError, ValueError):
                blockers.append(f"اسلاید {slide.position}: فایل {kind} خوانده نشد.")
                continue
            digest = hashlib.sha256(content).hexdigest()
            if digest != asset.sha256 or len(content) != asset.byte_size:
                blockers.append(f"اسلاید {slide.position}: integrity فایل {kind} تأیید نشد.")
                continue
            expected_format = {"image/png": "PNG", "image/jpeg": "JPEG"}.get(asset.mime_type)
            if not expected_format:
                blockers.append(f"اسلاید {slide.position}: MIME تصویر {kind} مجاز نیست.")
                continue
            try:
                with Image.open(io.BytesIO(content)) as image:
                    if image.format != expected_format or image.size != (asset.width, asset.height):
                        blockers.append(f"اسلاید {slide.position}: ابعاد/فرمت فایل {kind} با metadata تطابق ندارد.")
                        continue
                    image.verify()
            except (
                OSError,
                ValueError,
                Image.DecompressionBombError,
                Image.DecompressionBombWarning,
                UnidentifiedImageError,
            ):
                blockers.append(f"اسلاید {slide.position}: فایل {kind} تصویر سالمی نیست.")
                continue
            content_by_kind[kind] = content

        base = by_kind[AssetKind.IMAGE_PLAIN][0]
        if base.provenance == ArtifactProvenance.PROVIDER_OUTPUT:
            if not (base.provider_id and base.model_name):
                blockers.append(f"اسلاید {slide.position}: تصویر provider شناسه/مدل ندارد.")
        elif base.provenance == ArtifactProvenance.USER_INPUT:
            if not (
                base.rights_basis in AssetRightsBasis.values
                and base.rights_note.strip()
                and base.rights_confirmed_by_id
                and base.rights_confirmed_at
            ):
                blockers.append(f"اسلاید {slide.position}: تصویر دستی تأیید حقوق استفاده ندارد.")
        elif base.provenance == ArtifactProvenance.TEST_FIXTURE:
            if not settings.STUDIO_TEST_MODE:
                blockers.append(f"اسلاید {slide.position}: تصویر TEST_FIXTURE فقط در test mode مجاز است.")
        else:
            blockers.append(f"اسلاید {slide.position}: منشأ تصویر پایه مشخص نیست.")

        final = by_kind[AssetKind.IMAGE_FINAL][0]
        preview = by_kind[AssetKind.PREVIEW][0]
        spec = RenderSpec()
        for rendered in (final, preview):
            if rendered.provenance != ArtifactProvenance.SYSTEM_GENERATED:
                blockers.append(f"اسلاید {slide.position}: فایل {rendered.kind} منشأ Renderer سیستمی ندارد.")
            if (rendered.width, rendered.height) != (spec.width, spec.height):
                blockers.append(f"اسلاید {slide.position}: ابعاد {rendered.kind} با قالب رندر مطابقت ندارد.")
        if AssetKind.IMAGE_FINAL in content_by_kind and AssetKind.PREVIEW in content_by_kind:
            if content_by_kind[AssetKind.IMAGE_FINAL] != content_by_kind[AssetKind.PREVIEW]:
                blockers.append(f"اسلاید {slide.position}: preview با بایت‌های final یکسان نیست.")
        if final.render_input_hash != preview.render_input_hash:
            blockers.append(f"اسلاید {slide.position}: fingerprint preview/final متفاوت است.")
        try:
            current_hash = renderer.render_input_hash(base.sha256, slide.copy_text, RenderSpec())
        except (OSError, ValueError, RendererNotReady):
            blockers.append(f"اسلاید {slide.position}: snapshot ورودی Renderer قابل محاسبه نیست.")
        else:
            if final.render_input_hash != current_hash or preview.render_input_hash != current_hash:
                blockers.append(f"اسلاید {slide.position}: render با متن/تصویر فعلی منطبق نیست.")
    return blockers


@transaction.atomic
def ensure_initial_quality_reports(project: Project) -> list[QualityReport]:
    """Create independent, honest `not_run` records; never manufacture a pass."""
    reports = []
    for axis in AXES:
        report, _ = QualityReport.objects.get_or_create(
            project=project,
            axis=axis,
            version=1,
            defaults={
                "status": QualityStatus.NOT_RUN,
                "findings": [],
                "blockers": ["این بررسی هنوز روی محتوای واقعی اجرا نشده است."],
            },
        )
        reports.append(report)
    return reports


@transaction.atomic
def invalidate_quality_reports(project: Project, reason: str) -> None:
    """Preserve completed QA history while making the current inputs explicitly not-run."""
    if project.status in {ProjectStatus.READY, ProjectStatus.COMPLETED}:
        project.status = ProjectStatus.NEEDS_REVIEW
        project.save(update_fields=["status", "updated_at"])
    for axis in AXES:
        latest = project.quality_reports.filter(axis=axis).order_by("-version").first()
        if latest and latest.status == QualityStatus.NOT_RUN and not latest.reviewed_by_id and not latest.reviewed_at:
            latest.findings = []
            latest.blockers = [reason]
            latest.reviewed_content_hash = ""
            latest.save(update_fields=["findings", "blockers", "reviewed_content_hash", "updated_at"])
            continue
        QualityReport.objects.create(
            project=project,
            axis=axis,
            version=(latest.version + 1) if latest else 1,
            status=QualityStatus.NOT_RUN,
            findings=[],
            blockers=[reason],
        )


@transaction.atomic
def record_human_quality_review(
    project: Project,
    axis: str,
    data: dict,
    reviewer,
    *,
    test_only: bool = False,
) -> QualityReport:
    if axis not in AXES:
        raise ValueError("Unknown quality axis.")
    if test_only and not settings.STUDIO_TEST_MODE:
        raise ValueError("TEST_ONLY QA is disabled outside the test environment.")
    latest = project.quality_reports.filter(axis=axis).order_by("-version").first()
    version = (latest.version + 1) if latest else 1
    reviewed_at = timezone.now()
    snapshot_hash = quality_subject_hash(project)
    report = QualityReport.objects.create(
        project=project,
        axis=axis,
        status=data["status"],
        version=version,
        findings=data["findings"],
        blockers=data["blockers"],
        source_urls=data["source_urls"],
        policy_pack_id=data["policy_pack_id"],
        policy_pack_version=data["policy_pack_version"],
        provider_id="",
        model_name="",
        reviewed_content_hash=snapshot_hash,
        test_only=test_only,
        reviewed_by=reviewer,
        reviewed_at=reviewed_at,
    )
    ProjectArtifact.objects.create(
        project=project,
        stage=_AXIS_STAGE[axis],
        artifact_type="human_quality_review",
        version=version,
        payload={
            "axis": axis,
            "status": report.status,
            "findings": report.findings,
            "blockers": report.blockers,
            "source_urls": report.source_urls,
            "policy_pack_id": report.policy_pack_id,
            "policy_pack_version": report.policy_pack_version,
            "reviewed_content_hash": snapshot_hash,
            "provider_called": False,
            "review_method": "TEST_ONLY" if test_only else "human_form",
            "test_only": test_only,
        },
        provenance=ArtifactProvenance.TEST_FIXTURE if test_only else ArtifactProvenance.MANUAL_REVIEW,
        source_urls=report.source_urls,
    )
    return report


def final_delivery_blockers(project: Project) -> list[str]:
    """Fail closed unless each independent QA axis has a current, traceable human result."""
    blockers: list[str] = []
    latest_by_axis: dict[str, QualityReport] = {}
    for report in project.quality_reports.all().order_by("axis", "-version"):
        latest_by_axis.setdefault(report.axis, report)

    current_snapshot_hash = None
    for axis in AXES:
        report = latest_by_axis.get(axis)
        if report is None:
            blockers.append(f"گزارش مستقل {axis} وجود ندارد.")
            continue
        if report.test_only and not settings.STUDIO_TEST_MODE:
            blockers.append(f"محور {axis} برچسب TEST_ONLY دارد و در محیط غیرآزمایشی قابل تحویل نیست.")
            continue
        if report.status != QualityStatus.PASS:
            blockers.append(f"محور {axis} هنوز نتیجهٔ PASS انسانی نگرفته است.")
            continue
        if report.blockers:
            blockers.append(f"گزارش محور {axis} هنوز blocker باز دارد.")
        if not (report.reviewed_by_id and report.reviewed_at):
            blockers.append(f"بازبینی انسانی محور {axis} فاقد هویت یا زمان ثبت‌شده است.")
        if current_snapshot_hash is None:
            current_snapshot_hash = quality_subject_hash(project)
        if report.reviewed_content_hash != current_snapshot_hash:
            blockers.append(f"محور {axis} پس از آخرین تغییر محتوا/تصویر بازبینی نشده است.")

        if axis == QualityAxis.PLATFORM_COMPLIANCE:
            if not (report.policy_pack_id and report.policy_pack_version):
                blockers.append("Platform Compliance فاقد نسخهٔ policy pack است.")
            if not report.test_only and not report.source_urls:
                blockers.append("Platform Compliance فاقد منبع رسمی قابل‌ردیابی است.")
        elif axis == QualityAxis.PLATFORM_BEST_PRACTICES:
            if not (report.policy_pack_id and report.policy_pack_version):
                blockers.append("Platform Best Practices فاقد نسخهٔ قواعد قابل‌ردیابی است.")
    return blockers
