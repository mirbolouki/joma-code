import hashlib
import uuid

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator
from django.db import models

from .enums import (
    ArtifactProvenance,
    AssetKind,
    AssetRightsBasis,
    CapabilityStatus,
    ClaimSourceRelation,
    ClaimStatus,
    ClaimType,
    FormatChoice,
    MemoryKind,
    MemoryStatus,
    PipelineStage,
    ProjectStatus,
    QualityAxis,
    QualityStatus,
    ResearchLevel,
    ResearchSourceStatus,
    RunStatus,
)


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class BrandProfile(TimeStampedModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    slug = models.SlugField(max_length=80, unique=True)
    name = models.CharField(max_length=160)
    description = models.TextField(blank=True)
    audience = models.TextField(blank=True)
    tone_guidelines = models.TextField(blank=True)
    content_pillars = models.JSONField(default=list, blank=True)
    approved_claims = models.JSONField(default=list, blank=True)
    prohibited_claims = models.JSONField(default=list, blank=True)
    source_notes = models.JSONField(default=list, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name", "slug"]
        verbose_name = "Brand Profile"
        verbose_name_plural = "Brand Profiles"

    def __str__(self) -> str:
        return self.name


class Project(TimeStampedModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    brand = models.ForeignKey(BrandProfile, on_delete=models.PROTECT, related_name="projects")
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="studio_projects",
    )
    idea = models.TextField()
    requested_format = models.CharField(max_length=24, choices=FormatChoice.choices, default=FormatChoice.AUTO)
    selected_format = models.CharField(max_length=24, choices=FormatChoice.choices, blank=True)
    test_only = models.BooleanField(default=False)
    status = models.CharField(max_length=24, choices=ProjectStatus.choices, default=ProjectStatus.DRAFT)
    current_stage = models.CharField(max_length=32, choices=PipelineStage.choices, default=PipelineStage.IDEA)
    version = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["brand", "-created_at"]), models.Index(fields=["status", "current_stage"])]
        verbose_name = "Project"
        verbose_name_plural = "Projects"

    def __str__(self) -> str:
        return f"{self.brand.slug}: {self.idea[:60]}"


class StageRun(TimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="stage_runs")
    stage = models.CharField(max_length=32, choices=PipelineStage.choices)
    status = models.CharField(max_length=16, choices=RunStatus.choices, default=RunStatus.NOT_RUN)
    capability_status = models.CharField(
        max_length=32,
        choices=CapabilityStatus.choices,
        default=CapabilityStatus.NOT_VERIFIED,
    )
    message = models.TextField(blank=True)
    details = models.JSONField(default=dict, blank=True)
    attempt = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    finished_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["created_at", "stage", "attempt"]
        constraints = [
            models.UniqueConstraint(fields=["project", "stage", "attempt"], name="unique_project_stage_attempt")
        ]
        indexes = [models.Index(fields=["project", "stage", "status"])]

    def __str__(self) -> str:
        return f"{self.project_id} — {self.get_stage_display()} ({self.status})"


class ProjectArtifact(TimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="artifacts")
    stage = models.CharField(max_length=32, choices=PipelineStage.choices)
    artifact_type = models.CharField(max_length=80)
    version = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    payload = models.JSONField(default=dict)
    provenance = models.CharField(max_length=24, choices=ArtifactProvenance.choices)
    provider_id = models.CharField(max_length=80, blank=True)
    model_name = models.CharField(max_length=120, blank=True)
    source_urls = models.JSONField(default=list, blank=True)

    class Meta:
        ordering = ["stage", "artifact_type", "-version"]
        constraints = [
            models.UniqueConstraint(
                fields=["project", "stage", "artifact_type", "version"],
                name="unique_project_artifact_version",
            )
        ]

    def __str__(self) -> str:
        return f"{self.project_id}: {self.artifact_type} v{self.version}"


class ResearchDecision(TimeStampedModel):
    project = models.OneToOneField(Project, on_delete=models.CASCADE, related_name="research_decision")
    level = models.CharField(max_length=12, choices=ResearchLevel.choices)
    rationale = models.TextField()
    claim_types = models.JSONField(default=list, blank=True)
    test_only = models.BooleanField(default=False)
    confirmed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="confirmed_research_decisions",
    )
    confirmed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self) -> str:
        return f"{self.project_id}: {self.get_level_display()}"


class ResearchSource(TimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="research_sources")
    url = models.URLField(max_length=2048)
    title = models.CharField(max_length=500, blank=True)
    publisher = models.CharField(max_length=200, blank=True)
    author = models.CharField(max_length=200, blank=True)
    published_at = models.DateField(null=True, blank=True)
    accessed_at = models.DateTimeField(null=True, blank=True)
    excerpt = models.TextField(blank=True)
    review_status = models.CharField(
        max_length=16,
        choices=ResearchSourceStatus.choices,
        default=ResearchSourceStatus.UNREVIEWED,
    )
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="reviewed_research_sources",
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)
    reviewed_content_hash = models.CharField(max_length=64, blank=True, editable=False)

    class Meta:
        ordering = ["-accessed_at", "title"]

    @staticmethod
    def _hash_content(
        project_id,
        url: str,
        title: str,
        publisher: str,
        author: str,
        published_at,
        excerpt: str,
    ) -> str:
        content = "\0".join(
            (
                str(project_id or ""),
                url or "",
                title or "",
                publisher or "",
                author or "",
                published_at.isoformat() if published_at else "",
                excerpt or "",
            )
        )
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def current_content_hash(self) -> str:
        return self._hash_content(
            self.project_id,
            self.url,
            self.title,
            self.publisher,
            self.author,
            self.published_at,
            self.excerpt,
        )

    def save(self, *args, **kwargs):
        current_hash = self.current_content_hash()
        previous_hash = None
        if self.pk:
            previous_hash = type(self).objects.filter(pk=self.pk).values_list("reviewed_content_hash", flat=True).first()
        content_changed = previous_hash is not None and previous_hash != current_hash
        if content_changed:
            self.review_status = ResearchSourceStatus.UNREVIEWED
            self.reviewed_by_id = None
            self.reviewed_at = None
        self.reviewed_content_hash = current_hash

        if kwargs.get("update_fields") is not None:
            update_fields = set(kwargs["update_fields"]) | {"reviewed_content_hash"}
            if content_changed:
                update_fields.update(
                    {
                        "project",
                        "url",
                        "title",
                        "publisher",
                        "author",
                        "published_at",
                        "excerpt",
                        "review_status",
                        "reviewed_by",
                        "reviewed_at",
                    }
                )
            kwargs["update_fields"] = update_fields
        return super().save(*args, **kwargs)

    def __str__(self) -> str:
        return self.title or self.url


class ContentClaim(TimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="claims")
    key = models.SlugField(max_length=100)
    text = models.TextField()
    claim_type = models.CharField(max_length=24, choices=ClaimType.choices, default=ClaimType.FACTUAL)
    requires_source = models.BooleanField(default=True)
    source_requirement_reason = models.TextField(blank=True)
    status = models.CharField(max_length=24, choices=ClaimStatus.choices, default=ClaimStatus.DRAFT)
    rationale = models.TextField(blank=True)
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="reviewed_content_claims",
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)
    reviewed_content_hash = models.CharField(max_length=64, blank=True, editable=False)

    class Meta:
        ordering = ["created_at", "key"]
        constraints = [
            models.UniqueConstraint(fields=["project", "key"], name="unique_project_claim_key")
        ]

    @staticmethod
    def _hash_content(
        key: str,
        text: str,
        claim_type: str,
        requires_source: bool,
        source_requirement_reason: str,
        rationale: str,
    ) -> str:
        content = "\0".join(
            (
                key or "",
                text or "",
                claim_type or "",
                str(requires_source),
                source_requirement_reason or "",
                rationale or "",
            )
        )
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def current_content_hash(self) -> str:
        return self._hash_content(
            self.key,
            self.text,
            self.claim_type,
            self.requires_source,
            self.source_requirement_reason,
            self.rationale,
        )

    def save(self, *args, **kwargs):
        current_hash = self.current_content_hash()
        previous_hash = None
        if self.pk:
            previous_hash = type(self).objects.filter(pk=self.pk).values_list("reviewed_content_hash", flat=True).first()
        content_changed = previous_hash is not None and previous_hash != current_hash
        if content_changed:
            self.status = ClaimStatus.DRAFT
            self.reviewed_by_id = None
            self.reviewed_at = None
        self.reviewed_content_hash = current_hash

        if kwargs.get("update_fields") is not None:
            update_fields = set(kwargs["update_fields"]) | {"reviewed_content_hash"}
            if content_changed:
                update_fields.update(
                    {
                        "key",
                        "text",
                        "claim_type",
                        "requires_source",
                        "source_requirement_reason",
                        "rationale",
                        "status",
                        "reviewed_by",
                        "reviewed_at",
                    }
                )
            kwargs["update_fields"] = update_fields
        return super().save(*args, **kwargs)

    def clean(self):
        super().clean()
        source_free_types = {ClaimType.OPINION, ClaimType.CREATIVE, ClaimType.GENERAL_ADVICE}
        if not self.requires_source:
            if self.claim_type not in source_free_types:
                raise ValidationError(
                    {"requires_source": "Claim واقعی، علمی یا تبلیغاتی را بدون منبع نمی‌توان برای تحویل مجاز کرد."}
                )
            if not (self.source_requirement_reason or "").strip():
                raise ValidationError({"source_requirement_reason": "دلیلِ منبع‌نخواستن را ثبت کنید."})
            if self.status == ClaimStatus.SUPPORTED:
                raise ValidationError({"status": "Claim بدون منبع باید با وضعیت بازبینی‌شدهٔ غیرfactual ثبت شود."})
        elif self.status == ClaimStatus.REVIEWED_NONFACTUAL:
            raise ValidationError({"status": "وضعیت غیرfactual فقط برای Claimهای بدون منبع مجاز است."})

    def __str__(self) -> str:
        return f"{self.project_id}: {self.key}"


class ClaimSourceLink(TimeStampedModel):
    claim = models.ForeignKey(ContentClaim, on_delete=models.CASCADE, related_name="source_links")
    source = models.ForeignKey(ResearchSource, on_delete=models.CASCADE, related_name="claim_links")
    relation = models.CharField(max_length=16, choices=ClaimSourceRelation.choices, default=ClaimSourceRelation.SUPPORTS)
    evidence_excerpt = models.TextField()
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="reviewed_claim_source_links",
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)
    reviewed_content_hash = models.CharField(max_length=64, blank=True, editable=False)

    class Meta:
        ordering = ["created_at", "claim_id"]
        constraints = [
            models.UniqueConstraint(fields=["claim", "source"], name="unique_claim_source_link")
        ]

    @staticmethod
    def _hash_content(claim: ContentClaim, source: ResearchSource, relation: str, evidence_excerpt: str) -> str:
        content = "\0".join(
            (
                str(claim.pk),
                claim.current_content_hash(),
                str(source.pk),
                source.current_content_hash(),
                relation or "",
                evidence_excerpt or "",
            )
        )
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def current_content_hash(self) -> str:
        return self._hash_content(self.claim, self.source, self.relation, self.evidence_excerpt)

    def save(self, *args, **kwargs):
        current_hash = ""
        if self.claim_id and self.source_id:
            claim = ContentClaim.objects.get(pk=self.claim_id)
            source = ResearchSource.objects.get(pk=self.source_id)
            current_hash = self._hash_content(claim, source, self.relation, self.evidence_excerpt)

        previous_hash = None
        if self.pk:
            previous_hash = type(self).objects.filter(pk=self.pk).values_list("reviewed_content_hash", flat=True).first()
        content_changed = previous_hash is not None and previous_hash != current_hash
        if content_changed:
            self.reviewed_by_id = None
            self.reviewed_at = None
        self.reviewed_content_hash = current_hash

        if kwargs.get("update_fields") is not None:
            update_fields = set(kwargs["update_fields"]) | {"reviewed_content_hash"}
            if content_changed:
                update_fields.update({"claim", "source", "relation", "evidence_excerpt", "reviewed_by", "reviewed_at"})
            kwargs["update_fields"] = update_fields
        return super().save(*args, **kwargs)

    def clean(self):
        super().clean()
        if self.claim_id and self.source_id:
            claim_project_id = self.claim.project_id
            source_project_id = self.source.project_id
            if claim_project_id != source_project_id:
                raise ValidationError({"source": "Claim و Research Source باید متعلق به یک Project باشند."})
            source_excerpt = (self.source.excerpt or "").strip()
            evidence_excerpt = (self.evidence_excerpt or "").strip()
            if not source_excerpt:
                raise ValidationError({"source": "پیش از اتصال Claim، متن قابل‌ردیابی منبع را ثبت کنید."})
            if not evidence_excerpt or evidence_excerpt not in source_excerpt:
                raise ValidationError({"evidence_excerpt": "شاهد باید عیناً در متن ثبت‌شدهٔ همان منبع وجود داشته باشد."})

    def __str__(self) -> str:
        return f"{self.claim.key} ↔ {self.source}"


class BrandMemoryEntry(TimeStampedModel):
    brand = models.ForeignKey(BrandProfile, on_delete=models.CASCADE, related_name="memory_entries")
    project = models.ForeignKey(
        Project,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="memory_entries",
    )
    kind = models.CharField(max_length=16, choices=MemoryKind.choices)
    text = models.TextField()
    normalized_text = models.CharField(max_length=2000, db_index=True)
    status = models.CharField(max_length=16, choices=MemoryStatus.choices, default=MemoryStatus.DRAFT)
    provenance = models.CharField(max_length=24, choices=ArtifactProvenance.choices)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="created_brand_memory_entries",
    )
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="reviewed_brand_memory_entries",
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-updated_at", "kind"]
        indexes = [models.Index(fields=["brand", "kind", "status"])]

    def clean(self):
        super().clean()
        if self.project_id and self.brand_id and self.project.brand_id != self.brand_id:
            raise ValidationError({"project": "Project و Brand Memory باید متعلق به یک Brand باشند."})
        if self.status in {MemoryStatus.APPROVED, MemoryStatus.PUBLISHED} and not (
            self.reviewed_by_id and self.reviewed_at
        ):
            raise ValidationError("حافظهٔ تأییدشده باید reviewer و زمان ثبت داشته باشد.")

    def __str__(self) -> str:
        return f"{self.brand.slug}: {self.kind} — {self.text[:60]}"


class CarouselSlide(TimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="slides")
    position = models.PositiveSmallIntegerField(validators=[MinValueValidator(1)])
    role = models.CharField(max_length=64, blank=True)
    copy_text = models.TextField(blank=True)
    visual_direction = models.JSONField(default=dict, blank=True)
    image_prompt = models.TextField(blank=True)
    layout = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["position"]
        constraints = [
            models.UniqueConstraint(fields=["project", "position"], name="unique_project_slide_position")
        ]

    def __str__(self) -> str:
        return f"{self.project_id} — اسلاید {self.position}"


class ClaimSlideLink(TimeStampedModel):
    claim = models.ForeignKey(ContentClaim, on_delete=models.CASCADE, related_name="slide_links")
    slide = models.ForeignKey(CarouselSlide, on_delete=models.CASCADE, related_name="claim_links")
    copy_excerpt = models.TextField()
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="reviewed_claim_slide_links",
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)
    reviewed_content_hash = models.CharField(max_length=64, blank=True, editable=False)

    class Meta:
        ordering = ["slide__position", "claim_id"]
        constraints = [
            models.UniqueConstraint(fields=["claim", "slide"], name="unique_claim_slide_link")
        ]

    @staticmethod
    def _hash_content(claim: ContentClaim, slide: CarouselSlide, copy_excerpt: str) -> str:
        content = "\0".join(
            (
                str(claim.pk),
                claim.key,
                claim.text,
                claim.claim_type,
                str(claim.requires_source),
                claim.source_requirement_reason or "",
                claim.rationale or "",
                str(slide.pk),
                str(slide.position),
                slide.copy_text,
                copy_excerpt or "",
            )
        )
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def current_content_hash(self) -> str:
        return self._hash_content(self.claim, self.slide, self.copy_excerpt)

    def save(self, *args, **kwargs):
        current_hash = ""
        if self.claim_id and self.slide_id:
            claim = ContentClaim.objects.only(
                "id",
                "key",
                "text",
                "claim_type",
                "requires_source",
                "source_requirement_reason",
                "rationale",
            ).get(pk=self.claim_id)
            slide = CarouselSlide.objects.only("id", "position", "copy_text").get(pk=self.slide_id)
            current_hash = self._hash_content(claim, slide, self.copy_excerpt)

        previous_hash = None
        if self.pk:
            previous_hash = type(self).objects.filter(pk=self.pk).values_list("reviewed_content_hash", flat=True).first()
        content_changed = previous_hash is not None and previous_hash != current_hash
        if content_changed:
            self.reviewed_by_id = None
            self.reviewed_at = None
        self.reviewed_content_hash = current_hash

        if kwargs.get("update_fields") is not None:
            update_fields = set(kwargs["update_fields"]) | {"reviewed_content_hash"}
            if content_changed:
                update_fields.update({"claim", "slide", "copy_excerpt", "reviewed_by", "reviewed_at"})
            kwargs["update_fields"] = update_fields
        return super().save(*args, **kwargs)

    def clean(self):
        super().clean()
        if self.claim_id and self.slide_id:
            if self.claim.project_id != self.slide.project_id:
                raise ValidationError({"slide": "Claim و Slide باید متعلق به یک Project باشند."})
            if not (self.copy_excerpt or "").strip():
                raise ValidationError({"copy_excerpt": "بخش دقیق متن اسلاید برای ردیابی Claim الزامی است."})
            if self.copy_excerpt not in self.slide.copy_text:
                raise ValidationError({"copy_excerpt": "این بخش دقیق در متن فعلی اسلاید پیدا نشد."})

    def __str__(self) -> str:
        return f"{self.claim.key} → {self.slide}"


class GeneratedAsset(TimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="assets")
    slide = models.ForeignKey(
        CarouselSlide,
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name="assets",
    )
    kind = models.CharField(max_length=20, choices=AssetKind.choices)
    storage_key = models.CharField(max_length=500, unique=True)
    mime_type = models.CharField(max_length=100)
    width = models.PositiveIntegerField(null=True, blank=True)
    height = models.PositiveIntegerField(null=True, blank=True)
    byte_size = models.PositiveBigIntegerField(default=0)
    sha256 = models.CharField(max_length=64, blank=True)
    render_input_hash = models.CharField(max_length=64, blank=True)
    provenance = models.CharField(max_length=24, choices=ArtifactProvenance.choices)
    provider_id = models.CharField(max_length=80, blank=True)
    model_name = models.CharField(max_length=120, blank=True)
    rights_basis = models.CharField(max_length=24, choices=AssetRightsBasis.choices, blank=True)
    rights_note = models.CharField(max_length=500, blank=True)
    rights_source_url = models.URLField(max_length=2048, blank=True)
    rights_confirmed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="confirmed_studio_asset_rights",
    )
    rights_confirmed_at = models.DateTimeField(null=True, blank=True)
    is_private = models.BooleanField(default=True)

    class Meta:
        ordering = ["project", "slide__position", "kind"]
        constraints = [
            models.UniqueConstraint(
                fields=["slide", "kind"],
                condition=models.Q(slide__isnull=False),
                name="unique_slide_generated_asset_kind",
            )
        ]

    def __str__(self) -> str:
        return f"{self.project_id}: {self.kind}"


class QualityReport(TimeStampedModel):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name="quality_reports")
    axis = models.CharField(max_length=32, choices=QualityAxis.choices)
    status = models.CharField(max_length=24, choices=QualityStatus.choices, default=QualityStatus.NOT_RUN)
    version = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    findings = models.JSONField(default=list, blank=True)
    blockers = models.JSONField(default=list, blank=True)
    source_urls = models.JSONField(default=list, blank=True)
    policy_pack_id = models.CharField(max_length=120, blank=True)
    policy_pack_version = models.CharField(max_length=64, blank=True)
    provider_id = models.CharField(max_length=80, blank=True)
    model_name = models.CharField(max_length=120, blank=True)
    reviewed_content_hash = models.CharField(max_length=64, blank=True, editable=False)
    test_only = models.BooleanField(default=False)
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="reviewed_quality_reports",
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["axis", "-version"]
        constraints = [
            models.UniqueConstraint(fields=["project", "axis", "version"], name="unique_quality_axis_version")
        ]

    def __str__(self) -> str:
        return f"{self.project_id}: {self.get_axis_display()} ({self.status})"
