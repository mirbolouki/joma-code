import hashlib
import io

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Max
from django.http import FileResponse, HttpRequest, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_http_methods, require_POST

from .enums import (
    ArtifactProvenance,
    AssetKind,
    CapabilityStatus,
    FormatChoice,
    PipelineStage,
    ProjectStatus,
    QualityAxis,
    QualityStatus,
    RunStatus,
    ResearchSourceStatus,
)
from .exporter import ExportNotReady, _delivery_blockers, build_project_zip
from .forms import (
    CarouselSlideForm,
    ClaimSlideLinkForm,
    ClaimSourceLinkForm,
    ContentClaimForm,
    LocalTestFixtureUploadForm,
    ManualStageInputForm,
    ProjectCreateForm,
    QualityReviewForm,
    ResearchDecisionForm,
    ResearchSourceForm,
    SlideImageUploadForm,
)
from .models import (
    BrandProfile,
    ClaimSlideLink,
    ClaimSourceLink,
    GeneratedAsset,
    Project,
    ProjectArtifact,
    ResearchDecision,
    ResearchSource,
    StageRun,
)
from .quality import (
    ensure_initial_quality_reports,
    quality_input_blockers,
    quality_subject_hash,
    record_human_quality_review,
    invalidate_quality_reports,
)
from .services.workflow import mark_manual_mode_blocked
from .storage import PrivateLocalStore
from .services.rendering import SlideRenderBlocked, render_slide_assets
from .services.uploads import (
    ImageUploadBlocked,
    register_local_test_fixture_base_image,
    register_user_uploaded_base_image,
)


_STAGE_CAPABILITY = {
    PipelineStage.OPPORTUNITY_ANALYSIS: ("LLM", CapabilityStatus.REQUIRES_PROVIDER),
    PipelineStage.STRATEGY: ("LLM", CapabilityStatus.REQUIRES_PROVIDER),
    PipelineStage.HOOK: ("LLM", CapabilityStatus.REQUIRES_PROVIDER),
    PipelineStage.CONTENT_STRUCTURE: ("LLM", CapabilityStatus.REQUIRES_PROVIDER),
    PipelineStage.PERSIAN_COPY: ("LLM", CapabilityStatus.REQUIRES_PROVIDER),
    PipelineStage.VISUAL_DIRECTION: ("LLM", CapabilityStatus.REQUIRES_PROVIDER),
    PipelineStage.RESEARCH: ("Search", CapabilityStatus.REQUIRES_PROVIDER),
    PipelineStage.IMAGE_GENERATION: ("Image", CapabilityStatus.REQUIRES_PROVIDER),
    PipelineStage.PERSIAN_OVERLAY: ("Skia/HarfBuzz + Noto Sans Arabic; target build pending", CapabilityStatus.NOT_VERIFIED),
    PipelineStage.LAYOUT: ("layout renderer", CapabilityStatus.NOT_VERIFIED),
    PipelineStage.PREVIEW: ("private final-raster preview; target pending", CapabilityStatus.NOT_VERIFIED),
    PipelineStage.PLATFORM_COMPLIANCE: ("official policy pack + human review", CapabilityStatus.NOT_VERIFIED),
    PipelineStage.PLATFORM_BEST_PRACTICES: ("versioned criteria + human review", CapabilityStatus.NOT_VERIFIED),
    PipelineStage.CREATIVE_QUALITY: ("human review of final rasters", CapabilityStatus.NOT_VERIFIED),
    PipelineStage.FINAL_ASSETS: ("local raster renderer; target pending", CapabilityStatus.NOT_VERIFIED),
    PipelineStage.MANIFEST: ("deterministic exporter", CapabilityStatus.NOT_VERIFIED),
    PipelineStage.ZIP: ("private storage + hash-checked exporter; target pending", CapabilityStatus.NOT_VERIFIED),
}


def _pipeline_rows(project: Project) -> list[dict[str, str]]:
    latest_runs = {}
    for run in project.stage_runs.all().order_by("stage", "-attempt"):
        latest_runs.setdefault(run.stage, run)
    rows = []
    for stage, label in PipelineStage.choices:
        run = latest_runs.get(stage)
        if run:
            status = run.status
            capability_status = run.capability_status
            message = run.message
        elif stage == PipelineStage.IDEA:
            status = RunStatus.COMPLETED
            capability_status = CapabilityStatus.NOT_VERIFIED
            message = "ایده در پروژه ذخیره شده؛ آزمون UI/پایداری در حال انجام است."
        else:
            status = RunStatus.NOT_RUN
            capability_status = _STAGE_CAPABILITY.get(stage, ("", CapabilityStatus.NOT_VERIFIED))[1]
            message = _STAGE_CAPABILITY.get(stage, ("", ""))[0]
        rows.append(
            {
                "stage": stage,
                "label": label,
                "status": status,
                "capability_status": capability_status,
                "message": message,
            }
        )
    return rows


def _get_accessible_project(request: HttpRequest, project_id) -> Project:
    projects = Project.objects.select_related("brand", "created_by")
    if request.user.is_staff:
        return get_object_or_404(projects, pk=project_id)
    return get_object_or_404(projects, pk=project_id, created_by=request.user)


@login_required
@require_http_methods(["GET", "POST"])
def dashboard(request: HttpRequest) -> HttpResponse:
    if request.method == "POST":
        form = ProjectCreateForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                project = form.save(commit=False)
                project.created_by = request.user
                project.test_only = settings.STUDIO_TEST_MODE and request.headers.get("X-Studio-Test-Only") == "1"
                project.current_stage = PipelineStage.OPPORTUNITY_ANALYSIS
                project.selected_format = (
                    project.requested_format if project.requested_format != FormatChoice.AUTO else ""
                )
                project.status = ProjectStatus.IN_PROGRESS
                project.save()
                StageRun.objects.create(
                    project=project,
                    stage=PipelineStage.IDEA,
                    status=RunStatus.COMPLETED,
                    capability_status=CapabilityStatus.NOT_VERIFIED,
                    message=(
                        "TEST_ONLY پروژهٔ آزمایشی؛ ایده ورودی fixture است."
                        if project.test_only
                        else "ورودی ایده ذخیره شد؛ قابلیت ذخیره‌سازی هنوز در acceptance environment بررسی می‌شود."
                    ),
                    details={"test_only": project.test_only, "provider_called": False},
                )
                ensure_initial_quality_reports(project)
                mark_manual_mode_blocked(str(project.pk))
            messages.info(
                request,
                (
                    "TEST_ONLY: پروژهٔ آزمایشی در حالت محلی ثبت شد؛ تأیید محصول یا انسانی نیست. هیچ API یا صفی فراخوانی نشد."
                    if project.test_only
                    else "پروژه در حالت محلی/دستی ثبت شد؛ هیچ API، provider، صف Celery یا سرویس بیرونی فراخوانی نشد."
                ),
            )
            return redirect("studio:project_detail", project_id=project.pk)
    else:
        form = ProjectCreateForm()

    projects = Project.objects.select_related("brand", "created_by")
    if not request.user.is_staff:
        projects = projects.filter(created_by=request.user)
    projects = projects.order_by("-created_at")[:50]
    return render(
        request,
        "studio/dashboard.html",
        {"form": form, "projects": projects, "active_brands": BrandProfile.objects.filter(is_active=True).count()},
    )


@login_required
@require_http_methods(["GET"])
def project_detail(request: HttpRequest, project_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    decision = getattr(project, "research_decision", None)
    slides = list(project.slides.prefetch_related("claim_links__claim", "assets").all())
    for slide in slides:
        slide.upload_form = SlideImageUploadForm(prefix=f"upload-{slide.pk}")
    qa_reviews = []
    current_qa_hash = quality_subject_hash(project)
    for axis, label in QualityAxis.choices:
        report = project.quality_reports.filter(axis=axis).order_by("-version").first()
        qa_reviews.append(
            {
                "axis": axis,
                "label": label,
                "report": report,
                "is_current": bool(report and report.reviewed_content_hash == current_qa_hash),
                "form": QualityReviewForm(prefix=f"qa-{axis}", axis=axis),
            }
        )
    return render(
        request,
        "studio/project_detail.html",
        {
            "project": project,
            "rendered_slide_count": project.assets.filter(
                kind=AssetKind.IMAGE_FINAL,
                slide__isnull=False,
            ).values("slide_id").distinct().count(),
            "slide_count": project.slides.count(),
            "pipeline_rows": _pipeline_rows(project),
            "decision": decision,
            "decision_form": ResearchDecisionForm(instance=decision),
            "source_form": ResearchSourceForm(),
            "sources": project.research_sources.all(),
            "claim_form": ContentClaimForm(),
            "claim_source_form": ClaimSourceLinkForm(project=project),
            "slide_form": CarouselSlideForm(),
            "manual_stage_form": ManualStageInputForm(),
            "manual_stage_artifacts": project.artifacts.filter(artifact_type="manual_stage_input").order_by(
                "stage", "version"
            ),
            "test_mode": settings.STUDIO_TEST_MODE,
            "project_test_only": project.test_only,
            "claim_slide_form": ClaimSlideLinkForm(project=project),
            "slides": slides,
            "claims": project.claims.prefetch_related(
                "source_links__source", "slide_links__slide"
            ).all(),
            "artifacts": project.artifacts.all(),
            "qa_reviews": qa_reviews,
            "latest_runs": project.stage_runs.all().order_by("stage", "-attempt"),
        },
    )


@login_required
@require_POST
def save_research_decision(request: HttpRequest, project_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    decision = getattr(project, "research_decision", None)
    test_only = settings.STUDIO_TEST_MODE and request.headers.get("X-Studio-Test-Only") == "1"
    form = ResearchDecisionForm(request.POST, instance=decision)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.project = project
        obj.confirmed_by = request.user
        obj.confirmed_at = timezone.now()
        obj.test_only = test_only
        if test_only and not obj.rationale.startswith("TEST_ONLY:"):
            obj.rationale = "TEST_ONLY: " + obj.rationale
        obj.save()
        ProjectArtifact.objects.create(
            project=project,
            stage=PipelineStage.RESEARCH_DECISION,
            artifact_type="research_decision",
            version=project.artifacts.filter(
                stage=PipelineStage.RESEARCH_DECISION,
                artifact_type="research_decision",
            ).count() + 1,
            payload={
                "level": obj.level,
                "rationale": obj.rationale,
                "claim_types": obj.claim_types,
                "test_only": test_only,
            },
            provenance=ArtifactProvenance.TEST_FIXTURE if test_only else ArtifactProvenance.MANUAL_REVIEW,
        )
        invalidate_quality_reports(project, "Research Decision تغییر کرده؛ QA باید روی snapshot جدید تکرار شود.")
        messages.success(
            request,
            "TEST_ONLY: Research Decision fixture ثبت شد؛ تأیید واقعی نیست."
            if test_only
            else "Research Decision به‌صورت دستی ثبت شد؛ منبعی به‌طور خودکار جعل یا تأیید نشد.",
        )
    else:
        messages.error(request, "Research Decision ذخیره نشد؛ فرم را بررسی کنید.")
    return redirect("studio:project_detail", project_id=project.pk)


@login_required
@require_POST
def add_research_source(request: HttpRequest, project_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    form = ResearchSourceForm(request.POST)
    if form.is_valid():
        source = form.save(commit=False)
        source.project = project
        source.accessed_at = timezone.now()
        source.review_status = ResearchSourceStatus.UNREVIEWED
        source.save()
        invalidate_quality_reports(project, "منبع پژوهش تغییر کرده؛ QA باید روی snapshot جدید تکرار شود.")
        messages.info(request, "URL ثبت شد اما منبع هنوز بازبینی‌نشده است و برای claim تأییدشده قابل استفاده نیست.")
    else:
        messages.error(request, "منبع ذخیره نشد؛ URL و اطلاعات را بررسی کنید.")
    return redirect("studio:project_detail", project_id=project.pk)


@login_required
@require_POST
def add_content_claim(request: HttpRequest, project_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    form = ContentClaimForm(request.POST)
    if form.is_valid():
        if project.claims.filter(key=form.cleaned_data["key"]).exists():
            messages.error(request, "این شناسهٔ claim قبلاً در همین پروژه استفاده شده است.")
            return redirect("studio:project_detail", project_id=project.pk)
        with transaction.atomic():
            claim = form.save(commit=False)
            claim.project = project
            claim.save()
            ProjectArtifact.objects.create(
                project=project,
                stage=PipelineStage.RESEARCH,
                artifact_type="content_claim",
                version=project.artifacts.filter(
                    stage=PipelineStage.RESEARCH,
                    artifact_type="content_claim",
                ).count() + 1,
                payload={
                    "key": claim.key,
                    "text": claim.text,
                    "claim_type": claim.claim_type,
                    "requires_source": claim.requires_source,
                    "source_requirement_reason": claim.source_requirement_reason,
                    "status": claim.status,
                },
                provenance=ArtifactProvenance.USER_INPUT,
            )
        invalidate_quality_reports(project, "Claim تغییر کرده؛ QA باید روی snapshot جدید تکرار شود.")
        messages.info(request, "Claim به‌عنوان پیش‌نویس ثبت شد؛ تا بازبینی claim و منبع، قابل‌استفاده برای تحویل نیست.")
    else:
        messages.error(request, "Claim ذخیره نشد؛ فیلدها را بررسی کنید.")
    return redirect("studio:project_detail", project_id=project.pk)


@login_required
@require_POST
def add_carousel_slide(request: HttpRequest, project_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    test_only = settings.STUDIO_TEST_MODE and request.headers.get("X-Studio-Test-Only") == "1"
    if project.slides.count() >= 7:
        messages.error(request, "MVP Carousel حداکثر ۷ اسلاید دارد.")
        return redirect("studio:project_detail", project_id=project.pk)
    form = CarouselSlideForm(request.POST)
    if form.is_valid():
        with transaction.atomic():
            position = (project.slides.aggregate(max_position=Max("position"))["max_position"] or 0) + 1
            slide = form.save(commit=False)
            slide.project = project
            slide.position = position
            slide.save()
            ProjectArtifact.objects.create(
                project=project,
                stage=PipelineStage.PERSIAN_COPY,
                artifact_type="carousel_slide_copy",
                version=project.artifacts.filter(
                    stage=PipelineStage.PERSIAN_COPY,
                    artifact_type="carousel_slide_copy",
                ).count() + 1,
                payload={
                    "position": slide.position,
                    "role": slide.role,
                    "copy_text": slide.copy_text,
                    "test_only": test_only,
                },
                provenance=ArtifactProvenance.TEST_FIXTURE if test_only else ArtifactProvenance.USER_INPUT,
            )
        invalidate_quality_reports(project, "متن/ساختار اسلاید تغییر کرده؛ QA باید روی snapshot جدید تکرار شود.")
        messages.info(
            request,
            "TEST_ONLY: متن آزمایشی ثبت شد؛ خروجی واقعی محصول نیست."
            if test_only
            else "متن اسلاید به‌عنوان ورودی دستی ثبت شد؛ این کار به‌معنی تولید یا تأیید QA نیست.",
        )
    else:
        messages.error(request, "اسلاید ذخیره نشد؛ متن فارسی را بررسی کنید.")
    return redirect("studio:project_detail", project_id=project.pk)


@login_required
@require_POST
def link_claim_to_slide(request: HttpRequest, project_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    form = ClaimSlideLinkForm(request.POST, project=project)
    if form.is_valid():
        claim = form.cleaned_data["claim"]
        slide = form.cleaned_data["slide"]
        if ClaimSlideLink.objects.filter(claim=claim, slide=slide).exists():
            messages.error(request, "این Claim قبلاً به همین اسلاید پیوند خورده است.")
            return redirect("studio:project_detail", project_id=project.pk)
        with transaction.atomic():
            link = form.save(commit=False)
            link.save()
            ProjectArtifact.objects.create(
                project=project,
                stage=PipelineStage.PERSIAN_COPY,
                artifact_type="claim_slide_link",
                version=project.artifacts.filter(
                    stage=PipelineStage.PERSIAN_COPY,
                    artifact_type="claim_slide_link",
                ).count() + 1,
                payload={
                    "claim_key": link.claim.key,
                    "slide_position": link.slide.position,
                    "copy_excerpt": link.copy_excerpt,
                },
                provenance=ArtifactProvenance.USER_INPUT,
            )
        invalidate_quality_reports(project, "پیوند claim/slide تغییر کرده؛ QA باید روی snapshot جدید تکرار شود.")
        messages.info(request, "Claim به بخش دقیق متن اسلاید پیوند خورد؛ پیوند هنوز بازبینی‌نشده است.")
    else:
        messages.error(request, "پیوند ساخته نشد؛ Claim، اسلاید و عبارت باید متعلق به همین پروژه باشند.")
    return redirect("studio:project_detail", project_id=project.pk)


@login_required
@require_POST
def link_claim_source(request: HttpRequest, project_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    form = ClaimSourceLinkForm(request.POST, project=project)
    if form.is_valid():
        claim = form.cleaned_data["claim"]
        source = form.cleaned_data["source"]
        if ClaimSourceLink.objects.filter(claim=claim, source=source).exists():
            messages.error(request, "این claim و منبع قبلاً به هم پیوند داده شده‌اند.")
            return redirect("studio:project_detail", project_id=project.pk)
        with transaction.atomic():
            link = form.save()
            ProjectArtifact.objects.create(
                project=project,
                stage=PipelineStage.RESEARCH,
                artifact_type="claim_source_link",
                version=project.artifacts.filter(
                    stage=PipelineStage.RESEARCH,
                    artifact_type="claim_source_link",
                ).count() + 1,
                payload={
                    "claim_key": link.claim.key,
                    "source_url": link.source.url,
                    "relation": link.relation,
                    "evidence_excerpt": link.evidence_excerpt,
                },
                provenance=ArtifactProvenance.USER_INPUT,
                source_urls=[link.source.url],
            )
        invalidate_quality_reports(project, "پیوند claim/source تغییر کرده؛ QA باید روی snapshot جدید تکرار شود.")
        messages.info(request, "پیوند claim/source ثبت شد؛ این پیوند و منبع هنوز بازبینی‌نشده‌اند.")
    else:
        messages.error(request, "پیوند ذخیره نشد؛ claim و منبع باید متعلق به همین پروژه باشند.")
    return redirect("studio:project_detail", project_id=project.pk)


@login_required
@require_POST
def record_manual_stage_input(request: HttpRequest, project_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    test_only = settings.STUDIO_TEST_MODE and request.headers.get("X-Studio-Test-Only") == "1"
    form = ManualStageInputForm(request.POST)
    if not form.is_valid():
        messages.error(request, "یادداشت مرحله ذخیره نشد؛ مرحله و متن را بررسی کنید.")
        return redirect("studio:project_detail", project_id=project.pk)

    stages = (
        PipelineStage.OPPORTUNITY_ANALYSIS,
        PipelineStage.STRATEGY,
        PipelineStage.HOOK,
        PipelineStage.CONTENT_STRUCTURE,
    )
    stage = form.cleaned_data["stage"]
    index = stages.index(stage)
    if index and not project.artifacts.filter(
        artifact_type="manual_stage_input",
        stage=stages[index - 1],
    ).exists():
        messages.error(request, "مرحلهٔ قبلی باید پیش از این مرحله ثبت شود.")
        return redirect("studio:project_detail", project_id=project.pk)

    provenance = ArtifactProvenance.TEST_FIXTURE if test_only else ArtifactProvenance.USER_INPUT
    with transaction.atomic():
        version = project.artifacts.filter(stage=stage, artifact_type="manual_stage_input").count() + 1
        artifact = ProjectArtifact.objects.create(
            project=project,
            stage=stage,
            artifact_type="manual_stage_input",
            version=version,
            payload={
                "content": form.cleaned_data["content"],
                "content_sha256": hashlib.sha256(form.cleaned_data["content"].encode("utf-8")).hexdigest(),
                "provider_called": False,
                "test_only": test_only,
            },
            provenance=provenance,
        )
        next_stage = stages[index + 1] if index + 1 < len(stages) else PipelineStage.PERSIAN_COPY
        previous = project.stage_runs.filter(stage=stage).order_by("-attempt").first()
        StageRun.objects.create(
            project=project,
            stage=stage,
            status=RunStatus.COMPLETED,
            capability_status=CapabilityStatus.NOT_VERIFIED,
            message=(
                "یادداشت تحریریهٔ TEST_ONLY ثبت شد؛ خروجی AI یا محتوای تأییدشده نیست."
                if test_only
                else "یادداشت تحریریه به‌صورت ورودی کاربر ثبت شد؛ هیچ provider یا API اجرا نشد."
            ),
            attempt=(previous.attempt + 1) if previous else 1,
            finished_at=timezone.now(),
            details={
                "artifact_version": artifact.version,
                "provenance": provenance,
                "provider_called": False,
                "test_only": test_only,
            },
        )
        project.current_stage = next_stage
        project.status = ProjectStatus.IN_PROGRESS
        project.save(update_fields=["current_stage", "status", "updated_at"])
        invalidate_quality_reports(project, "محتوای تحریریه تغییر کرده؛ QA باید روی snapshot نهایی اجرا شود.")

    messages.info(
        request,
        "محتوای این مرحله به‌صورت TEST_ONLY ثبت شد."
        if test_only
        else "محتوای مرحله به‌صورت دستی ثبت شد؛ هیچ API فراخوانی نشد.",
    )
    return redirect("studio:project_detail", project_id=project.pk)


@login_required
@require_POST
def record_quality_review(request: HttpRequest, project_id, axis: str) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    if axis not in QualityAxis.values:
        return HttpResponse(status=404)
    test_only = settings.STUDIO_TEST_MODE and request.headers.get("X-Studio-Test-Only") == "1"
    form = QualityReviewForm(request.POST, prefix=f"qa-{axis}", axis=axis, test_only=test_only)
    if not form.is_valid():
        messages.error(request, "QA ثبت نشد؛ هر سه موردِ نتیجه، شواهد بررسی و blockerها را بازبینی کنید. " + form.errors.as_text())
        return redirect("studio:project_detail", project_id=project.pk)

    store = PrivateLocalStore()
    asset_blockers = quality_input_blockers(project, store)
    if asset_blockers:
        messages.error(request, "QA ثبت نشد؛ هنوز فایل‌های واقعی/خصوصی و رندر تازه لازم‌اند: " + "؛ ".join(asset_blockers))
        return redirect("studio:project_detail", project_id=project.pk)

    with transaction.atomic():
        report = record_human_quality_review(
            project,
            axis,
            form.cleaned_data,
            request.user,
            test_only=test_only,
        )
        stage = {
            QualityAxis.PLATFORM_COMPLIANCE: PipelineStage.PLATFORM_COMPLIANCE,
            QualityAxis.PLATFORM_BEST_PRACTICES: PipelineStage.PLATFORM_BEST_PRACTICES,
            QualityAxis.CREATIVE_QUALITY: PipelineStage.CREATIVE_QUALITY,
        }[axis]
        previous = project.stage_runs.filter(stage=stage).order_by("-attempt").first()
        StageRun.objects.create(
            project=project,
            stage=stage,
            status=RunStatus.COMPLETED if report.status == QualityStatus.PASS else RunStatus.FAILED,
            capability_status=CapabilityStatus.NOT_VERIFIED,
            message=(
                f"TEST_ONLY QA ثبت شد: {report.get_status_display()}؛ تأیید انسانی واقعی نیست."
                if test_only
                else f"بازبینی انسانی ثبت شد: {report.get_status_display()}؛ هیچ QA خودکار یا API اجرا نشد."
            ),
            attempt=(previous.attempt + 1) if previous else 1,
            finished_at=timezone.now(),
            details={
                "axis": axis,
                "report_version": report.version,
                "reviewed_content_hash": report.reviewed_content_hash,
                "provider_called": False,
                "test_only": test_only,
            },
        )
        if report.status == QualityStatus.FAIL:
            project.status = ProjectStatus.NEEDS_REVIEW
            project.save(update_fields=["status", "updated_at"])
        else:
            blockers = _delivery_blockers(project, store, require_ready_status=False)
            if not blockers:
                project.status = ProjectStatus.NEEDS_REVIEW if test_only else ProjectStatus.READY
                project.save(update_fields=["status", "updated_at"])

    if report.status == QualityStatus.FAIL:
        messages.warning(request, f"{report.get_axis_display()} نتیجهٔ رد دارد؛ export مسدود می‌ماند.")
    elif test_only:
        messages.warning(request, "TEST_ONLY: مسیر QA فقط برای آزمون فنی ثبت شد؛ تأیید انسانی واقعی یا مجوز انتشار نیست.")
    elif project.status == ProjectStatus.READY:
        messages.success(request, "QA ثبت شد و تمام gateهای جاری عبور کردند؛ پروژه READY است. ZIP همچنان از همان فایل‌های خصوصی ساخته می‌شود.")
    else:
        blockers = _delivery_blockers(project, store, require_ready_status=False)
        messages.success(request, "QA انسانی ثبت شد؛ تکمیل پروژه هنوز به blockerهای دیگر وابسته است. " + "؛ ".join(blockers[:3]))
    return redirect("studio:project_detail", project_id=project.pk)


@login_required
@require_POST
def upload_slide_base_image(request: HttpRequest, project_id, slide_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    slide = get_object_or_404(project.slides, pk=slide_id)
    use_test_fixture = settings.STUDIO_TEST_MODE and request.headers.get("X-Studio-Test-Fixture") == "1"
    if use_test_fixture:
        form = LocalTestFixtureUploadForm(request.POST, request.FILES, prefix=f"fixture-{slide.pk}")
        if not form.is_valid():
            messages.error(request, "تصویر TEST_FIXTURE پذیرفته نشد؛ فایل PNG/JPEG آزمایشی را بررسی کنید.")
            return redirect("studio:project_detail", project_id=project.pk)
        try:
            register_local_test_fixture_base_image(
                project,
                slide,
                form.cleaned_data["image"],
                source_description="تصویر بدون نوشته با زمینهٔ هندسی که محلی با Pillow برای آزمون ساخته شده؛ TEST_FIXTURE، نه USER_INPUT و نه AI.",
            )
        except ImageUploadBlocked as exc:
            messages.error(request, f"TEST_FIXTURE ذخیره نشد: {exc}")
        else:
            messages.info(request, "تصویر محلی TEST_FIXTURE خصوصی ذخیره شد؛ برای محصول یا انتشار نیست.")
        return redirect("studio:project_detail", project_id=project.pk)

    form = SlideImageUploadForm(request.POST, request.FILES, prefix=f"upload-{slide.pk}")
    if not form.is_valid():
        messages.error(request, "تصویر ذخیره نشد؛ فایل و تأیید حق استفاده را بررسی کنید. " + form.errors.as_text())
        return redirect("studio:project_detail", project_id=project.pk)

    try:
        register_user_uploaded_base_image(
            project,
            slide,
            form.cleaned_data["image"],
            uploaded_by=request.user,
            rights_basis=form.cleaned_data["rights_basis"],
            rights_note=form.cleaned_data["rights_note"],
            rights_source_url=form.cleaned_data["rights_source_url"],
        )
    except ImageUploadBlocked as exc:
        messages.error(request, f"تصویر ذخیره نشد: {exc}")
    else:
        messages.success(
            request,
            f"تصویر پایهٔ اسلاید {slide.position} خصوصی ذخیره شد و منشأ آن user_input است؛ هیچ AI/provider فراخوانی نشد.",
        )
    return redirect("studio:project_detail", project_id=project.pk)


@login_required
@require_POST
def render_slide_asset(request: HttpRequest, project_id, slide_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    slide = get_object_or_404(project.slides, pk=slide_id)
    try:
        render_slide_assets(project, slide)
    except SlideRenderBlocked as exc:
        messages.error(request, f"رندر انجام نشد: {exc}")
    else:
        messages.success(
            request,
            f"اسلاید {slide.position} رندر شد و preview از همان PNG نهایی استفاده می‌کند؛ نتیجهٔ محیطی هنوز روی target تأیید نشده.",
        )
    return redirect("studio:project_detail", project_id=project.pk)


@login_required
@require_http_methods(["GET"])
def preview_final_asset(request: HttpRequest, project_id, asset_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    asset = get_object_or_404(
        project.assets,
        pk=asset_id,
        kind=AssetKind.IMAGE_FINAL,
        slide__isnull=False,
        is_private=True,
    )
    if asset.mime_type not in {"image/png", "image/jpeg"}:
        return HttpResponse(status=404)
    store = PrivateLocalStore()
    try:
        content = store.read(asset.storage_key)
    except (OSError, ValueError):
        return HttpResponse(status=404)
    if hashlib.sha256(content).hexdigest() != asset.sha256 or len(content) != asset.byte_size:
        return HttpResponse("Preview integrity check failed.", status=409, content_type="text/plain")
    extension = "jpg" if asset.mime_type == "image/jpeg" else "png"
    response = FileResponse(
        io.BytesIO(content),
        content_type=asset.mime_type,
        as_attachment=False,
        filename=f"slide-{asset.slide.position:02d}.{extension}",
    )
    response["Cache-Control"] = "private, no-store"
    response["X-Content-Type-Options"] = "nosniff"
    return response


@login_required
@require_POST
def retry_pipeline(request: HttpRequest, project_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    result = mark_manual_mode_blocked(str(project.pk))
    messages.info(request, result.message)
    return redirect("studio:project_detail", project_id=project.pk)


@login_required
@require_POST
def download_project_zip(request: HttpRequest, project_id) -> HttpResponse:
    project = _get_accessible_project(request, project_id)
    store = PrivateLocalStore()
    try:
        archive_bytes = build_project_zip(str(project.pk), store)
    except ExportNotReady as exc:
        messages.error(request, str(exc))
        return redirect("studio:project_detail", project_id=project.pk)

    storage_key, digest, byte_size = store.save(str(project.pk), "zip", archive_bytes)
    GeneratedAsset.objects.create(
        project=project,
        kind=AssetKind.ZIP,
        storage_key=storage_key,
        mime_type="application/zip",
        byte_size=byte_size,
        sha256=digest,
        provenance=ArtifactProvenance.SYSTEM_GENERATED,
        is_private=True,
    )
    response = FileResponse(
        io.BytesIO(archive_bytes),
        as_attachment=True,
        filename=f"content-studio-{project.pk}.zip",
        content_type="application/zip",
    )
    response["Cache-Control"] = "private, no-store"
    return response
