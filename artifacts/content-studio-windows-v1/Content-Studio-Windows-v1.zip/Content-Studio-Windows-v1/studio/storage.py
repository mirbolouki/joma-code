import hashlib
import os
import uuid
from pathlib import Path, PurePosixPath

from django.conf import settings


class UnsafeStorageKey(ValueError):
    pass


class PrivateLocalStore:
    """Private, non-HTTP storage for project assets and ZIPs."""

    def __init__(self, root: Path | None = None):
        self.root = Path(root or settings.PRIVATE_MEDIA_ROOT).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def save(self, project_id: str, suffix: str, content: bytes) -> tuple[str, str, int]:
        project_uuid = uuid.UUID(str(project_id))
        clean_suffix = suffix.lower().lstrip(".")
        if clean_suffix not in {"png", "jpg", "jpeg", "zip", "json", "txt"}:
            raise ValueError("Unsupported private asset extension.")
        key = f"projects/{project_uuid}/{uuid.uuid4().hex}.{clean_suffix}"
        destination = self._resolve(key)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        try:
            with temporary.open("xb") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            temporary.replace(destination)
        finally:
            if temporary.exists():
                temporary.unlink()
        return key, hashlib.sha256(content).hexdigest(), len(content)

    def read(self, key: str) -> bytes:
        return self._resolve(key).read_bytes()

    def exists(self, key: str) -> bool:
        try:
            return self._resolve(key).is_file()
        except UnsafeStorageKey:
            return False

    def delete(self, key: str) -> None:
        try:
            self._resolve(key).unlink(missing_ok=True)
        except UnsafeStorageKey:
            return

    def _resolve(self, key: str) -> Path:
        pure = PurePosixPath(key)
        if pure.is_absolute() or not pure.parts or any(part in {"..", "."} for part in pure.parts):
            raise UnsafeStorageKey("Storage key must be a relative, normalized path.")
        target = (self.root / Path(*pure.parts)).resolve()
        if not target.is_relative_to(self.root):
            raise UnsafeStorageKey("Storage key escapes private storage root.")
        return target
