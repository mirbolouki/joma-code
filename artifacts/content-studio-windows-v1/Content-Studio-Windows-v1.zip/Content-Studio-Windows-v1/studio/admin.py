from django.contrib import admin

from .models import (
    BrandMemoryEntry,
    BrandProfile,
    CarouselSlide,
    ClaimSlideLink,
    ClaimSourceLink,
    ContentClaim,
    GeneratedAsset,
    Project,
    ProjectArtifact,
    QualityReport,
    ResearchDecision,
    ResearchSource,
    StageRun,
)


@admin.register(BrandProfile)
class BrandProfileAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "is_active", "updated_at")
    list_filter = ("is_active",)
    search_fields = ("name", "slug")
    readonly_fields = ("id", "created_at", "updated_at")


class ClaimSourceLinkInline(admin.TabularInline):
    model = ClaimSourceLink
    extra = 0


class ClaimSlideLinkInline(admin.TabularInline):
    model = ClaimSlideLink
    extra = 0


@admin.register(ContentClaim)
class ContentClaimAdmin(admin.ModelAdmin):
    list_display = ("project", "key", "claim_type", "status", "requires_source", "reviewed_by", "reviewed_at")
    list_filter = ("claim_type", "status", "requires_source")
    search_fields = ("key", "text", "project__idea")
    inlines = (ClaimSourceLinkInline, ClaimSlideLinkInline)


@admin.register(BrandMemoryEntry)
class BrandMemoryEntryAdmin(admin.ModelAdmin):
    list_display = ("brand", "kind", "status", "provenance", "reviewed_by", "updated_at")
    list_filter = ("brand", "kind", "status", "provenance")
    search_fields = ("text", "normalized_text", "brand__name")
    readonly_fields = ("created_at", "updated_at")


class CarouselSlideInline(admin.TabularInline):
    model = CarouselSlide
    extra = 0


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ("id", "brand", "status", "current_stage", "created_at")
    list_filter = ("status", "current_stage", "brand")
    search_fields = ("idea", "brand__name", "id")
    readonly_fields = ("id", "created_at", "updated_at")
    inlines = (CarouselSlideInline,)


@admin.register(StageRun)
class StageRunAdmin(admin.ModelAdmin):
    list_display = ("project", "stage", "status", "capability_status", "attempt", "created_at")
    list_filter = ("stage", "status", "capability_status")
    readonly_fields = ("created_at", "updated_at", "finished_at")


@admin.register(ProjectArtifact)
class ProjectArtifactAdmin(admin.ModelAdmin):
    list_display = ("project", "stage", "artifact_type", "version", "provenance", "created_at")
    list_filter = ("stage", "provenance")
    readonly_fields = ("created_at", "updated_at")


@admin.register(ResearchDecision)
class ResearchDecisionAdmin(admin.ModelAdmin):
    list_display = ("project", "level", "confirmed_by", "confirmed_at")
    list_filter = ("level",)


@admin.register(ResearchSource)
class ResearchSourceAdmin(admin.ModelAdmin):
    list_display = ("project", "title", "publisher", "review_status", "accessed_at")
    list_filter = ("review_status", "publisher")
    search_fields = ("title", "url", "publisher", "excerpt")


@admin.register(GeneratedAsset)
class GeneratedAssetAdmin(admin.ModelAdmin):
    list_display = ("project", "slide", "kind", "mime_type", "byte_size", "is_private", "created_at")
    list_filter = ("kind", "provenance", "is_private")
    readonly_fields = ("created_at", "updated_at")


@admin.register(QualityReport)
class QualityReportAdmin(admin.ModelAdmin):
    list_display = ("project", "axis", "status", "version", "reviewed_by", "reviewed_at")
    list_filter = ("axis", "status", "policy_pack_id")
    readonly_fields = ("created_at", "updated_at")
