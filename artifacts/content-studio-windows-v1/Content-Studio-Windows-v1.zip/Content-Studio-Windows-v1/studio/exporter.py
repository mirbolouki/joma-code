from __future__ import annotations

import hashlib
import io
import json
import zipfile
from datetime import datetime, timezone

from django.conf import settings
from django.db import transaction
from PIL import Image, UnidentifiedImageError

from studio.enums import (
    AssetKind,
    AssetRightsBasis,
    ArtifactProvenance,
    ClaimSourceRelation,
    ClaimStatus,
    ClaimType,
    FormatChoice,
    ProjectStatus,
    ResearchLevel,
    ResearchSourceStatus,
)
from studio.models import GeneratedAsset, Project, ResearchDecision
from studio.quality import final_delivery_blockers
from studio.storage import PrivateLocalStore, UnsafeStorageKey
from studio.rendering.pillow_raqm import RenderSpec
from studio.rendering.skia_canvas import RendererNotReady, SkiaCanvasRenderer


class ExportNotReady(RuntimeError):
    def __init__(self, blockers: list[str]):
        self.blockers = blockers
        super().__init__("خروجی نهایی هنوز آماده نیست: " + "؛ ".join(blockers))


_REQUIRED_IMAGE_KINDS = (AssetKind.IMAGE_PLAIN, AssetKind.PREVIEW, AssetKind.IMAGE_FINAL)
_ALLOWED_MIME_TYPES = {"image/png": "PNG", "image/jpeg": "JPEG"}


@transaction.atomic
def build_project_zip(project_id: str, store: PrivateLocalStore | None = None) -> bytes:
    """Build a real bundle only from stored raster assets and traceable, completed QA."""
    project = Project.objects.select_related("brand", "research_decision").get(pk=project_id)
    store = store or PrivateLocalStore()
    blockers = _delivery_blockers(project, store)
    if blockers:
        raise ExportNotReady(blockers)
    test_only_bundle = _project_is_test_only(project)

    buffer = io.BytesIO()
    asset_entries = []
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        image_assets = project.assets.select_related("slide").filter(kind__in=_REQUIRED_IMAGE_KINDS).order_by(
            "slide__position", "kind"
        )
        for asset in image_assets:
            try:
                content = store.read(asset.storage_key)
            except (OSError, UnsafeStorageKey) as exc:
                raise ExportNotReady([f"فایل خصوصی {asset.storage_key} قابل خواندن نیست."]) from exc
            digest = hashlib.sha256(content).hexdigest()
            if not asset.sha256 or digest != asset.sha256:
                raise ExportNotReady([f"هش فایل {asset.storage_key} با metadata ثبت‌شده هم‌خوان نیست."])
            if asset.byte_size != len(content):
                raise ExportNotReady([f"اندازهٔ فایل {asset.storage_key} با metadata ثبت‌شده هم‌خوان نیست."])
            extension = _validate_raster(asset, content)
            arcname = _archive_name(asset, extension, test_only=test_only_bundle)
            archive.writestr(arcname, content)
            asset_entries.append(
                {
                    "path": arcname,
                    "kind": asset.kind,
                    "slide_position": asset.slide.position,
                    "mime_type": asset.mime_type,
                    "width": asset.width,
                    "height": asset.height,
                    "sha256": digest,
                    "render_input_hash": asset.render_input_hash or None,
                    "provenance": asset.provenance,
                    "provider_id": asset.provider_id or None,
                    "model_name": asset.model_name or None,
                    "rights": {
                        "basis": asset.rights_basis or None,
                        "note": asset.rights_note or None,
                        "source_url": asset.rights_source_url or None,
                        "confirmed": bool(asset.rights_confirmed_by_id and asset.rights_confirmed_at),
                        "confirmed_at": asset.rights_confirmed_at.isoformat() if asset.rights_confirmed_at else None,
                    },
                    "bytes": len(content),
                    "provenance": asset.provenance,
                    "provider_id": asset.provider_id or None,
                    "model_name": asset.model_name or None,
                }
            )

        slides = [
            {
                "position": slide.position,
                "role": slide.role,
                "copy_text": slide.copy_text,
                "visual_direction": slide.visual_direction,
                "image_prompt": slide.image_prompt,
                "layout": slide.layout,
                "claim_links": [
                    {
                        "claim_key": link.claim.key,
                        "copy_excerpt": link.copy_excerpt,
                        "reviewed_content_hash": link.reviewed_content_hash or None,
                        "reviewed_by_id": link.reviewed_by_id,
                        "reviewed_at": link.reviewed_at.isoformat() if link.reviewed_at else None,
                    }
                    for link in slide.claim_links.all()
                ],
            }
            for slide in project.slides.prefetch_related("claim_links__claim").all()
        ]
        decision = project.research_decision
        sources = []
        for source in project.research_sources.prefetch_related("claim_links__claim").all():
            sources.append(
                {
                    "id": source.pk,
                    "url": source.url,
                    "title": source.title,
                    "publisher": source.publisher,
                    "author": source.author,
                    "published_at": source.published_at.isoformat() if source.published_at else None,
                    "accessed_at": source.accessed_at.isoformat() if source.accessed_at else None,
                    "excerpt": source.excerpt,
                    "review_status": source.review_status,
                    "reviewed_content_hash": source.reviewed_content_hash or None,
                    "reviewed_by_id": source.reviewed_by_id,
                    "reviewed_at": source.reviewed_at.isoformat() if source.reviewed_at else None,
                    "claim_links": [
                        {
                            "claim_key": link.claim.key,
                            "relation": link.relation,
                            "evidence_excerpt": link.evidence_excerpt,
                            "reviewed_content_hash": link.reviewed_content_hash or None,
                            "reviewed_by_id": link.reviewed_by_id,
                            "reviewed_at": link.reviewed_at.isoformat() if link.reviewed_at else None,
                        }
                        for link in source.claim_links.all()
                    ],
                }
            )
        claims = [
            {
                "id": claim.pk,
                "key": claim.key,
                "text": claim.text,
                "claim_type": claim.claim_type,
                "requires_source": claim.requires_source,
                "source_requirement_reason": claim.source_requirement_reason,
                "status": claim.status,
                "rationale": claim.rationale,
                "reviewed_content_hash": claim.reviewed_content_hash or None,
                "reviewed_by_id": claim.reviewed_by_id,
                "reviewed_at": claim.reviewed_at.isoformat() if claim.reviewed_at else None,
                "source_links": [
                    {
                        "source_id": link.source_id,
                        "source_url": link.source.url,
                        "relation": link.relation,
                        "evidence_excerpt": link.evidence_excerpt,
                        "reviewed_content_hash": link.reviewed_content_hash or None,
                        "reviewed_by_id": link.reviewed_by_id,
                        "reviewed_at": link.reviewed_at.isoformat() if link.reviewed_at else None,
                    }
                    for link in claim.source_links.all()
                ],
                "slide_links": [
                    {
                        "slide_position": link.slide.position,
                        "copy_excerpt": link.copy_excerpt,
                        "reviewed_content_hash": link.reviewed_content_hash or None,
                        "reviewed_by_id": link.reviewed_by_id,
                        "reviewed_at": link.reviewed_at.isoformat() if link.reviewed_at else None,
                    }
                    for link in claim.slide_links.all()
                ],
            }
            for claim in project.claims.prefetch_related("source_links__source", "slide_links__slide").all()
        ]
        quality = [
            {
                "axis": report.axis,
                "status": report.status,
                "version": report.version,
                "findings": report.findings,
                "blockers": report.blockers,
                "policy_pack_id": report.policy_pack_id or None,
                "policy_pack_version": report.policy_pack_version or None,
                "source_urls": report.source_urls,
                "provider_id": report.provider_id or None,
                "model_name": report.model_name or None,
                "reviewed_content_hash": report.reviewed_content_hash or None,
                "test_only": report.test_only,
                "reviewed_by_id": report.reviewed_by_id,
                "reviewed_at": report.reviewed_at.isoformat() if report.reviewed_at else None,
            }
            for report in project.quality_reports.all().order_by("axis", "-version")
        ]
        artifacts = [
            {
                "stage": artifact.stage,
                "artifact_type": artifact.artifact_type,
                "version": artifact.version,
                "provenance": artifact.provenance,
                "provider_id": artifact.provider_id or None,
                "model_name": artifact.model_name or None,
                "source_urls": artifact.source_urls,
                "payload": artifact.payload,
            }
            for artifact in project.artifacts.all().order_by("stage", "artifact_type", "version")
        ]
        stage_runs = [
            {
                "stage": run.stage,
                "status": run.status,
                "capability_status": run.capability_status,
                "attempt": run.attempt,
                "message": run.message,
                "created_at": run.created_at.isoformat(),
                "finished_at": run.finished_at.isoformat() if run.finished_at else None,
            }
            for run in project.stage_runs.all().order_by("created_at", "stage", "attempt")
        ]
        manifest = {
            "schema_version": "0.9.0",
            "test_only": test_only_bundle,
            "project_test_only": project.test_only,
            "project_id": str(project.pk),
            "brand": {"id": str(project.brand_id), "slug": project.brand.slug, "name": project.brand.name},
            "project_version": project.version,
            "format": project.selected_format or project.requested_format,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "research_decision": {
                "level": decision.level,
                "rationale": decision.rationale,
                "test_only": decision.test_only,
                "confirmed_by_id": decision.confirmed_by_id,
                "confirmed_at": decision.confirmed_at.isoformat() if decision.confirmed_at else None,
            },
            "sources": sources,
            "claims": claims,
            "assets": asset_entries,
            "quality_reports": quality,
            "artifacts": artifacts,
            "stage_runs": stage_runs,
            "provider_credentials_included": False,
        }
        archive.writestr("manifest.json", _json_bytes(manifest))
        readme = (
            "TEST_ONLY — این بستهٔ آزمایشی برای انتشار محصول یا تأیید انسانی واقعی مجاز نیست. تصویرهای پایه TEST_FIXTURE محلی‌اند؛ PNGهای نهایی و preview را renderer محلی ساخته است، نه AI. QAها نیز فرم‌های آزمایشی‌اند، نه بازبینی انسانی واقعی.\n"
            if manifest["test_only"]
            else "این بسته از assetهای رستری ذخیره‌شده، با QA و provenance قابل‌ردیابی ساخته شده است. پیوند claim/source/slide و متن دقیق استفاده‌شده در manifest.json، copy/slides.json و research/claims.json ثبت شده‌اند.\n"
        )
        archive.writestr("README_FA.txt", readme)
        archive.writestr("copy/slides.json", _json_bytes(slides))
        archive.writestr("research/sources.json", _json_bytes(sources))
        archive.writestr("research/claims.json", _json_bytes(claims))
        archive.writestr("qa/reports.json", _json_bytes(quality))

    buffer.seek(0)
    with zipfile.ZipFile(buffer, "r") as verification:
        corrupt = verification.testzip()
        if corrupt:
            raise ExportNotReady([f"آزمون سلامت ZIP در فایل {corrupt} شکست خورد."])
    return buffer.getvalue()


def _project_is_test_only(project: Project) -> bool:
    try:
        decision_is_test_only = project.research_decision.test_only
    except ResearchDecision.DoesNotExist:
        decision_is_test_only = False
    return bool(
        project.test_only
        or decision_is_test_only
        or project.assets.filter(provenance=ArtifactProvenance.TEST_FIXTURE).exists()
        or project.artifacts.filter(provenance=ArtifactProvenance.TEST_FIXTURE).exists()
        or project.quality_reports.filter(test_only=True).exists()
    )


def _delivery_blockers(
    project: Project,
    store: PrivateLocalStore,
    *,
    require_ready_status: bool = True,
) -> list[str]:
    blockers = final_delivery_blockers(project)
    if _project_is_test_only(project) and not settings.STUDIO_TEST_MODE:
        blockers.append("پروژه دادهٔ TEST_ONLY دارد و فقط در محیط test-only قابل بسته‌بندی است.")
    if project.selected_format != FormatChoice.CAROUSEL:
        blockers.append("فقط Carousel در MVP هدف است؛ format نهایی هنوز Carousel نشده است.")
    test_bundle_mode = settings.STUDIO_TEST_MODE and _project_is_test_only(project)
    if (
        require_ready_status
        and project.status not in {ProjectStatus.READY, ProjectStatus.COMPLETED}
        and not test_bundle_mode
    ):
        blockers.append("پروژه status آمادهٔ تحویل ندارد.")

    try:
        decision = project.research_decision
    except ResearchDecision.DoesNotExist:
        decision = None
    if decision is None:
        blockers.append("Research Decision ثبت نشده است.")
    else:
        if decision.test_only and not settings.STUDIO_TEST_MODE:
            blockers.append("Research Decision برچسب TEST_ONLY دارد و در محیط غیرآزمایشی قابل استفاده نیست.")
        if not (decision.confirmed_by_id and decision.confirmed_at):
            blockers.append("Research Decision فاقد تأیید انسانی و زمان ثبت‌شده است.")
        if decision.level == ResearchLevel.REQUIRED:
            reviewed = project.research_sources.filter(
                review_status=ResearchSourceStatus.REVIEWED,
                reviewed_by__isnull=False,
                reviewed_at__isnull=False,
            ).exists()
            if not reviewed:
                blockers.append("Research لازم است اما منبع بازبینی‌شده با هویت و زمان ثبت‌شده‌ای موجود نیست.")

    blockers.extend(_claim_delivery_blockers(project, decision))
    blockers.extend(_claim_slide_delivery_blockers(project))

    slides = list(project.slides.all())
    if not slides:
        blockers.append("هیچ اسلاید Carousel ثبت نشده است.")
    elif not 5 <= len(slides) <= 7:
        blockers.append("Carousel قابل‌تحویل باید ۵ تا ۷ اسلاید داشته باشد.")
    if slides and [slide.position for slide in slides] != list(range(1, len(slides) + 1)):
        blockers.append("شمارهٔ اسلایدها باید از ۱ پیوسته و بدون فاصله باشد.")

    orphan_assets = project.assets.exclude(kind=AssetKind.ZIP).filter(slide__isnull=True)
    if orphan_assets.exists():
        blockers.append("تصویر رستری بدون اتصال به اسلاید وجود دارد.")
    mislinked_assets = project.assets.exclude(kind=AssetKind.ZIP).filter(slide__isnull=False).exclude(slide__project=project)
    if mislinked_assets.exists():
        blockers.append("یک یا چند asset به اسلایدی خارج از همین پروژه متصل است.")

    renderer = SkiaCanvasRenderer()
    for slide in slides:
        assets = list(project.assets.filter(slide=slide))
        assets_by_kind = {kind: [asset for asset in assets if asset.kind == kind] for kind in _REQUIRED_IMAGE_KINDS}
        current_render_input_hash = None
        if len(assets_by_kind[AssetKind.IMAGE_PLAIN]) == 1:
            base = assets_by_kind[AssetKind.IMAGE_PLAIN][0]
            try:
                current_render_input_hash = renderer.render_input_hash(base.sha256, slide.copy_text, RenderSpec())
            except (OSError, ValueError, RendererNotReady):
                blockers.append(f"اسلاید {slide.position}: snapshot ورودی Renderer قابل محاسبه نیست.")

        for kind in _REQUIRED_IMAGE_KINDS:
            matching = assets_by_kind[kind]
            if len(matching) != 1:
                blockers.append(f"اسلاید {slide.position}: دقیقاً یک asset از نوع {kind} لازم است.")
                continue
            asset = matching[0]
            if asset.slide.project_id != project.pk:
                blockers.append(f"اسلاید {slide.position}: asset به پروژهٔ دیگری اشاره می‌کند.")
            if not asset.is_private or not store.exists(asset.storage_key):
                blockers.append(f"اسلاید {slide.position}: فایل خصوصی/ذخیره‌شدهٔ {asset.kind} در دسترس نیست.")
            if asset.mime_type not in _ALLOWED_MIME_TYPES:
                blockers.append(f"اسلاید {slide.position}: فقط PNG یا JPEG برای {asset.kind} مجاز است.")
            if not asset.sha256 or not asset.byte_size or not (asset.width and asset.height):
                blockers.append(f"اسلاید {slide.position}: metadata/hash کامل برای {asset.kind} موجود نیست.")
            if kind == AssetKind.IMAGE_PLAIN:
                if asset.provenance == ArtifactProvenance.PROVIDER_OUTPUT:
                    if not (asset.provider_id and asset.model_name):
                        blockers.append(f"اسلاید {slide.position}: تصویر provider فاقد شناسه یا مدل ثبت‌شده است.")
                elif asset.provenance == ArtifactProvenance.USER_INPUT:
                    if not (
                        asset.rights_basis in AssetRightsBasis.values
                        and asset.rights_note.strip()
                        and asset.rights_confirmed_by_id
                        and asset.rights_confirmed_at
                    ):
                        blockers.append(f"اسلاید {slide.position}: تصویر ورودی فاقد تأیید ثبت‌شدهٔ حقوق استفاده است.")
                elif asset.provenance == ArtifactProvenance.TEST_FIXTURE:
                    if not settings.STUDIO_TEST_MODE:
                        blockers.append(f"اسلاید {slide.position}: تصویر TEST_FIXTURE فقط در test mode مجاز است.")
                else:
                    blockers.append(f"اسلاید {slide.position}: منشأ تصویر پایه معتبر نیست.")
            else:
                if asset.provenance != ArtifactProvenance.SYSTEM_GENERATED:
                    blockers.append(f"اسلاید {slide.position}: {asset.kind} provenance تولید سیستمی ندارد.")
                if not current_render_input_hash or asset.render_input_hash != current_render_input_hash:
                    blockers.append(
                        f"اسلاید {slide.position}: {asset.kind} با تصویر پایه/متن فعلی منطبق نیست؛ دوباره رندر کنید."
                    )

        preview_assets = assets_by_kind[AssetKind.PREVIEW]
        final_assets = assets_by_kind[AssetKind.IMAGE_FINAL]
        if len(preview_assets) == 1 and len(final_assets) == 1:
            if preview_assets[0].sha256 != final_assets[0].sha256:
                blockers.append(f"اسلاید {slide.position}: پیش‌نمایش باید byte-identical با فایل نهایی باشد.")

    return blockers


def _claim_delivery_blockers(project: Project, decision: ResearchDecision | None = None) -> list[str]:
    """Require human-reviewed claims and source evidence before they enter a deliverable."""
    claims = list(project.claims.prefetch_related("source_links__source").all())
    blockers: list[str] = []
    if decision and decision.level == ResearchLevel.REQUIRED and not claims:
        blockers.append("Research لازم است اما هیچ Content Claim ثبت نشده است.")

    source_free_types = {ClaimType.OPINION, ClaimType.CREATIVE, ClaimType.GENERAL_ADVICE}
    for claim in claims:
        label = f"Claim «{claim.key}»"
        if claim.requires_source:
            if claim.status != ClaimStatus.SUPPORTED:
                blockers.append(f"{label} باید با منبع واقعی و بازبینی‌شده پشتیبانی شود.")
        else:
            if claim.claim_type not in source_free_types:
                blockers.append(f"{label} از نوع factual است و نمی‌تواند بدون منبع عبور کند.")
            if not claim.source_requirement_reason.strip():
                blockers.append(f"{label} دلیلِ عدم نیاز به منبع را ثبت نکرده است.")
            if claim.status != ClaimStatus.REVIEWED_NONFACTUAL:
                blockers.append(f"{label} باید به‌عنوان محتوای غیرfactual، انسانی بازبینی شود.")
        if claim.reviewed_content_hash != claim.current_content_hash():
            blockers.append(f"{label} پس از تغییر متن/طبقه‌بندی نیازمند بازبینی دوباره است.")
        if not (claim.reviewed_by_id and claim.reviewed_at):
            blockers.append(f"{label} فاقد reviewer انسانی و زمان بازبینی ثبت‌شده است.")

        links = list(claim.source_links.all())
        for link in links:
            if link.reviewed_content_hash != link.current_content_hash():
                blockers.append(f"{label}: پیوند شاهد/منبع بعد از بازبینی تغییر کرده یا هنوز بازبینی نشده است.")
            if not (link.reviewed_by_id and link.reviewed_at):
                blockers.append(f"{label}: پیوند شاهد/منبع هنوز بازبینی انسانی ندارد.")
            if link.source.reviewed_content_hash != link.source.current_content_hash():
                blockers.append(f"{label}: اطلاعات منبع بعد از بازبینی تغییر کرده یا هنوز snapshot بازبینی ندارد.")
            if (
                link.source.review_status != ResearchSourceStatus.REVIEWED
                or not (link.source.reviewed_by_id and link.source.reviewed_at)
            ):
                blockers.append(f"{label}: منبع متصل هنوز بازبینی انسانی ندارد.")

        reviewed_contradictions = [
            link
            for link in links
            if link.relation == ClaimSourceRelation.CONTRADICTS
            and link.source.project_id == project.pk
            and link.source.review_status == ResearchSourceStatus.REVIEWED
            and link.source.reviewed_by_id
            and link.source.reviewed_at
            and link.reviewed_by_id
            and link.reviewed_at
            and link.reviewed_content_hash == link.current_content_hash()
            and link.source.reviewed_content_hash == link.source.current_content_hash()
        ]
        if reviewed_contradictions:
            blockers.append(f"{label} دارای منبع متعارضِ بازبینی‌شده است؛ ابتدا تعارض را حل کنید.")

        if claim.requires_source:
            has_reviewed_support = any(
                link.relation == ClaimSourceRelation.SUPPORTS
                and link.source.project_id == project.pk
                and bool(link.evidence_excerpt.strip())
                and bool(link.source.excerpt.strip())
                and link.evidence_excerpt.strip() in link.source.excerpt
                and link.source.review_status == ResearchSourceStatus.REVIEWED
                and bool(link.source.reviewed_by_id and link.source.reviewed_at)
                and link.source.reviewed_content_hash == link.source.current_content_hash()
                and bool(link.reviewed_by_id and link.reviewed_at)
                and link.reviewed_content_hash == link.current_content_hash()
                for link in links
            )
            if not has_reviewed_support:
                blockers.append(
                    f"{label} نیازمند منبع پشتیبان با شاهدِ عیناً موجود در متن ثبت‌شدهٔ منبع و بازبینی claim/source است."
                )

    return blockers


def _claim_slide_delivery_blockers(project: Project) -> list[str]:
    """Require every registered claim to map to reviewed, exact slide-copy text."""
    blockers: list[str] = []
    claims = project.claims.prefetch_related("slide_links__slide").all()
    for claim in claims:
        label = f"Claim «{claim.key}»"
        links = list(claim.slide_links.all())
        if not links:
            blockers.append(f"{label} به هیچ اسلایدی از متن نهایی متصل نشده است.")
            continue

        for link in links:
            if link.slide.project_id != project.pk:
                blockers.append(f"{label} به اسلایدی خارج از همین پروژه متصل است.")
            if not link.copy_excerpt.strip() or link.copy_excerpt not in link.slide.copy_text:
                blockers.append(f"{label}: عبارت ثبت‌شده در متن فعلی اسلاید {link.slide.position} پیدا نشد.")
            current_hash = link._hash_content(claim, link.slide, link.copy_excerpt)
            if link.reviewed_content_hash != current_hash:
                blockers.append(f"{label}: متن Claim یا اسلاید بعد از ثبت پیوند تغییر کرده و به بازبینی دوباره نیاز دارد.")
            if not (link.reviewed_by_id and link.reviewed_at):
                blockers.append(f"{label}: پیوند به اسلاید {link.slide.position} هنوز بازبینی انسانی ندارد.")

    return blockers


def _validate_raster(asset: GeneratedAsset, content: bytes) -> str:
    expected_format = _ALLOWED_MIME_TYPES.get(asset.mime_type)
    if not expected_format:
        raise ExportNotReady([f"MIME type فایل {asset.storage_key} برای خروجی مجاز نیست."])
    try:
        with Image.open(io.BytesIO(content)) as image:
            actual_format = image.format
            dimensions = image.size
            image.verify()
    except (OSError, UnidentifiedImageError, Image.DecompressionBombError) as exc:
        raise ExportNotReady([f"فایل {asset.storage_key} تصویر معتبر نیست."]) from exc
    if actual_format != expected_format:
        raise ExportNotReady([f"فرمت واقعی فایل {asset.storage_key} با MIME metadata هم‌خوان نیست."])
    if dimensions != (asset.width, asset.height):
        raise ExportNotReady([f"ابعاد واقعی فایل {asset.storage_key} با metadata هم‌خوان نیست."])
    extension = "jpg" if asset.mime_type == "image/jpeg" else "png"
    return extension


def _archive_name(asset: GeneratedAsset, extension: str, *, test_only: bool = False) -> str:
    position = asset.slide.position
    if asset.kind == AssetKind.IMAGE_FINAL:
        if test_only:
            return f"test-only/final/{position:02d}.final.{extension}"
        return f"publish-ready/{position:02d}.final.{extension}"
    if asset.kind == AssetKind.IMAGE_PLAIN:
        return f"assets/image-plain/{position:02d}.{extension}"
    if asset.kind == AssetKind.PREVIEW:
        return f"previews/slide-{position:02d}.{extension}"
    raise ExportNotReady([f"نوع asset {asset.kind} برای archive ناشناخته است."])


def _json_bytes(value: object) -> bytes:
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8")
