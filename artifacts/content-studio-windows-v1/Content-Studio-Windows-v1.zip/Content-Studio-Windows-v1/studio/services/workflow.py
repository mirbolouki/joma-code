from dataclasses import dataclass

from django.db import transaction
from django.utils import timezone

from studio.enums import CapabilityStatus, PipelineStage, ProjectStatus, RunStatus
from studio.models import Project, StageRun


@dataclass(frozen=True)
class WorkflowResult:
    project_id: str
    stage: str
    status: str
    capability_status: str
    message: str


def start_or_resume_project(project_id: str) -> WorkflowResult:
    """Keep the MVP local/manual: a pipeline retry never probes or initializes providers."""
    return mark_manual_mode_blocked(project_id)


@transaction.atomic
def mark_manual_mode_blocked(project_id: str) -> WorkflowResult:
    """Record the explicitly selected local/manual mode without touching providers or a queue."""
    project = Project.objects.select_for_update().get(pk=project_id)
    stage = project.current_stage or PipelineStage.OPPORTUNITY_ANALYSIS
    message = (
        ("TEST_ONLY پروژهٔ آزمایشی؛ " if project.test_only else "")
        + "حالت محلی/دستی فعال است: هیچ API، provider، صف Celery یا سرویس بیرونی فراخوانی نمی‌شود؛ "
        "متن، تصویر پایه و بازبینی‌ها را دستی وارد کنید."
    )
    return _record_blocker(
        project,
        stage,
        CapabilityStatus.REQUIRES_PROVIDER,
        message,
        details={
            "mode": "manual_local",
            "provider_called": False,
            "queue_called": False,
            "test_only": project.test_only,
        },
    )


def _record_blocker(
    project: Project,
    stage: str,
    capability_status: str,
    message: str,
    *,
    details: dict | None = None,
) -> WorkflowResult:
    previous = StageRun.objects.filter(project=project, stage=stage).order_by("-attempt").first()
    attempt = (previous.attempt + 1) if previous else 1
    StageRun.objects.create(
        project=project,
        stage=stage,
        status=RunStatus.BLOCKED,
        capability_status=capability_status,
        message=message,
        attempt=attempt,
        finished_at=timezone.now(),
        details=details or {},
    )
    project.status = ProjectStatus.BLOCKED
    project.current_stage = stage
    project.save(update_fields=["status", "current_stage", "updated_at"])
    return WorkflowResult(
        project_id=str(project.pk),
        stage=stage,
        status=RunStatus.BLOCKED,
        capability_status=capability_status,
        message=message,
    )
