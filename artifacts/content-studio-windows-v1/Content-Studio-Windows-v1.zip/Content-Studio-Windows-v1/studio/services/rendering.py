from __future__ import annotations

import hashlib
import io
from dataclasses import dataclass

from django.conf import settings
from django.db import transaction
from django.utils import timezone
from PIL import Image, UnidentifiedImageError

from studio.enums import (
    ArtifactProvenance,
    AssetKind,
    AssetRightsBasis,
    CapabilityStatus,
    PipelineStage,
    RunStatus,
)
from studio.models import CarouselSlide, GeneratedAsset, Project, ProjectArtifact, StageRun
from studio.quality import invalidate_quality_reports
from studio.rendering.pillow_raqm import RenderSpec
from studio.rendering.skia_canvas import RendererNotReady, SkiaCanvasRenderer
from studio.storage import PrivateLocalStore


class SlideRenderBlocked(RuntimeError):
    pass


@dataclass(frozen=True)
class RenderedSlideAssets:
    final: GeneratedAsset
    preview: GeneratedAsset
    render_input_hash: str
    metrics: dict


def render_slide_assets(
    project: Project,
    slide: CarouselSlide,
    store: PrivateLocalStore | None = None,
    renderer: SkiaCanvasRenderer | None = None,
) -> RenderedSlideAssets:
    """Create final and byte-identical preview PNGs from an approved base image and saved copy."""
    store = store or PrivateLocalStore()
    renderer = renderer or SkiaCanvasRenderer()
    if slide.project_id != project.pk:
        raise SlideRenderBlocked("اسلاید به همین پروژه تعلق ندارد.")

    base_assets = list(
        project.assets.filter(slide=slide, kind=AssetKind.IMAGE_PLAIN, is_private=True).order_by("created_at")
    )
    if len(base_assets) != 1:
        raise SlideRenderBlocked("برای این اسلاید باید دقیقاً یک تصویر پایهٔ خصوصی وجود داشته باشد.")
    base = base_assets[0]
    if base.provenance == ArtifactProvenance.PROVIDER_OUTPUT:
        if not (base.provider_id and base.model_name):
            raise SlideRenderBlocked("تصویر provider فاقد شناسه یا مدل ثبت‌شده است.")
    elif base.provenance == ArtifactProvenance.USER_INPUT:
        if not (
            base.rights_basis in AssetRightsBasis.values
            and base.rights_note.strip()
            and base.rights_confirmed_by_id
            and base.rights_confirmed_at
        ):
            raise SlideRenderBlocked("ورودی دستی فاقد مبنای مجوز یا تأیید ثبت‌شدهٔ بارگذار است.")
    elif base.provenance == ArtifactProvenance.TEST_FIXTURE:
        if not settings.STUDIO_TEST_MODE:
            raise SlideRenderBlocked("TEST_FIXTURE فقط در محیط test-only مجاز است.")
    else:
        raise SlideRenderBlocked("منشأ تصویر پایه باید USER_INPUT، provider_output یا TEST_FIXTURE مجاز باشد.")
    if base.mime_type not in {"image/png", "image/jpeg"}:
        raise SlideRenderBlocked("تصویر پایه باید PNG یا JPEG معتبر باشد.")

    try:
        image_bytes = store.read(base.storage_key)
    except (OSError, ValueError) as exc:
        raise SlideRenderBlocked("فایل تصویر پایه از storage خصوصی قابل‌خواندن نیست.") from exc
    source_hash = hashlib.sha256(image_bytes).hexdigest()
    if not base.sha256 or source_hash != base.sha256 or len(image_bytes) != base.byte_size:
        raise SlideRenderBlocked("checksum یا اندازهٔ فایل پایه با metadata ثبت‌شده تطابق ندارد.")
    try:
        with Image.open(io.BytesIO(image_bytes)) as image:
            actual_format = image.format
            actual_dimensions = image.size
            image.verify()
    except (OSError, UnidentifiedImageError, Image.DecompressionBombError) as exc:
        raise SlideRenderBlocked("تصویر پایه یک PNG/JPEG سالم نیست.") from exc
    expected_format = "PNG" if base.mime_type == "image/png" else "JPEG"
    if actual_format != expected_format or actual_dimensions != (base.width, base.height):
        raise SlideRenderBlocked("فرمت/ابعاد تصویر پایه با metadata ثبت‌شده تطابق ندارد.")

    try:
        renderer.check_ready()
        spec = RenderSpec()
        render_input_hash = renderer.render_input_hash(source_hash, slide.copy_text, spec)
        rendered_bytes, metrics = renderer.render_overlay_with_metrics(image_bytes, slide.copy_text, spec)
    except (RendererNotReady, ValueError) as exc:
        raise SlideRenderBlocked(f"Renderer آماده نیست یا متن قابل‌چیدمان نیست: {exc}") from exc
    try:
        with Image.open(io.BytesIO(rendered_bytes)) as rendered:
            if rendered.format != "PNG" or rendered.size != (spec.width, spec.height):
                raise SlideRenderBlocked("Renderer خروجی PNG با ابعاد تنظیم‌شده برنگرداند.")
            rendered.verify()
    except (OSError, UnidentifiedImageError, Image.DecompressionBombError) as exc:
        raise SlideRenderBlocked("PNG نهایی تولیدشده معتبر نیست.") from exc

    output_hash = hashlib.sha256(rendered_bytes).hexdigest()
    existing_renders = list(
        project.assets.filter(slide=slide, kind__in=(AssetKind.IMAGE_FINAL, AssetKind.PREVIEW))
    )
    render_inputs_changed = any(
        asset.render_input_hash != render_input_hash or asset.sha256 != output_hash
        for asset in existing_renders
    ) or len(existing_renders) != 2
    staged_files: dict[str, tuple[str, str, int]] = {}
    old_storage_keys: list[str] = []
    try:
        for kind in (AssetKind.IMAGE_FINAL, AssetKind.PREVIEW):
            staged_files[kind] = store.save(str(project.pk), "png", rendered_bytes)

        with transaction.atomic():
            saved_assets: dict[str, GeneratedAsset] = {}
            for kind, (storage_key, digest, byte_size) in staged_files.items():
                existing = list(project.assets.filter(slide=slide, kind=kind).order_by("created_at"))
                if len(existing) > 1:
                    raise SlideRenderBlocked(f"برای نوع {kind} asset تکراری وجود دارد؛ ابتدا آن‌ها را پاکسازی کنید.")
                values = {
                    "storage_key": storage_key,
                    "mime_type": "image/png",
                    "width": spec.width,
                    "height": spec.height,
                    "byte_size": byte_size,
                    "sha256": digest,
                    "render_input_hash": render_input_hash,
                    "provenance": ArtifactProvenance.SYSTEM_GENERATED,
                    "provider_id": "",
                    "model_name": "",
                    "is_private": True,
                }
                if existing:
                    asset = existing[0]
                    old_storage_keys.append(asset.storage_key)
                    for field, value in values.items():
                        setattr(asset, field, value)
                    asset.save(update_fields=[*values, "updated_at"])
                else:
                    asset = GeneratedAsset.objects.create(project=project, slide=slide, kind=kind, **values)
                saved_assets[kind] = asset

            artifact_version = (
                project.artifacts.filter(
                    stage=PipelineStage.PERSIAN_OVERLAY,
                    artifact_type="rendered_slide",
                ).count()
                + 1
            )
            ProjectArtifact.objects.create(
                project=project,
                stage=PipelineStage.PERSIAN_OVERLAY,
                artifact_type="rendered_slide",
                version=artifact_version,
                payload={
                    "slide_position": slide.position,
                    "base_sha256": source_hash,
                    "base_provenance": base.provenance,
                    "base_provider_id": base.provider_id or None,
                    "copy_text_sha256": hashlib.sha256(slide.copy_text.encode("utf-8")).hexdigest(),
                    "render_input_hash": render_input_hash,
                    "final_sha256": output_hash,
                    "renderer": metrics["engine"],
                    "font_family": "Noto Sans Arabic",
                    "font_license": "SIL Open Font License 1.1",
                    "canvas": metrics["canvas"],
                    "line_count": metrics["line_count"],
                },
                provenance=ArtifactProvenance.SYSTEM_GENERATED,
            )
            for stage in (PipelineStage.PERSIAN_OVERLAY, PipelineStage.PREVIEW, PipelineStage.FINAL_ASSETS):
                previous = project.stage_runs.filter(stage=stage).order_by("-attempt").first()
                StageRun.objects.create(
                    project=project,
                    stage=stage,
                    status=RunStatus.COMPLETED,
                    capability_status=CapabilityStatus.NOT_VERIFIED,
                    message=(
                        "متن اسلاید روی تصویر پایهٔ ثبت‌شده رندر و به‌صورت خصوصی ذخیره شد؛ این نتیجهٔ محلی است و target هنوز تأیید نشده."
                    ),
                    attempt=(previous.attempt + 1) if previous else 1,
                    finished_at=timezone.now(),
                    details={
                        "slide_position": slide.position,
                        "render_input_hash": render_input_hash,
                        "asset_sha256": output_hash,
                    },
                )
            if render_inputs_changed:
                invalidate_quality_reports(
                    project,
                    "فایل نهایی/preview تغییر کرده است؛ سه محور QA باید دوباره اجرا شوند.",
                )
    except Exception:
        for storage_key, _, _ in staged_files.values():
            store.delete(storage_key)
        raise

    for old_key in old_storage_keys:
        store.delete(old_key)
    return RenderedSlideAssets(
        final=saved_assets[AssetKind.IMAGE_FINAL],
        preview=saved_assets[AssetKind.PREVIEW],
        render_input_hash=render_input_hash,
        metrics=metrics,
    )
