from __future__ import annotations

import hashlib
import io
import warnings
from dataclasses import dataclass

from django.conf import settings
from django.db import transaction
from django.utils import timezone
from PIL import Image, UnidentifiedImageError

from studio.enums import (
    ArtifactProvenance,
    AssetKind,
    AssetRightsBasis,
    CapabilityStatus,
    PipelineStage,
    RunStatus,
)
from studio.models import CarouselSlide, GeneratedAsset, Project, ProjectArtifact, StageRun
from studio.quality import invalidate_quality_reports
from studio.storage import PrivateLocalStore

MAX_UPLOAD_BYTES = 12 * 1024 * 1024
MAX_IMAGE_PIXELS = 20_000_000
MAX_NORMALIZED_BYTES = 24 * 1024 * 1024
MIN_IMAGE_EDGE = 512


class InvalidImageUpload(ValueError):
    pass


class ImageUploadBlocked(RuntimeError):
    pass


@dataclass(frozen=True)
class NormalizedImageUpload:
    content: bytes
    mime_type: str
    suffix: str
    width: int
    height: int
    sha256: str


def normalize_uploaded_image(uploaded) -> NormalizedImageUpload:
    """Validate and re-encode one bounded PNG/JPEG, stripping metadata before private storage."""
    if not uploaded or not getattr(uploaded, "size", 0):
        raise InvalidImageUpload("فایل تصویر خالی است.")
    if uploaded.size > MAX_UPLOAD_BYTES:
        raise InvalidImageUpload("حجم تصویر باید حداکثر ۱۲ مگابایت باشد.")

    raw = bytearray()
    try:
        uploaded.seek(0)
        for chunk in uploaded.chunks():
            raw.extend(chunk)
            if len(raw) > MAX_UPLOAD_BYTES:
                raise InvalidImageUpload("حجم تصویر باید حداکثر ۱۲ مگابایت باشد.")
    except (OSError, ValueError) as exc:
        if isinstance(exc, InvalidImageUpload):
            raise
        raise InvalidImageUpload("محتوای فایل خوانده نشد.") from exc
    finally:
        try:
            uploaded.seek(0)
        except (AttributeError, OSError, ValueError):
            pass

    if not raw:
        raise InvalidImageUpload("فایل تصویر خالی است.")

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(raw)) as source:
                image_format = source.format
                width, height = source.size
                if image_format not in {"PNG", "JPEG"}:
                    raise InvalidImageUpload("فقط تصویر PNG یا JPEG پذیرفته می‌شود.")
                if width < MIN_IMAGE_EDGE or height < MIN_IMAGE_EDGE:
                    raise InvalidImageUpload("هر ضلع تصویر باید حداقل ۵۱۲ پیکسل باشد.")
                if width * height > MAX_IMAGE_PIXELS:
                    raise InvalidImageUpload("ابعاد تصویر از سقف ۲۰ مگاپیکسل بیشتر است.")
                if getattr(source, "n_frames", 1) != 1:
                    raise InvalidImageUpload("تصویر متحرک پذیرفته نمی‌شود؛ یک PNG/JPEG ثابت بارگذاری کنید.")
                source.verify()

            with Image.open(io.BytesIO(raw)) as source:
                source.load()
                output = io.BytesIO()
                if image_format == "JPEG":
                    source.convert("RGB").save(output, format="JPEG", quality=95, optimize=True)
                    mime_type, suffix = "image/jpeg", "jpg"
                else:
                    mode = "RGBA" if "A" in source.getbands() or "transparency" in source.info else "RGB"
                    source.convert(mode).save(output, format="PNG", optimize=True)
                    mime_type, suffix = "image/png", "png"
                normalized = output.getvalue()
    except InvalidImageUpload:
        raise
    except (
        OSError,
        ValueError,
        SyntaxError,
        Image.DecompressionBombError,
        Image.DecompressionBombWarning,
        UnidentifiedImageError,
    ) as exc:
        raise InvalidImageUpload("فایل تصویر خراب، ناقص یا بیش از حد بزرگ است.") from exc

    if not normalized or len(normalized) > MAX_NORMALIZED_BYTES:
        raise InvalidImageUpload("حجم تصویر نرمال‌شده از سقف مجاز بیشتر است.")

    return NormalizedImageUpload(
        content=normalized,
        mime_type=mime_type,
        suffix=suffix,
        width=width,
        height=height,
        sha256=hashlib.sha256(normalized).hexdigest(),
    )


def register_user_uploaded_base_image(
    project: Project,
    slide: CarouselSlide,
    image: NormalizedImageUpload,
    *,
    uploaded_by,
    rights_basis: str,
    rights_note: str,
    rights_source_url: str = "",
    store: PrivateLocalStore | None = None,
) -> GeneratedAsset:
    """Store a user-provided image only with an authenticated rights attestation."""
    if slide.project_id != project.pk:
        raise ImageUploadBlocked("اسلاید به همین پروژه تعلق ندارد.")
    if rights_basis not in AssetRightsBasis.values:
        raise ImageUploadBlocked("مبنای حق استفاده معتبر نیست.")
    if not rights_note.strip() or not uploaded_by or not uploaded_by.is_authenticated:
        raise ImageUploadBlocked("توضیح مجوز و تأیید کاربر واردشده لازم است.")
    return _store_base_image(
        project,
        slide,
        image,
        provenance=ArtifactProvenance.USER_INPUT,
        rights_basis=rights_basis,
        rights_note=rights_note.strip(),
        rights_source_url=rights_source_url.strip(),
        source_description="",
        uploaded_by=uploaded_by,
        store=store,
    )


def register_local_test_fixture_base_image(
    project: Project,
    slide: CarouselSlide,
    image: NormalizedImageUpload,
    *,
    source_description: str,
    store: PrivateLocalStore | None = None,
) -> GeneratedAsset:
    """Store a locally generated, non-product image under the hard test-only provenance."""
    if not settings.STUDIO_TEST_MODE:
        raise ImageUploadBlocked("TEST_FIXTURE images are disabled outside STUDIO_TEST_MODE.")
    if slide.project_id != project.pk:
        raise ImageUploadBlocked("اسلاید به همین پروژه تعلق ندارد.")
    if not source_description.strip():
        raise ImageUploadBlocked("منشأ تصویر محلی آزمایشی باید ثبت شود.")
    return _store_base_image(
        project,
        slide,
        image,
        provenance=ArtifactProvenance.TEST_FIXTURE,
        rights_basis="",
        rights_note="",
        rights_source_url="",
        source_description=source_description.strip(),
        uploaded_by=None,
        store=store,
    )


def _store_base_image(
    project: Project,
    slide: CarouselSlide,
    image: NormalizedImageUpload,
    *,
    provenance: str,
    rights_basis: str,
    rights_note: str,
    rights_source_url: str,
    source_description: str,
    uploaded_by,
    store: PrivateLocalStore | None,
) -> GeneratedAsset:
    store = store or PrivateLocalStore()
    storage_key, digest, byte_size = store.save(str(project.pk), image.suffix, image.content)
    if digest != image.sha256 or byte_size != len(image.content):
        store.delete(storage_key)
        raise ImageUploadBlocked("یکپارچگی فایل نرمال‌شده تأیید نشد.")

    old_storage_keys: list[str] = []
    is_test_fixture = provenance == ArtifactProvenance.TEST_FIXTURE
    artifact_type = "local_test_fixture_base_image" if is_test_fixture else "user_uploaded_base_image"
    now = timezone.now()
    try:
        with transaction.atomic():
            base_assets = list(
                project.assets.select_for_update().filter(slide=slide, kind=AssetKind.IMAGE_PLAIN).order_by("created_at")
            )
            if len(base_assets) > 1:
                raise ImageUploadBlocked("برای این اسلاید تصویر پایهٔ تکراری وجود دارد؛ ابتدا آن‌ها را پاکسازی کنید.")
            values = {
                "storage_key": storage_key,
                "mime_type": image.mime_type,
                "width": image.width,
                "height": image.height,
                "byte_size": byte_size,
                "sha256": digest,
                "render_input_hash": "",
                "provenance": provenance,
                "provider_id": "",
                "model_name": "",
                "rights_basis": rights_basis,
                "rights_note": rights_note,
                "rights_source_url": rights_source_url,
                "rights_confirmed_by": uploaded_by,
                "rights_confirmed_at": now if uploaded_by else None,
                "is_private": True,
            }
            if base_assets:
                asset = base_assets[0]
                old_storage_keys.append(asset.storage_key)
                for field, value in values.items():
                    setattr(asset, field, value)
                asset.save(update_fields=[*values, "updated_at"])
            else:
                asset = GeneratedAsset.objects.create(
                    project=project,
                    slide=slide,
                    kind=AssetKind.IMAGE_PLAIN,
                    **values,
                )

            stale_renders = list(
                project.assets.filter(slide=slide, kind__in=(AssetKind.IMAGE_FINAL, AssetKind.PREVIEW))
            )
            old_storage_keys.extend(item.storage_key for item in stale_renders)
            for item in stale_renders:
                item.delete()

            artifact_version = (
                project.artifacts.filter(stage=PipelineStage.IMAGE_GENERATION, artifact_type=artifact_type).count() + 1
            )
            payload = {
                "slide_position": slide.position,
                "sha256": digest,
                "mime_type": image.mime_type,
                "width": image.width,
                "height": image.height,
                "bytes": byte_size,
                "provenance": provenance,
                "provider_called": False,
                "test_only": is_test_fixture,
            }
            if is_test_fixture:
                payload["source_description"] = source_description
            else:
                payload.update(
                    {
                        "rights_basis": rights_basis,
                        "rights_note": rights_note,
                        "rights_source_url": rights_source_url,
                        "rights_confirmed_by_id": uploaded_by.pk,
                        "rights_confirmed_at": now.isoformat(),
                    }
                )
            ProjectArtifact.objects.create(
                project=project,
                stage=PipelineStage.IMAGE_GENERATION,
                artifact_type=artifact_type,
                version=artifact_version,
                payload=payload,
                provenance=provenance,
                source_urls=[rights_source_url] if rights_source_url else [],
            )
            if is_test_fixture:
                previous = project.stage_runs.filter(stage=PipelineStage.IMAGE_GENERATION).order_by("-attempt").first()
                StageRun.objects.create(
                    project=project,
                    stage=PipelineStage.IMAGE_GENERATION,
                    status=RunStatus.COMPLETED,
                    capability_status=CapabilityStatus.NOT_VERIFIED,
                    message="تصویر محلی TEST_FIXTURE ثبت شد؛ تصویر محصول، USER_INPUT یا خروجی AI نیست.",
                    attempt=(previous.attempt + 1) if previous else 1,
                    finished_at=now,
                    details={
                        "slide_position": slide.position,
                        "source_provenance": ArtifactProvenance.TEST_FIXTURE,
                        "provider_called": False,
                        "test_only": True,
                    },
                )
            else:
                _record_not_run(
                    project,
                    PipelineStage.IMAGE_GENERATION,
                    slide,
                    "تصویر پایه را کاربر بارگذاری کرده است؛ این مرحله خروجی AI/provider نیست.",
                    source_provenance=ArtifactProvenance.USER_INPUT,
                )
            for stage in (PipelineStage.PERSIAN_OVERLAY, PipelineStage.PREVIEW, PipelineStage.FINAL_ASSETS):
                _record_not_run(
                    project,
                    stage,
                    slide,
                    "تصویر پایه تغییر کرده است؛ رندر و بازبینی دوباره لازم است.",
                    source_provenance=provenance,
                )
            invalidate_quality_reports(
                project,
                "تصویر پایه تغییر کرده؛ بازبینی انسانی باید دوباره انجام شود.",
            )
    except Exception:
        store.delete(storage_key)
        raise

    for old_key in old_storage_keys:
        store.delete(old_key)
    return asset


def _record_not_run(
    project: Project,
    stage: str,
    slide: CarouselSlide,
    message: str,
    *,
    source_provenance: str,
) -> None:
    previous = project.stage_runs.filter(stage=stage).order_by("-attempt").first()
    StageRun.objects.create(
        project=project,
        stage=stage,
        status=RunStatus.NOT_RUN,
        capability_status=CapabilityStatus.NOT_VERIFIED,
        message=message,
        attempt=(previous.attempt + 1) if previous else 1,
        finished_at=timezone.now(),
        details={
            "slide_position": slide.position,
            "source_provenance": source_provenance,
            "provider_called": False,
            "test_only": source_provenance == ArtifactProvenance.TEST_FIXTURE,
        },
    )
