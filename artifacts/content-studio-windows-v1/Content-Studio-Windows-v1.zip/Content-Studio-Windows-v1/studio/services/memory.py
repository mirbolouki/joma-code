import unicodedata

from studio.enums import MemoryStatus
from studio.models import BrandMemoryEntry


_TRANSLATION = str.maketrans({"ي": "ی", "ك": "ک"})


def normalize_memory_text(text: str) -> str:
    """Normalize common Persian/Arabic character variants without deleting ZWNJ."""
    normalized = unicodedata.normalize("NFC", text).translate(_TRANSLATION)
    return " ".join(normalized.casefold().split())


def approved_brand_memory(brand_id, *, kind: str | None = None):
    queryset = BrandMemoryEntry.objects.filter(
        brand_id=brand_id,
        status__in=(MemoryStatus.APPROVED, MemoryStatus.PUBLISHED),
        reviewed_by__isnull=False,
        reviewed_at__isnull=False,
    ).select_related("brand", "project", "reviewed_by")
    if kind:
        queryset = queryset.filter(kind=kind)
    return queryset.order_by("kind", "-updated_at")


def find_exact_brand_memory_match(brand_id, text: str, *, kind: str | None = None):
    key = normalize_memory_text(text)
    if not key:
        return BrandMemoryEntry.objects.none()
    queryset = approved_brand_memory(brand_id).filter(normalized_text=key)
    if kind:
        queryset = queryset.filter(kind=kind)
    return queryset
