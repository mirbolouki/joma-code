"""Loopback-only, test-only settings for the Windows evaluation bundle.

This module deliberately keeps Django CSRF protection enabled. It is not a
production configuration and must only be used by the bundled local launcher.
"""

import os

os.environ["DJANGO_DEBUG"] = "1"
os.environ.setdefault(
    "DJANGO_SECRET_KEY",
    "content-studio-windows-local-test-only-not-for-production",
)

from content_studio.settings import *  # noqa: E402,F403

TEST_DATA_ROOT = BASE_DIR / "var" / "user-test-v1"
TEST_DATA_ROOT.mkdir(parents=True, exist_ok=True)

_port = os.environ.get("STUDIO_TEST_PORT", "8000").strip()
if not _port.isdigit() or not 1 <= int(_port) <= 65535:
    raise RuntimeError("STUDIO_TEST_PORT must be a TCP port number from 1 to 65535.")

DEBUG = True
SECRET_KEY = os.environ["DJANGO_SECRET_KEY"]
ALLOWED_HOSTS = ["127.0.0.1", "localhost", "testserver"]
CSRF_TRUSTED_ORIGINS = [
    f"http://127.0.0.1:{_port}",
    f"http://localhost:{_port}",
]

# Local HTTP only: retain normal same-site browser behavior. Do not disable
# CsrfViewMiddleware or enable cross-site/embedded-preview cookies here.
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False
SESSION_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_SAMESITE = "Lax"
SECURE_SSL_REDIRECT = False

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": TEST_DATA_ROOT / "studio.sqlite3",
        "OPTIONS": {"timeout": 20},
    }
}
PRIVATE_MEDIA_ROOT = TEST_DATA_ROOT / "private-media"
STATIC_ROOT = TEST_DATA_ROOT / "staticfiles"
STUDIO_TEST_MODE = True
CELERY_TASK_ALWAYS_EAGER = True

# The local development server serves static assets itself; keep uploaded and
# generated files in the private local storage path above.
MIDDLEWARE = ["testonly_middleware.ForceTestOnlyMiddleware"] + [
    item for item in MIDDLEWARE if item != "whitenoise.middleware.WhiteNoiseMiddleware"
]
STORAGES = {
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {"BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage"},
}
