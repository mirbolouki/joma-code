"""Seed a synthetic demo through Content Studio's actual Django endpoints."""

from __future__ import annotations

import hashlib
import io
import json
import os
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "test-harness"))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "content_studio_test_settings")

import django

django.setup()

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import Client
from django.urls import reverse
from PIL import Image

from studio.enums import (
    ArtifactProvenance,
    AssetKind,
    FormatChoice,
    PipelineStage,
    ProjectStatus,
    QualityAxis,
    QualityStatus,
    ResearchLevel,
)
from studio.models import BrandProfile, Project
from studio.storage import PrivateLocalStore

USERNAME = "studio-tester"
PASSWORD = os.environ.get("STUDIO_TEST_PASSWORD", "StudioTestV1!24")
IDEA = "TEST_ONLY: چرا با وجود تصمیم جدی، دوباره به عادت قبلی برمی‌گردیم؟"
BRAND_SLUG = "habit-return-test-only"
DEMO_ZIP = ROOT / "prototype-output" / "habit-return-carousel" / "habit-return-carousel_TEST_ONLY_NOT-FOR-PUBLICATION.zip"


def _check_redirect(response, label: str) -> None:
    if response.status_code != 302:
        body = getattr(response, "content", b"").decode("utf-8", errors="replace")[:1200]
        raise RuntimeError(f"{label} failed (HTTP {response.status_code}): {body}")


def _existing_demo(user):
    project = Project.objects.filter(created_by=user, idea=IDEA).first()
    if project is None:
        return None
    if project.slides.count() != 5 or not project.test_only:
        raise RuntimeError(
            "A partial TEST_ONLY demo already exists. It was left unchanged; ask the test owner before repairing it."
        )
    return project


def main() -> None:
    call_command("migrate", verbosity=0, interactive=False)
    if not DEMO_ZIP.is_file():
        raise FileNotFoundError(f"The source snapshot is missing its five-slide fixture ZIP: {DEMO_ZIP}")

    user_model = get_user_model()
    user = user_model.objects.filter(username=USERNAME).first()
    if user is None:
        user = user_model.objects.create_user(username=USERNAME, password=PASSWORD)
    elif not user.check_password(PASSWORD):
        raise RuntimeError(
            f"Test account {USERNAME!r} already exists with a different password; no password was reset."
        )
    if user.is_staff or user.is_superuser:
        raise RuntimeError("The local demo account unexpectedly has administrative privileges.")

    brand, _ = BrandProfile.objects.get_or_create(
        slug=BRAND_SLUG,
        defaults={
            "name": "TEST_ONLY — روایتِ عادت",
            "description": "پروفایل ساختگی برای آزمون محلی؛ دادهٔ مراجعه‌کننده یا برند واقعی نیست.",
            "audience": "مخاطب عمومی بزرگسال؛ بدون دادهٔ فردی یا بالینی.",
            "tone_guidelines": "همدلانه، روشن، غیرتشخیصی، محتاط و بی‌سرزنش.",
            "content_pillars": ["تأمل روزمره", "توصیهٔ عمومی"],
        },
    )
    if not brand.is_active:
        raise RuntimeError("The existing test Brand Profile is inactive; it was left unchanged.")

    project = _existing_demo(user)
    if project is not None:
        print(json.dumps({
            "version": "Content Studio Test v1",
            "project_id": str(project.pk),
            "project_status": project.status,
            "project_test_only": project.test_only,
            "slides": project.slides.count(),
            "reused_existing_data_without_modification": True,
        }, ensure_ascii=False, indent=2))
        return

    client = Client()
    client.force_login(user)
    test_headers = {"HTTP_X_STUDIO_TEST_ONLY": "1"}

    if project is None:
        created = client.post(
            reverse("studio:dashboard"),
            {"brand": str(brand.pk), "idea": IDEA, "requested_format": FormatChoice.CAROUSEL},
            **test_headers,
        )
        _check_redirect(created, "project creation")
        project = Project.objects.get(created_by=user, idea=IDEA)
        if not project.test_only or project.selected_format != FormatChoice.CAROUSEL:
            raise RuntimeError("The project route did not preserve its TEST_ONLY / Carousel state.")

        stage_inputs = (
            (
                PipelineStage.OPPORTUNITY_ANALYSIS,
                "TEST_ONLY: تجربهٔ تصمیم و بازگشت به رفتار آشنا؛ بدون برچسب‌زدن یا نسبت‌دادن علت قطعی.",
            ),
            (
                PipelineStage.STRATEGY,
                "TEST_ONLY: همذات‌پنداری، توضیح محتاطانه، پیشنهاد کوچک و پرسش پایانی؛ بدون تشخیص یا وعدهٔ درمان.",
            ),
            (
                PipelineStage.HOOK,
                "TEST_ONLY: قلاب کوتاه و انسانی دربارهٔ تصمیمی که در موقعیت آشنا دوباره دشوار می‌شود.",
            ),
            (
                PipelineStage.CONTENT_STRUCTURE,
                "TEST_ONLY: پنج بخش از قلاب تا تجربه، بینش محتاطانه، تمرین کوچک و پرسش تأملی.",
            ),
        )
        for stage, content in stage_inputs:
            response = client.post(
                reverse("studio:record_manual_stage_input", kwargs={"project_id": project.pk}),
                {"stage": stage, "content": content},
                **test_headers,
            )
            _check_redirect(response, f"manual editorial stage {stage}")
            artifact = project.artifacts.filter(stage=stage, artifact_type="manual_stage_input").latest("version")
            if not artifact.payload.get("test_only") or artifact.payload.get("provider_called") is not False:
                raise RuntimeError(f"The {stage} stage was not kept local/test-only.")

        research = client.post(
            reverse("studio:save_research_decision", kwargs={"project_id": project.pk}),
            {
                "level": ResearchLevel.NONE,
                "rationale": (
                    "TEST_ONLY: تجربه‌محور و توصیهٔ عمومیِ محتاطانه؛ بدون آمار، تشخیص، وعدهٔ درمان یا ادعای علمی قطعی. "
                    "منبع بیرونی یا واقعیت پژوهشی ادعا نمی‌شود."
                ),
            },
            **test_headers,
        )
        _check_redirect(research, "research decision")
        if not project.research_decision.test_only or project.research_decision.level != ResearchLevel.NONE:
            raise RuntimeError("Research Decision did not remain TEST_ONLY / no external research.")

        with zipfile.ZipFile(DEMO_ZIP) as fixture_archive:
            copy_rows = json.loads(fixture_archive.read("copy/slides.json"))
            if len(copy_rows) != 5:
                raise RuntimeError("The saved local carousel fixture does not contain five slides.")
            store = PrivateLocalStore()
            for position, copy_row in enumerate(copy_rows, start=1):
                text = copy_row["copy_text"]
                if "TEST_ONLY" not in text or "NOT FOR PUBLICATION" not in text:
                    raise RuntimeError(f"Slide {position} is missing its test-only warning labels.")
                slide_response = client.post(
                    reverse("studio:add_carousel_slide", kwargs={"project_id": project.pk}),
                    {"role": copy_row["role"], "copy_text": text},
                    **test_headers,
                )
                _check_redirect(slide_response, f"slide {position} creation")
                slide = project.slides.get(position=position)

                base_bytes = fixture_archive.read(f"assets/image-plain/{position:02d}.png")
                upload = client.post(
                    reverse("studio:upload_slide_base_image", kwargs={"project_id": project.pk, "slide_id": slide.pk}),
                    {
                        f"fixture-{slide.pk}-image": SimpleUploadedFile(
                            f"TEST_ONLY-base-{position}.png", base_bytes, content_type="image/png"
                        )
                    },
                    HTTP_X_STUDIO_TEST_ONLY="1",
                    HTTP_X_STUDIO_TEST_FIXTURE="1",
                )
                _check_redirect(upload, f"slide {position} local fixture upload")
                base = project.assets.get(slide=slide, kind=AssetKind.IMAGE_PLAIN)
                if base.provenance != ArtifactProvenance.TEST_FIXTURE:
                    raise RuntimeError(f"Slide {position} background was not marked TEST_FIXTURE.")

                render = client.post(
                    reverse("studio:render_slide_asset", kwargs={"project_id": project.pk, "slide_id": slide.pk})
                )
                _check_redirect(render, f"slide {position} renderer route")
                final = project.assets.get(slide=slide, kind=AssetKind.IMAGE_FINAL)
                preview = project.assets.get(slide=slide, kind=AssetKind.PREVIEW)
                final_bytes = store.read(final.storage_key)
                if (final.width, final.height) != (1080, 1350) or final_bytes != store.read(preview.storage_key):
                    raise RuntimeError(f"Slide {position} final and preview failed size/identity checks.")
                with Image.open(io.BytesIO(final_bytes)) as image:
                    image.load()
                    if image.format != "PNG" or image.size != (1080, 1350):
                        raise RuntimeError(f"Slide {position} is not a valid 1080×1350 PNG.")
                preview_response = client.get(
                    reverse("studio:preview_final_asset", kwargs={"project_id": project.pk, "asset_id": final.pk})
                )
                if preview_response.status_code != 200 or b"".join(preview_response.streaming_content) != final_bytes:
                    raise RuntimeError(f"Slide {position} preview endpoint did not return the final PNG bytes.")

        for axis in QualityAxis:
            prefix = f"qa-{axis}"
            result = client.post(
                reverse("studio:record_quality_review", kwargs={"project_id": project.pk, "axis": axis}),
                {
                    f"{prefix}-status": QualityStatus.PASS,
                    f"{prefix}-policy_pack_id": f"TEST_ONLY-local-technical-check-{axis}",
                    f"{prefix}-policy_pack_version": "local-test-v1",
                    f"{prefix}-source_urls": "",
                    f"{prefix}-findings": (
                        "TEST_ONLY: technical flow/integrity check only; no human review, platform-policy audit, "
                        "or permission to publish. NOT FOR PUBLICATION."
                    ),
                    f"{prefix}-blockers": "",
                },
                **test_headers,
            )
            _check_redirect(result, f"TEST_ONLY QA route {axis}")
            report = project.quality_reports.filter(axis=axis).order_by("-version").first()
            if report.status != QualityStatus.PASS or not report.test_only:
                raise RuntimeError(f"QA axis {axis} did not remain explicitly TEST_ONLY.")

    project.refresh_from_db()
    if not project.test_only or project.status != ProjectStatus.NEEDS_REVIEW or project.slides.count() != 5:
        raise RuntimeError("The demo did not remain a five-slide TEST_ONLY / NEEDS_REVIEW project.")

    download = client.post(reverse("studio:download_project_zip", kwargs={"project_id": project.pk}))
    if download.status_code != 200 or download["Content-Type"] != "application/zip":
        raise RuntimeError(f"The actual ZIP download route failed (HTTP {download.status_code}).")
    downloaded_zip = b"".join(download.streaming_content)
    with zipfile.ZipFile(io.BytesIO(downloaded_zip)) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("The application ZIP failed its CRC test.")
        names = set(archive.namelist())
        manifest = json.loads(archive.read("manifest.json"))
        if not manifest["test_only"] or not manifest["project_test_only"]:
            raise RuntimeError("The downloaded ZIP lost its TEST_ONLY markers.")
        if any(name.startswith("publish-ready/") for name in names):
            raise RuntimeError("A TEST_ONLY ZIP unexpectedly contains a publish-ready path.")
        if len([name for name in names if name.startswith("test-only/final/") and name.endswith(".png")]) != 5:
            raise RuntimeError("The downloaded ZIP does not contain five test-only final PNGs.")

    zip_asset = project.assets.get(kind=AssetKind.ZIP)
    if PrivateLocalStore().read(zip_asset.storage_key) != downloaded_zip:
        raise RuntimeError("The private ZIP asset differs from the bytes returned by the download view.")
    detail = client.get(reverse("studio:project_detail", kwargs={"project_id": project.pk}))
    if detail.status_code != 200 or "TEST_ONLY project" not in detail.content.decode("utf-8"):
        raise RuntimeError("The actual project detail page did not expose its TEST_ONLY status.")

    report = {
        "version": "Content Studio Test v1",
        "project_id": str(project.pk),
        "project_status": project.status,
        "project_test_only": project.test_only,
        "slides": project.slides.count(),
        "renderer": "@napi-rs/canvas (Skia/HarfBuzz)",
        "zip_bytes": len(downloaded_zip),
        "zip_sha256": hashlib.sha256(downloaded_zip).hexdigest(),
        "real_human_review": False,
        "provider_called": False,
        "publication_allowed": False,
    }
    report_path = settings.TEST_DATA_ROOT / "seed-report.json"
    if not report_path.exists():
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"username": USERNAME, **report}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
