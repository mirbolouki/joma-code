"""Local test-only guard; never included in the Content Studio application package."""


class ForceTestOnlyMiddleware:
    """Mark browser POSTs as TEST_ONLY so the test server cannot publish a project."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.method == "POST":
            request.META["HTTP_X_STUDIO_TEST_ONLY"] = "1"
        return self.get_response(request)
