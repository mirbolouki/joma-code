(() => {
  'use strict';
  const stage = document.querySelector('#owl');
  const pupils = [document.querySelector('#pupil-left'), document.querySelector('#pupil-right')];
  const eyes = [{ x: 416, y: 416 }, { x: 621, y: 357 }];
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let pointer = null, blinkTimer;
  function reset() { pupils.forEach(p => { p.style.transform = ''; }); }
  function update(e) {
    if (motion.matches) return;
    const rect = stage.getBoundingClientRect();
    const x = (e.clientX - rect.left) * 912 / rect.width;
    const y = (e.clientY - rect.top) * 1136 / rect.height;
    eyes.forEach((eye, i) => {
      const dx = x - eye.x, dy = y - eye.y;
      const distance = Math.hypot(dx, dy);
      const strength = Math.min(distance / 180, 1);
      const px = distance ? dx / distance * 7 * strength : 0;
      const py = distance ? dy / distance * 5 * strength : 0;
      const hover = Math.hypot(dx / 52, dy / 49) < 1;
      // Scale around each pupil's own center; limited translation stays inside its eye mask.
      pupils[i].style.transform = `translate(${px}px, ${py}px) scale(${hover ? 1.1 : 1})`;
    });
  }
  function blink() {
    if (motion.matches) return;
    clearTimeout(blinkTimer); stage.classList.remove('is-blinking');
    requestAnimationFrame(() => { stage.classList.add('is-blinking'); blinkTimer = setTimeout(() => stage.classList.remove('is-blinking'), 300); });
  }
  stage.addEventListener('pointerdown', e => {
    if (!e.isPrimary || (e.pointerType === 'mouse' && e.button !== 0)) return;
    pointer = { id: e.pointerId, x: e.clientX, y: e.clientY, moved: false };
    update(e);
  });
  stage.addEventListener('pointermove', e => {
    if (pointer && e.pointerId === pointer.id && Math.hypot(e.clientX - pointer.x, e.clientY - pointer.y) > 10) pointer.moved = true;
    if (e.pointerType === 'mouse' || (pointer && pointer.id === e.pointerId)) update(e);
  });
  stage.addEventListener('pointerup', e => {
    if (!pointer || pointer.id !== e.pointerId) return;
    if (!pointer.moved) blink();
    pointer = null;
    if (e.pointerType !== 'mouse') reset();
  });
  stage.addEventListener('pointercancel', () => { pointer = null; reset(); });
  stage.addEventListener('pointerleave', () => { pointer = null; reset(); });
  stage.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (!e.repeat) blink(); } });
  motion.addEventListener('change', () => { if (motion.matches) { clearTimeout(blinkTimer); stage.classList.remove('is-blinking'); reset(); } });
})();
