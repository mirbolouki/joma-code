#!/usr/bin/env python3
import hashlib, json, pathlib, struct
root = pathlib.Path(__file__).resolve().parent.parent
manifest = json.loads((root / 'approved-assets-lock.json').read_text(encoding='utf8'))
for item in manifest['assets']:
    file = root / item['path']
    data = file.read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n', f'Not PNG: {file}'
    assert struct.unpack('>II', data[16:24]) == (item['width'], item['height']), f'Dimensions changed: {file}'
    assert hashlib.sha256(data).hexdigest() == item['sha256'], f'Asset changed: {file}'
print(f"Validated {len(manifest['assets'])} locked assets")
