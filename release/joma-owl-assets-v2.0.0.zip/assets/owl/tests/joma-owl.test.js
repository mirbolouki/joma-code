'use strict';
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const pending = [];
class FakeImage { set src(v) { this.url = v; pending.push(this); } }
const document = {
  currentScript: { src: 'https://example.test/assets/owl/component/joma-owl.js' },
  baseURI: 'https://example.test/app/',
  createElement: () => ({ dataset: {}, classList: { toggle() {} }, remove() { this.removed = true; } })
};
const context = { window: {}, document, Image: FakeImage, URL, Promise, TypeError, Error };
vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../component/joma-owl.js'), 'utf8'), context);
(async () => {
  let img;
  const owl = context.window.JomaOwl.create({ appendChild(el) { img = el; } });
  assert.strictEqual(img.alt, '');
  const first = owl.setState('thinking');
  const second = owl.setState('answering');
  pending[1].onload();
  pending[0].onload();
  assert.strictEqual(await second, true);
  assert.strictEqual(await first, false);
  assert.strictEqual(owl.getState(), 'answering');
  assert.strictEqual(img.src, 'https://example.test/assets/owl/runtime/answering.png');
  await assert.rejects(owl.setState('not-a-state'), /Unknown owl state/);
  const failure = owl.setState('error');
  pending[2].onerror();
  await assert.rejects(failure, /Failed to load/);
  assert.strictEqual(owl.getState(), 'answering');
  const late = owl.setState('processing');
  owl.destroy();
  pending[3].onload();
  assert.strictEqual(await late, false);
  assert.strictEqual(img.removed, true);
  await assert.rejects(owl.setState('idle'), /destroyed/);
  console.log('JomaOwl component tests passed');
})().catch(e => { console.error(e); process.exitCode = 1; });
