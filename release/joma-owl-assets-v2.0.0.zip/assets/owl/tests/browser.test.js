const { chromium: play } = require('playwright');

(async()=>{

 const browser=await play.launch({headless:true});
 for (const mobile of [false,true]){
  const context=await browser.newContext(mobile?{viewport:{width:390,height:844},hasTouch:true,isMobile:true}:{viewport:{width:1280,height:900}});
  const page=await context.newPage(); let errors=[]; page.on('pageerror',e=>errors.push(e.message));
  await page.goto((process.env.OWL_BASE_URL || 'http://127.0.0.1:8000') + '/state-demo/',{waitUntil:'networkidle'});
  await page.waitForSelector('#owl svg'); await page.waitForFunction(()=>document.querySelector('#owl img').dataset.state==='greeting');
  const box=await page.locator('#owl').boundingBox();
  if(!mobile){await page.mouse.move(box.x+box.width*.456,box.y+box.height*.366); await page.waitForTimeout(230); if(!await page.locator('#owl svg').evaluate(e=>e.classList.contains('joma-owl-eyes-active'))) throw Error('desktop hover failed'); await page.mouse.click(box.x+box.width*.45,box.y+box.height*.36);}
  else {await page.touchscreen.tap(box.x+box.width*.45,box.y+box.height*.36);}
  if(!await page.locator('#owl svg').evaluate(e=>e.classList.contains('joma-owl-blinking'))) throw Error('blink failed');
  await page.getByRole('button',{name:'استراحت',exact:true}).click(); await page.waitForFunction(()=>document.querySelector('#owl img').dataset.state==='sleeping');
  if(await page.locator('#owl svg').evaluate(e=>e.classList.contains('joma-owl-eyes-active'))) throw Error('sleep overlay active');
  await page.emulateMedia({reducedMotion:'reduce'}); await page.getByRole('button',{name:'خوشامد',exact:true}).click(); await page.waitForFunction(()=>document.querySelector('#owl img').dataset.state==='greeting');
  await page.locator('#owl').focus(); await page.keyboard.press('Enter'); if(await page.locator('#owl svg').evaluate(e=>e.classList.contains('joma-owl-blinking'))) throw Error('reduced motion failed');
  if(errors.length) throw Error(errors.join('; ')); console.log((mobile?'mobile emulation':'desktop')+' passed (Chromium '+browser.version()+')');
  await context.close();
 }
 await browser.close();
})().catch(e=>{console.error(e);process.exitCode=1});
