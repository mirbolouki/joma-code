'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const {JSDOM} = require('jsdom');
(async () => {
 const dom = new JSDOM('<aside data-joma-owl-state="happy"><button data-owl-toggle></button><div data-owl-stage hidden></div></aside>', {url:'https://example.test/',runScripts:'outside-only'});
 const w=dom.window; let chosen=null, destroyed=0;
 w.JomaOwlEyes={}; w.JomaOwl={create:()=>({setState:s=>{chosen=s;return Promise.resolve(true)},destroy:()=>{destroyed++}})};
 w.eval(fs.readFileSync(path.join(__dirname,'../component/joma-owl-presence.js'),'utf8'));
 w.document.dispatchEvent(new w.Event('DOMContentLoaded'));
 const button=w.document.querySelector('button'), stage=w.document.querySelector('[data-owl-stage]');
 assert(stage.hidden); button.click(); assert(!stage.hidden); assert.strictEqual(chosen,'happy');
 assert.strictEqual(w.localStorage.getItem('joma_owl_presence_v1'),'on'); assert.strictEqual(button.getAttribute('aria-expanded'),'true');
 button.click(); assert(stage.hidden); assert.strictEqual(destroyed,1); assert.strictEqual(w.localStorage.getItem('joma_owl_presence_v1'),'off');
 console.log('Presence controls passed'); dom.window.close();
})().catch(err=>{console.error(err);process.exitCode=1});
