#!/usr/bin/env python3
"""Create an alpha-matted PNG from a green-background source.
Requires Pillow and NumPy. This heuristic is specific to these owl assets;
inspect the result on light and dark backgrounds before release.
"""
import sys
import numpy as np
from PIL import Image

if len(sys.argv) != 3:
    raise SystemExit('Usage: python remove-green.py INPUT OUTPUT')
im = Image.open(sys.argv[1]).convert('RGBA')
pixels = np.asarray(im).astype(np.float32)
r, g, b, a = (pixels[:, :, i] for i in range(4))
# Green excess is absent from the blue, cream and yellow palette. A soft
# threshold retains partially transparent fine fur better than flood fill.
excess = g - np.maximum(r, b)
alpha = np.clip((70.0 - excess) / 55.0, 0.0, 1.0) * a / 255.0
# Remove residual green spill only where green dominates both other channels.
spill = np.maximum(excess, 0.0)
pixels[:, :, 1] = g - spill * np.clip((excess - 3.0) / 20.0, 0.0, 1.0)
pixels[:, :, 3] = alpha * 255.0
Image.fromarray(np.clip(pixels, 0, 255).astype(np.uint8), 'RGBA').save(sys.argv[2], optimize=True)
