/* Joma Owl: framework-free, experimental static-state presentation component. */
(function (global) {
  'use strict';
  var script = document.currentScript;
  var defaultBase = script && script.src ? new URL('../', script.src).href : '';
  var sources = {
    idle: 'runtime/processing.png',
    greeting: 'runtime/greeting.png',
    listening: 'runtime/listening.png',
    thinking: 'runtime/thinking.png',
    processing: 'runtime/processing.png',
    answering: 'runtime/answering.png',
    learning: 'runtime/learning.png',
    curious: 'runtime/curious.png',
    happy: 'runtime/happy.png',
    celebrating: 'runtime/success.png',
    confused: 'runtime/confused.png',
    error: 'runtime/error.png',
    sleeping: 'runtime/sleeping.png',
    encouraging: 'runtime/encouraging.png'
  };
  function create(container, options) {
    if (!container || !container.appendChild) throw new TypeError('A container element is required');
    options = options || {};
    var base = options.baseUrl || defaultBase;
    if (!base) throw new Error('Pass baseUrl when the script URL is unavailable');
    base = new URL(base, document.baseURI);
    if (base.href.slice(-1) !== '/') base = new URL(base.href + '/');
    var image = document.createElement('img');
    image.className = 'joma-owl-image';
    image.alt = ''; // Presentation only; the host provides status and controls.
    image.decoding = 'async';
    var state = null;
    var destroyed = false;
    var generation = 0;
    if (options.interactive && !global.JomaOwlEyes) throw new Error('Load joma-owl-eyes.js before enabling interaction');
    container.appendChild(image);
    var eyes = options.interactive && global.JomaOwlEyes ? global.JomaOwlEyes.attach(container) : null;
    var visible = true;
    function updateVisibility() {
      image.classList.toggle('joma-owl-paused', !visible || document.hidden);
    }
    if (document.addEventListener) document.addEventListener('visibilitychange', updateVisibility);
    var observer = typeof IntersectionObserver !== 'undefined' ? new IntersectionObserver(function (entries) {
      visible = entries[0].isIntersecting;
      updateVisibility();
    }) : null;
    if (observer) observer.observe(container);
    updateVisibility();
    function setState(next) {
      if (destroyed) return Promise.reject(new Error('Component has been destroyed'));
      if (!Object.prototype.hasOwnProperty.call(sources, next)) return Promise.reject(new Error('Unknown owl state: ' + next));
      var id = ++generation;
      var src = new URL(sources[next], base).href;
      return new Promise(function (resolve, reject) {
        var preload = new Image();
        preload.onload = function () {
          if (destroyed || id !== generation) return resolve(false);
          image.src = src;
          image.dataset.state = next;
          state = next;
          if (eyes) eyes.setState(next);
          resolve(true);
        };
        preload.onerror = function () {
          if (destroyed || id !== generation) return resolve(false);
          reject(new Error('Failed to load owl asset: ' + next));
        };
        preload.src = src;
      });
    }
    return {
      setState: setState,
      getState: function () { return state; },
      destroy: function () { destroyed = true; generation++; if (eyes) eyes.destroy(); if (observer) observer.disconnect(); if (document.removeEventListener) document.removeEventListener('visibilitychange', updateVisibility); image.remove(); }
    };
  }
  global.JomaOwl = { create: create, states: Object.keys(sources) };
})(window);
