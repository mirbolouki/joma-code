/* Experimental interactive SVG overlay for the approved master-derived poses. */
(function (global) {
  'use strict';
  var markup = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 912 1136\">\n<defs><radialGradient id=\"iris\"><stop offset=\"0\" stop-color=\"#37200c\"/><stop offset=\".68\" stop-color=\"#6d3409\"/><stop offset=\"1\" stop-color=\"#a05b11\"/></radialGradient><radialGradient id=\"black\"><stop offset=\"0\" stop-color=\"#050608\"/><stop offset=\".8\" stop-color=\"#101012\"/><stop offset=\"1\" stop-color=\"#231809\"/></radialGradient><clipPath id=\"left-clip\"><circle cx=\"416\" cy=\"416\" r=\"35\"/></clipPath><clipPath id=\"right-clip\"><circle cx=\"621\" cy=\"357\" r=\"35\"/></clipPath></defs>\n<!-- Experimental replacement over the baked-in pupil, not an extracted original layer. -->\n<circle cx=\"416\" cy=\"416\" r=\"34\" fill=\"url(#iris)\"/><circle cx=\"621\" cy=\"357\" r=\"34\" fill=\"url(#iris)\"/>\n<g clip-path=\"url(#left-clip)\"><g id=\"pupil-left\" class=\"joma-owl-pupil\"><circle cx=\"416\" cy=\"416\" r=\"25\" fill=\"url(#black)\"/><circle cx=\"408\" cy=\"405\" r=\"6\" fill=\"#fff\"/><circle cx=\"425\" cy=\"410\" r=\"2.5\" fill=\"#eef7ff\" opacity=\".9\"/></g></g>\n<g clip-path=\"url(#right-clip)\"><g id=\"pupil-right\" class=\"joma-owl-pupil\"><circle cx=\"621\" cy=\"357\" r=\"25\" fill=\"url(#black)\"/><circle cx=\"613\" cy=\"346\" r=\"6\" fill=\"#fff\"/><circle cx=\"630\" cy=\"351\" r=\"2.5\" fill=\"#eef7ff\" opacity=\".9\"/></g></g>\n<g class=\"joma-owl-blink\"><ellipse cx=\"416\" cy=\"416\" rx=\"52\" ry=\"49\" fill=\"#ead7b6\"/><path d=\"M366 417 Q416 447 466 417\" fill=\"none\" stroke=\"#493628\" stroke-width=\"7\" stroke-linecap=\"round\"/></g>\n</svg>";
  var counter = 0;
  function attach(container) {
    var prefix = 'joma-eye-' + (++counter) + '-';
    var svgText = markup.replace(/id="(iris|black|left-clip|right-clip|pupil-left|pupil-right)"/g, function (_, id) { return 'id="' + prefix + id + '"'; }).replace(/url\(#(iris|black|left-clip|right-clip)\)/g, function (_, id) { return 'url(#' + prefix + id + ')'; });
    container.insertAdjacentHTML('beforeend', svgText);
    var overlay = container.lastElementChild;
    overlay.classList.add('joma-owl-eyes');
    overlay.setAttribute('aria-hidden', 'true');
    var pupils = [overlay.querySelector('#' + prefix + 'pupil-left'), overlay.querySelector('#' + prefix + 'pupil-right')];
    var eyes = [{ x: 416, y: 416 }, { x: 621, y: 357 }];
    var motion = global.matchMedia ? global.matchMedia('(prefers-reduced-motion: reduce)') : {matches:false, addListener:function(){}, removeListener:function(){}};
    var pointer = null, timer = null, autoTimer = null, state = '', active = false, visible = true, destroyed = false;
    container.classList.add('joma-owl-interactive');
    container.setAttribute('role', 'button');
    container.setAttribute('tabindex', '0');
    container.setAttribute('aria-label', 'جغد جوما؛ برای چشمک زدن فعال کنید');
    function show(on) { overlay.classList.toggle('joma-owl-eyes-active', !!on && !motion.matches && state !== 'sleeping'); }
    function reset() { pupils.forEach(function (p) { p.style.transform = ''; }); }
    function update(event) {
      if (motion.matches || state === 'sleeping') return;
      var rect = container.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      var x = (event.clientX - rect.left) * 912 / rect.width;
      var y = (event.clientY - rect.top) * 1136 / rect.height;
      show(true);
      eyes.forEach(function (eye, i) {
        var dx = x - eye.x, dy = y - eye.y, distance = Math.hypot(dx, dy), strength = Math.min(distance / 180, 1);
        var px = distance ? dx / distance * 7 * strength : 0;
        var py = distance ? dy / distance * 5 * strength : 0;
        var hover = Math.hypot(dx / 52, dy / 49) < 1;
        pupils[i].style.transform = 'translate(' + px + 'px,' + py + 'px) scale(' + (hover ? 1.1 : 1) + ')';
      });
    }
    function blink() {
      if (motion.matches || state === 'sleeping') return;
      show(true); clearTimeout(timer);
      overlay.classList.add('joma-owl-blinking');
      timer = setTimeout(function () { timer = null; overlay.classList.remove('joma-owl-blinking'); if (!active) { reset(); show(false); } }, 300);
    }
    function scheduleBlink() {
      clearTimeout(autoTimer); autoTimer = null;
      if (destroyed || motion.matches || document.hidden || !visible || !state || state === 'sleeping') return;
      autoTimer = setTimeout(function () { if (!active) blink(); scheduleBlink(); }, 7000 + Math.random() * 5000);
    }
    function visibility() { scheduleBlink(); if (document.hidden || !visible) { reset(); show(false); } }
    var observer = typeof IntersectionObserver !== 'undefined' ? new IntersectionObserver(function (entries) { visible = entries[0].isIntersecting; visibility(); }) : null;
    if (observer) observer.observe(container);
    document.addEventListener('visibilitychange', visibility);
    function down(e) { if (!e.isPrimary || (e.pointerType === 'mouse' && e.button !== 0)) return; pointer = { id:e.pointerId, x:e.clientX, y:e.clientY, moved:false }; active = true; update(e); }
    function move(e) { if (pointer && pointer.id === e.pointerId && Math.hypot(e.clientX-pointer.x,e.clientY-pointer.y)>10) pointer.moved=true; if (e.pointerType === 'mouse' || (pointer && pointer.id === e.pointerId)) { active = true; update(e); } }
    function up(e) { if (!pointer || pointer.id !== e.pointerId) return; if (!pointer.moved) blink(); pointer = null; if (e.pointerType !== 'mouse') { active=false; if (!timer) { reset(); show(false); } } }
    function leave() { pointer=null; active=false; reset(); if (!overlay.classList.contains('joma-owl-blinking')) show(false); }
    function key(e) { if ((e.key === 'Enter' || e.key === ' ') && !e.repeat) { e.preventDefault(); blink(); } }
    function reduced() { if (motion.matches) { clearTimeout(timer); timer=null; overlay.classList.remove('joma-owl-blinking'); reset(); show(false); } scheduleBlink(); }
    container.addEventListener('pointerdown',down); container.addEventListener('pointermove',move); container.addEventListener('pointerup',up); container.addEventListener('pointercancel',leave); container.addEventListener('pointerleave',leave); container.addEventListener('keydown',key); if (motion.addEventListener) motion.addEventListener('change',reduced); else motion.addListener(reduced);
    return { setState:function(next) { state=next; if (next==='sleeping') { reset(); show(false); } scheduleBlink(); }, destroy:function() { destroyed=true; clearTimeout(timer); clearTimeout(autoTimer); if (observer) observer.disconnect(); document.removeEventListener('visibilitychange',visibility); container.removeEventListener('pointerdown',down); container.removeEventListener('pointermove',move); container.removeEventListener('pointerup',up); container.removeEventListener('pointercancel',leave); container.removeEventListener('pointerleave',leave); container.removeEventListener('keydown',key); if (motion.removeEventListener) motion.removeEventListener('change',reduced); else motion.removeListener(reduced); container.classList.remove('joma-owl-interactive'); container.removeAttribute('role'); container.removeAttribute('tabindex'); container.removeAttribute('aria-label'); overlay.remove(); } };
  }
  global.JomaOwlEyes = { attach:attach };
})(window);
