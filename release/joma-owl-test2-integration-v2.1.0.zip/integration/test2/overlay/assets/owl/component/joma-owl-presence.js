(function () {
  'use strict';
  function init() {
    document.querySelectorAll('[data-joma-owl-state]').forEach(function (root) {
      var button = root.querySelector('[data-owl-toggle]');
      var stage = root.querySelector('[data-owl-stage]');
      var owl = null;
      var enabled = false;
      try { enabled = localStorage.getItem('joma_owl_presence_v1') === 'on'; } catch (_) {}
      function render() {
        stage.hidden = !enabled;
        button.setAttribute('aria-expanded', enabled ? 'true' : 'false');
        button.textContent = enabled ? 'پنهان کردن همراه جوما' : 'نمایش همراه جوما';
        if (!enabled && owl) { owl.destroy(); owl = null; }
        if (enabled && !owl && window.JomaOwl && window.JomaOwlEyes) {
          owl = window.JomaOwl.create(stage, { interactive: true });
          var instance = owl;
          instance.setState(root.dataset.jomaOwlState).catch(function () { if (owl !== instance) return; owl.destroy(); owl = null; enabled = false; stage.hidden = true; button.setAttribute('aria-expanded', 'false'); button.textContent = 'نمایش همراه جوما'; });
        }
      }
      document.addEventListener('joma:owl-state', function (event) {
        var state = event.detail && event.detail.state;
        if (['processing', 'happy', 'error', 'encouraging'].indexOf(state) === -1) return;
        root.dataset.jomaOwlState = state;
        if (owl) owl.setState(state).catch(function () {});
      });
      button.addEventListener('click', function () {
        enabled = !enabled;
        try { localStorage.setItem('joma_owl_presence_v1', enabled ? 'on' : 'off'); } catch (_) {}
        render();
      });
      render();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
