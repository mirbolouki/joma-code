'use strict';
const assert=require('assert'),fs=require('fs'),path=require('path');
const {JSDOM}=require('jsdom');
const root=process.env.JOMA_STAGING_DIR;
if(!root) throw Error('Set JOMA_STAGING_DIR to the sanitized patched staging directory');
const code=fs.readFileSync(path.join(root,'assets/js/joma-v2.js'),'utf8');
const start=code.indexOf("(function () {\n  var card = document.getElementById('water-card');");
assert(start>=0); const end=code.indexOf('\n})();',start);assert(end>start);
const waterCode=code.slice(start,end+6);
async function scenario(response, action, expected) {
 const html='<div id="water-card" data-pa="1" data-date="1405-01-01" data-value="0" data-target="2"><input name="csrf" value="fake"><button data-fill="1"><span class="glass-water"></span></button><form data-water-finalize><button>final</button></form><span data-water-label></span><span data-water-badge></span></div>';
 const dom=new JSDOM(html,{url:'https://example.test/index.php?p=today',runScripts:'outside-only'}),w=dom.window;
 let events=[];w.document.addEventListener('joma:owl-state',e=>events.push(e.detail.state));
 w.fetch=()=>response instanceof Error ? Promise.reject(response) : Promise.resolve({ok:true,json:()=>Promise.resolve(response)});
 w.eval(waterCode);
 if(action==='draft') w.document.querySelector('[data-fill]').click(); else w.document.querySelector('form').dispatchEvent(new w.Event('submit',{cancelable:true}));
 await new Promise(r=>setTimeout(r,20));
 assert.deepStrictEqual(events,expected);
 if(expected[1]==='error') {assert(w.document.querySelector('[data-water-error]').textContent); assert.strictEqual(w.document.querySelector('#water-card').getAttribute('data-value'),'0');}
 if(action==='finalize' && expected[1]==='happy') assert(w.document.querySelector('form button').disabled);
 dom.window.close();
}
(async()=>{
 const good={ok:true,state:{value:1,is_draft:true,is_final:false,done_count:1,total_count:1}};
 const invalid={ok:false,message:'invalid',state:{value:0,is_draft:false,is_final:false,done_count:0,total_count:1}};
 await scenario(good,'draft',['processing','encouraging']);
 await scenario(invalid,'draft',['processing','error']);
 await scenario(new Error('network'),'draft',['processing','error']);
 await scenario(good,'finalize',['processing','happy']);
 console.log('Water AJAX events passed (jsdom/mock fetch)');
})().catch(e=>{console.error(e);process.exitCode=1});
