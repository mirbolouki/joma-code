<?php
/** Opt-in UI adapter for the isolated test (2) version. No user data is emitted. */
function joma_owl_presence($state) {
    $allowed = array('idle','greeting','encouraging','happy','error','answering');
    if (!in_array($state, $allowed, true)) $state = 'idle';
    $base = joma_url('assets/owl/');
    echo '<link rel="stylesheet" href="' . e($base . 'component/joma-owl.css') . '">';
    echo '<link rel="stylesheet" href="' . e($base . 'component/joma-owl-presence.css') . '">';
    echo '<aside class="joma-owl-presence" data-joma-owl-state="' . e($state) . '">';
    echo '<button type="button" data-owl-toggle aria-expanded="false">نمایش همراه جوما</button>';
    echo '<div data-owl-stage hidden></div></aside>';
    echo '<script defer src="' . e($base . 'component/joma-owl-eyes.js') . '"></script>';
    echo '<script defer src="' . e($base . 'component/joma-owl.js') . '"></script>';
    echo '<script defer src="' . e($base . 'component/joma-owl-presence.js') . '"></script>';
}
