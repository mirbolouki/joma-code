#!/usr/bin/env python3
"""Create a new, non-sensitive test (2).zip staging tree without touching source."""
import pathlib, subprocess, sys, zipfile

if len(sys.argv) != 3:
    raise SystemExit('Usage: python3 build-staging.py /path/to/test.zip /new/staging-dir')
archive = pathlib.Path(sys.argv[1]).resolve()
root = pathlib.Path(sys.argv[2]).resolve()
if root.exists():
    raise SystemExit('Refusing to modify an existing directory')
root.mkdir(parents=True)
allowed = {'.php', '.css', '.js', '.json', '.svg', '.png', '.jpg', '.jpeg', '.webp', '.woff', '.woff2', '.ttf'}
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        path = pathlib.PurePosixPath(info.filename)
        if not path.parts or path.parts[0] != 'test' or '..' in path.parts or info.is_dir():
            continue
        relative = pathlib.PurePosixPath(*path.parts[1:])
        if not relative.parts or relative.parts[0] in ('config', 'data', 'tests', 'FRONTEND-PREVIEW') or relative.suffix.lower() not in allowed:
            continue
        if relative.parts[0] == 'database' and str(relative) != 'database/library_official.json':
            continue
        target = root.joinpath(*relative.parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(z.read(info))
(root / 'config').mkdir(exist_ok=True)
(root / 'config/config.php').write_text("<?php\n$JOMA_CONFIG = array('storage'=>'file','base_url'=>'/');\n", encoding='utf-8')
(root / 'data/sessions').mkdir(parents=True, exist_ok=True)
subprocess.run([str(pathlib.Path(__file__).with_name('install.sh')), str(root)], check=True)
print('Staging created with synthetic file-storage configuration; no original config or user data copied.')
