#!/bin/sh
# Apply to an isolated exact match of test (2).zip; never an unidentified live site.
set -eu
if [ "$#" -ne 1 ]; then echo "Usage: $0 /path/to/extracted/test" >&2; exit 2; fi
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
root=$(CDPATH= cd -- "$here/../.." && pwd)
target=$(CDPATH= cd -- "$1" && pwd)
[ -f "$target/index.php" ] && [ -d "$target/pages" ] && [ -d "$target/includes" ] || { echo 'Not the expected Joma tree' >&2; exit 1; }
[ ! -e "$target/assets/owl" ] && [ ! -e "$target/includes/joma_owl_presence.php" ] || { echo 'Owl files already exist; refusing to overwrite' >&2; exit 1; }
python3 - "$here/expected-pages.json" "$target" <<'PY'
import hashlib, json, pathlib, sys
expected=json.loads(pathlib.Path(sys.argv[1]).read_text())
root=pathlib.Path(sys.argv[2])
for name, wanted in expected.items():
    page=root/'pages'/(name+'.php')
    if not page.is_file() or hashlib.sha256(page.read_bytes()).hexdigest()!=wanted:
        raise SystemExit('Page differs from test (2).zip; refusing to patch: '+name)
    if (root/'pages'/(name+'.php.joma-owl-backup')).exists():
        raise SystemExit('Backup exists; refusing to overwrite: '+name)
PY
water="$target/assets/js/joma-v2.js"
[ -f "$water" ] && [ ! -e "$water.joma-owl-backup" ] || { echo 'Water client missing or backup exists' >&2; exit 1; }
[ "$(sha256sum "$water" | cut -d' ' -f1)" = "$(cat "$here/expected-water.sha256")" ] || { echo 'Water client differs from expected version' >&2; exit 1; }
for name in home login dashboard today reports; do (cd "$target" && patch --dry-run -p1 < "$here/$name.patch"); done
(cd "$target" && patch --dry-run -p1 < "$here/water.patch")
mkdir -p "$target/assets/owl/component" "$target/assets/owl/master" "$target/assets/owl/runtime"
cp "$here"/overlay/assets/owl/component/joma-owl*.js "$here"/overlay/assets/owl/component/joma-owl*.css "$target/assets/owl/component/"
cp "$root/assets/owl/master/master-character-transparent.png" "$target/assets/owl/master/"
cp "$root"/assets/owl/runtime/*.png "$target/assets/owl/runtime/"
cp "$here/overlay/includes/joma_owl_presence.php" "$target/includes/"
for name in home login dashboard today reports; do
  cp "$target/pages/$name.php" "$target/pages/$name.php.joma-owl-backup"
  (cd "$target" && patch -p1 < "$here/$name.patch")
done
cp "$water" "$water.joma-owl-backup"
(cd "$target" && patch -p1 < "$here/water.patch")
echo 'Installed Joma owl into matching isolated tree; validate before release.'
