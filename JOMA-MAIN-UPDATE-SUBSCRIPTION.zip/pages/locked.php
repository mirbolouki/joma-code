<?php
/**
 * JOMA — صفحهٔ «پایان دورهٔ آزمایشی» (اشتراک)
 * کاربر قفل‌شده فقط همین صفحه + خروج را می‌بیند. ورود آزاد است؛ استفاده نه.
 */
$u = current_user();
if (!$u) joma_redirect('index.php?p=login');
if (function_exists('joma_sub_state')) {
    $lk_st = joma_sub_state((int) $u['id']);
    // اگر به هر دلیلی دیگر قفل نبود (مثلاً مدیر همین الان اشتراک داد)، برگرد به برنامه
    if ($u['role_key'] === 'admin' || !isset($lk_st['status']) || $lk_st['status'] !== 'locked') {
        joma_redirect('index.php?p=dashboard');
    }
}
joma_header('تهیهٔ اشتراک', array(), array('public' => 1));
?>
<div class="card auth-card" style="max-width:560px;text-align:center">
  <span class="logo-tile" style="margin:0 auto;width:56px;height:56px;border-radius:18px"><?php echo joma_v2_icon('owl-hi', 'ic lg'); ?></span>
  <h1 style="margin-top:12px">دورهٔ رایگان شما تمام شده است</h1>
  <p class="lede" style="margin-top:8px">
    سلام <?php echo e($u['first_name']); ?> عزیز 👋<br>
    هفت روزِ آزمایشیِ جوما به پایان رسید. حساب و همهٔ ثبت‌هایت سر جایشان هستند و
    هیچ چیزی پاک نمی‌شود — فقط برای ادامهٔ استفاده، لازم است اشتراک تهیه کنی.
  </p>

  <div style="background:var(--bg-soft,#f6f1ea);border-radius:16px;padding:16px;margin:16px 0;text-align:right">
    <b>برای تهیهٔ اشتراک:</b>
    <p class="tiny" style="margin:8px 0 4px">با پشتیبانی جوما تماس بگیر تا اشتراک حساب فعال شود:</p>
    <div style="margin:6px 0"><span class="tiny">پیامک:</span> <b dir="ltr">09967979471</b></div>
    <div style="margin:6px 0"><span class="tiny">پیام‌رسان بله:</span> <b dir="ltr">09967979471</b></div>
    <p class="tiny" style="margin:8px 0 0">نام کاربری‌ات را هم بگو: <b dir="ltr">@<?php echo e($u['username']); ?></b></p>
  </div>

  <div class="btn-row" style="justify-content:center;margin-top:8px">
    <a class="btn" href="<?php echo e(joma_url('index.php?p=locked')); ?>"><?php echo joma_v2_icon('i-checkc'); ?>اتصال را بررسی کن</a>
    <a class="btn sec" href="<?php echo e(joma_url('index.php?p=logout')); ?>"><?php echo joma_v2_icon('i-lock'); ?>خروج</a>
  </div>
  <p class="tiny" style="margin-top:12px">به‌محض فعال‌شدن اشتراک، با همین حساب وارد شو و همه‌چیز مثل قبل در دسترس است.</p>
</div>
<?php joma_footer(); ?>
