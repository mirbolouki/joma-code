<?php
/**
 * JOMA — مدیریت دورهٔ آزمایشی و اشتراک‌ها (فقط مدیر · ADMIN_ACCESS)
 * افزودنی: کاربران قدیمی بدون فیلد «دائمی» هستند؛ ثبت‌نام جدید دورهٔ آزمایشی می‌گیرد.
 */
require_perm('ADMIN_ACCESS');
$u = current_user();
$msg = '';
$err = '';

/* ---------- عملیات‌ها (POST با چک ضدجعل) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $uid = isset($_POST['uid']) ? (int) $_POST['uid'] : 0;
    $act = isset($_POST['act']) ? (string) $_POST['act'] : '';
    if (!$uid) {
        $err = 'کاربر مشخص نیست.';
    } else {
        switch ($act) {
            case 'grant30':   joma_sub_grant_days($uid, 30);   $msg = 'اشتراک ۳۰ روزه فعال شد.'; break;
            case 'grant90':   joma_sub_grant_days($uid, 90);   $msg = 'اشتراک ۹۰ روزه فعال شد.'; break;
            case 'grant365':  joma_sub_grant_days($uid, 365);  $msg = 'اشتراک یک‌ساله فعال شد.'; break;
            case 'grantforever': joma_sub_grant_unlimited($uid); $msg = 'اشتراک دائمی فعال شد.'; break;
            case 'lock':      joma_sub_lock_now($uid);         $msg = 'حساب همین حالا قفل شد.'; break;
            case 'resettrial': joma_sub_reset_trial($uid);     $msg = 'دورهٔ آزمایشی از نو شروع شد (۷ روز).'; break;
            default: $err = 'عملیات ناشناخته است.';
        }
    }
}

/* ---------- فهرست کاربران (هر دو حالت ذخیره‌سازی) ---------- */
$users = array();
if (store_mode() === 'mysql') {
    // اگر مهاجرت ستون‌ها هنوز اجرا نشده باشد، کوئری اول خالی برمی‌گرداند
    // و به کوئری بدون ستون‌های جدید برمی‌گردیم (کاربران «دائمی» دیده می‌شوند).
    $raw = joma_query('SELECT id, first_name, last_name, username, role_key, created_at, trial_until, subscription_until FROM joma_users ORDER BY id', '', array());
    if (!is_array($raw) || !$raw) {
        $raw = joma_query('SELECT id, first_name, last_name, username, role_key, created_at FROM joma_users ORDER BY id', '', array());
    }
    $users = is_array($raw) ? $raw : array();
} else {
    $data = store_load();
    foreach ($data['users'] as $row) $users[] = $row;
}

/* ---------- محاسبهٔ وضعیت هر کاربر ---------- */
$counts = array('unlimited' => 0, 'subscription' => 0, 'trial' => 0, 'locked' => 0);
$rowsOut = array();
foreach ($users as $row) {
    $st = joma_sub_state_of($row);
    $status = $st['status'];
    if (isset($row['role_key']) && $row['role_key'] === 'admin') $status = 'admin';
    $counts[$st['status']] = isset($counts[$st['status']]) ? $counts[$st['status']] + 1 : $counts[$st['status']];
    $rowsOut[] = array('row' => $row, 'st' => $st, 'status' => $status);
}

joma_header('مدیریت اشتراک‌ها', array());
joma_v2_pagehead('مدیریت دورهٔ آزمایشی و اشتراک‌ها', 'اشتراک‌ها', 'وضعیت دورهٔ آزمایشی و اشتراک هر کاربر و فعال‌سازی دستی اشتراک.', '<span>فقط مدیر</span>');
?>
<style>
/* دکمه‌های کوچک فعال‌سازی اشتراک — همان چیپ‌های موجود، فقط قابل کلیک */
button.chip{border:0;cursor:pointer;font-family:inherit;line-height:inherit}
button.chip:hover{filter:brightness(.96)}
button.chip:active{transform:translateY(1px)}
</style>
<?php if ($msg !== '') { ?><div class="ok"><?php echo e($msg); ?></div><?php } ?>
<?php if ($err !== '') { ?><div class="bad"><?php echo e($err); ?></div><?php } ?>

<section class="card">
  <div class="k">خلاصه</div>
  <div class="kpis" style="margin-top:8px">
    <div class="rkpi"><div class="k">دائمی (قدیمی)</div><div class="v"><?php echo fa_num($counts['unlimited']); ?></div><div class="t">هرگز قفل نمی‌شوند</div></div>
    <div class="rkpi"><div class="k">اشتراک فعال</div><div class="v"><?php echo fa_num($counts['subscription']); ?></div><div class="t">تا تاریخ تعیین‌شده</div></div>
    <div class="rkpi"><div class="k">آزمایشی</div><div class="v"><?php echo fa_num($counts['trial']); ?></div><div class="t"><?php echo fa_num(JOMA_TRIAL_DAYS); ?> روز رایگان</div></div>
    <div class="rkpi"><div class="k">قفل</div><div class="v"><?php echo fa_num($counts['locked']); ?></div><div class="t">در انتظار خرید</div></div>
  </div>
  <p class="tiny" style="margin-top:8px">ثبت‌نام برای همه آزاد است؛ هر کاربرِ جدید <?php echo fa_num(JOMA_TRIAL_DAYS); ?> روز آزمایشی دارد و بعد از آن قفل می‌شود تا اشتراکش را فعال کنی. فعال‌سازی اشتراک با کلیک روی دکمه‌های همین صفحه انجام می‌شود (پرداخت آنلاین فعلاً وجود ندارد).</p>
</section>

<section class="card">
  <div class="k">کاربران</div>
  <div class="table-wrap" style="margin-top:8px">
    <table class="tbl">
      <thead><tr><th>#</th><th>نام</th><th>نام کاربری</th><th>وضعیت</th><th>جزئیات</th><th>فعال‌سازی / عملیات</th></tr></thead>
      <tbody>
      <?php foreach ($rowsOut as $it) { $row = $it['row']; $st = $it['st']; ?>
        <tr>
          <td><?php echo fa_num((int) $row['id']); ?></td>
          <td><?php echo e(trim($row['first_name'] . ' ' . $row['last_name'])); ?></td>
          <td dir="ltr">@<?php echo e($row['username']); ?></td>
          <td>
            <?php
            $chip = 's';
            if ($it['status'] === 'admin') $chip = 'g';
            elseif ($st['status'] === 'unlimited') $chip = 'g';
            elseif ($st['status'] === 'subscription') $chip = 'go';
            elseif ($st['status'] === 'trial') $chip = 's';
            elseif ($st['status'] === 'locked') $chip = 'r';
            ?>
            <span class="chip <?php echo $chip; ?>"><?php echo e($it['status'] === 'admin' ? 'مدیر (آزاد)' : joma_sub_state_label($st['status'])); ?></span>
          </td>
          <td class="tiny">
            <?php if ($st['status'] === 'trial' && $st['trial_left'] !== null) { ?>
              تا <b dir="ltr"><?php echo e($st['trial_until']); ?></b> — <?php echo fa_num($st['trial_left']); ?> روز مانده
            <?php } elseif ($st['status'] === 'subscription') { ?>
              <?php if ($st['sub_until'] === JOMA_SUB_FOREVER) { ?>دائمی<?php } else { ?>تا <b dir="ltr"><?php echo e($st['sub_until']); ?></b><?php } ?>
            <?php } elseif ($st['status'] === 'locked') { ?>
              دوره تمام شده — در انتظار فعال‌سازی
            <?php } else { ?>بدون محدودیت<?php } ?>
          </td>
          <td>
            <?php if ((int) $row['id'] !== (int) $u['id']) { ?>
            <form method="post" style="display:inline">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="uid" value="<?php echo (int) $row['id']; ?>">
              <button class="chip g" name="act" value="grant30" title="۳۰ روز">۳۰روز</button>
              <button class="chip g" name="act" value="grant90" title="۹۰ روز">۹۰روز</button>
              <button class="chip g" name="act" value="grant365" title="یک سال">۱سال</button>
              <button class="chip g" name="act" value="grantforever" title="بدون انقضا">دائمی</button>
              <?php if ($st['status'] === 'locked') { ?><button class="chip s" name="act" value="resettrial" title="شروع دوبارهٔ دورهٔ آزمایشی">آزمایشی دوباره</button><?php } ?>
              <?php if ($it['status'] !== 'admin') { ?><button class="chip r" name="act" value="lock" title="قفل فوری" onclick="return confirm('این حساب همین حالا قفل شود؟');">قفل</button><?php } ?>
            </form>
            <?php } else { ?><span class="tiny">خودت هستی 🙂</span><?php } ?>
          </td>
        </tr>
      <?php } ?>
      </tbody>
    </table>
  </div>
  <p class="tiny" style="margin-top:6px">با فعال‌کردن اشتراک، قفل همان لحظه برداشته می‌شود و کاربر با اولین ورود به برنامه برمی‌گردد.</p>
</section>
<?php joma_footer(); ?>
