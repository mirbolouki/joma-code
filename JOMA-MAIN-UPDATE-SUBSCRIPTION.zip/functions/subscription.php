<?php
/* ============================================================
 * JOMA — ماژول «اشتراک و دورهٔ آزمایشی» (افزودنی؛ بدون تغییر رفتار قبلی)
 * ------------------------------------------------------------
 * قانون کار (با تصمیم مالک):
 *   · ثبت‌نام برای همه آزاد است.
 *   · هر کاربرِ جدید ۷ روز (JOMA_TRIAL_DAYS) دورهٔ آزمایشی رایگان دارد.
 *   · کاربرهای قدیمی (که این دو فیلد را ندارند) «نامحدود» فرض می‌شوند
 *     (بزرگ‌داشت خودکار — هرگز قفل نمی‌شوند).
 *   · بعد از پایان دوره، حساب قفل می‌شود و فقط صفحهٔ «تهیهٔ اشتراک»
 *     قابل دسترسی است تا مدیر اشتراک را فعال کند.
 *   · مدیرها (نقش admin) هرگز قفل نمی‌شوند.
 *
 * ذخیره‌سازی: دو فیلد متنی (تاریخ شمسی) روی کاربر:
 *   trial_until, subscription_until   — در MySQL ستون‌های جدید (مهاجرت
 *   افزودنی) و در حالت فایل، کلیدهای آرایهٔ کاربر.
 * ============================================================ */

if (!defined('JOMA_TRIAL_DAYS')) define('JOMA_TRIAL_DAYS', 7);
if (!defined('JOMA_SUB_FOREVER')) define('JOMA_SUB_FOREVER', '2999-12-29');

/* جمع کردن تعداد روز به تاریخ شمسی (بدون نیاز به توابع موفقیت) */
function joma_sub_add_days($jdate, $days) {
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', (string) $jdate, $m)) return $jdate;
    $jy = (int) $m[1]; $jm = (int) $m[2]; $jd = (int) $m[3];
    $days = (int) $days;
    while ($days > 0) {
        $ml = function_exists('jalali_month_length') ? jalali_month_length($jy, $jm) : ($jm <= 6 ? 31 : ($jm <= 11 ? 30 : 29));
        $room = $ml - $jd + 1;
        if ($days < $room) { $jd += $days; $days = 0; }
        else { $days -= $room; $jd = 1; $jm++; if ($jm > 12) { $jm = 1; $jy++; } }
    }
    while ($days < 0) {
        $days += $jd; $jd = 0;
        if ($days > 0) { $jd = $days; $days = 0; }
        else { $jm--; if ($jm < 1) { $jm = 12; $jy--; } $jd = 1; }
    }
    if ($jd < 1) {
        $jm--; if ($jm < 1) { $jm = 12; $jy--; }
        $jd = function_exists('jalali_month_length') ? jalali_month_length($jy, $jm) : ($jm <= 6 ? 31 : ($jm <= 11 ? 30 : 29));
    }
    return sprintf('%04d-%02d-%02d', $jy, $jm, $jd);
}

/* خواندن تازه‌ترین ردیف کاربر (برای تصمیم قفل، نه دادهٔ نشست) */
function joma_sub_user_row($user_id) {
    $user_id = (int) $user_id;
    if (function_exists('get_user')) {
        try { return get_user($user_id); } catch (Throwable $e) { return null; }
    }
    return null;
}

function joma_sub_fields($row) {
    $trial = '';
    $sub = '';
    if (is_array($row)) {
        if (isset($row['trial_until']) && $row['trial_until']) $trial = (string) $row['trial_until'];
        if (isset($row['subscription_until']) && $row['subscription_until']) $sub = (string) $row['subscription_until'];
    }
    return array($trial, $sub);
}

/* وضعیت یک کاربر: unlimited | subscription | trial | locked */
function joma_sub_state_of($row) {
    list($trial, $sub) = joma_sub_fields($row);
    $today = function_exists('jalali_today') ? jalali_today() : '';
    if ($sub === '' && $trial === '') {
        return array('status' => 'unlimited', 'trial_left' => null, 'sub_until' => '', 'trial_until' => '');
    }
    if ($sub !== '' && $today !== '' && strcmp($sub, $today) >= 0) {
        return array('status' => 'subscription', 'trial_left' => null, 'sub_until' => $sub, 'trial_until' => $trial);
    }
    if ($trial !== '' && $today !== '' && strcmp($trial, $today) >= 0) {
        // روزهای باقی‌ماندهٔ آزمایشی (تقریب دقیق با تقویم شمسی)
        $left = 0;
        $d = $today;
        while (strcmp($d, $trial) < 0 && $left < 400) { $d = joma_sub_add_days($d, 1); $left++; }
        return array('status' => 'trial', 'trial_left' => $left + 1, 'sub_until' => $sub, 'trial_until' => $trial);
    }
    return array('status' => 'locked', 'trial_left' => 0, 'sub_until' => $sub, 'trial_until' => $trial);
}

function joma_sub_state($user_id) {
    return joma_sub_state_of(joma_sub_user_row($user_id));
}

/* آیا این کاربر (ردیف کامل) الان دسترسی دارد؟ */
function joma_sub_row_active($row) {
    if (!is_array($row)) return false;
    if (isset($row['role_key']) && $row['role_key'] === 'admin') return true; // مدیر هرگز قفل نمی‌شود
    $st = joma_sub_state_of($row);
    return $st['status'] !== 'locked';
}

/* گارد مرکزی — از require_login صدا زده می‌شود */
function joma_sub_enforce() {
    $u = function_exists('current_user') ? current_user() : null;
    if (!$u) return;
    if (isset($u['role_key']) && $u['role_key'] === 'admin') return;
    $p = isset($_GET['p']) ? (string) $_GET['p'] : '';
    if (in_array($p, array('locked', 'logout'), true)) return;
    $row = joma_sub_user_row((int) $u['id']);
    if (!is_array($row)) return; // fail-open اگر خواندن ردیف ممکن نبود
    if (!joma_sub_row_active($row)) {
        joma_redirect('index.php?p=locked');
    }
}

/* نوشتن فیلدهای اشتراک برای یک کاربر (هر دو حالت) */
function joma_sub_write($user_id, $trial_until, $sub_until) {
    $user_id = (int) $user_id;
    if (store_mode() === 'mysql') {
        try {
            joma_exec(
                'UPDATE joma_users SET trial_until=?, subscription_until=? WHERE id=?',
                'ssi',
                array((string) $trial_until, (string) $sub_until, $user_id)
            );
        } catch (Throwable $e) { /* مهاجرت هنوز اجرا نشده — بی‌صدا رد شو */ }
        return;
    }
    $data = store_load();
    if (!is_array($data)) return;
    foreach ($data['users'] as $i => $usr) {
        if ((int) $usr['id'] === $user_id) {
            $data['users'][$i]['trial_until'] = (string) $trial_until;
            $data['users'][$i]['subscription_until'] = (string) $sub_until;
            break;
        }
    }
    store_save($data);
}

/* ثبت‌نام جدید: شروع دورهٔ آزمایشی */
function joma_sub_init_new_user($user_id) {
    $today = function_exists('jalali_today') ? jalali_today() : '';
    if ($today === '') return;
    joma_sub_write($user_id, joma_sub_add_days($today, JOMA_TRIAL_DAYS - 1), '');
}

/*فعال‌سازی اشتراک توسط مدیر: تعداد روز یا نامحدود */
function joma_sub_grant_days($user_id, $days) {
    $today = function_exists('jalali_today') ? jalali_today() : '';
    if ($today === '') return false;
    $until = ((int) $days <= 0) ? JOMA_SUB_FOREVER : joma_sub_add_days($today, (int) $days - 1);
    $row = joma_sub_user_row((int) $user_id);
    list($trial, ) = joma_sub_fields($row);
    joma_sub_write($user_id, $trial, $until);
    return true;
}

function joma_sub_grant_unlimited($user_id) {
    return joma_sub_grant_days($user_id, 0);
}

/* قفل فوری (لغو اشتراک/آزمایشی) */
function joma_sub_lock_now($user_id) {
    joma_sub_write($user_id, '1400-01-01', '1400-01-01');
}

/* شروع دوبارهٔ دورهٔ آزمایشی */
function joma_sub_reset_trial($user_id) {
    joma_sub_write($user_id, '', '');
    joma_sub_init_new_user($user_id);
}

/* برچسب نمایشی وضعیت */
function joma_sub_state_label($st) {
    $labels = array(
        'unlimited' => 'دائمی (قدیمی)',
        'subscription' => 'اشتراک فعال',
        'trial' => 'آزمایشی',
        'locked' => 'قفل',
    );
    return isset($labels[$st]) ? $labels[$st] : $st;
}
