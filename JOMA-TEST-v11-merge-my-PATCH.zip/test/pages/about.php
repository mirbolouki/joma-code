<?php
/**
 * JOMA — درباره جوما (نسخهٔ ادغام)
 * =====================================================================
 * ادغام my → test (با حکم مالک، ۲۰۲۶-۰۹-۱۹):
 *  · محتوا: کل محتوای صفحهٔ سئوی «my» (چیست/چرا/فلسفه/شیوهٔ کار/
 *    روان‌شناسی رفتار/بنیان‌گذار/جغد دانا) — بدون کم‌وکاست.
 *  · قالب: طرح نسخهٔ ۲۰ همین بسته (پوستهٔ خود جوما) — فرانت از تست تبعیت می‌کند.
 *  · سئو: متاهای عمومی (description/robots/Open Graph/canonical) از مسیر
 *    تازهٔ $opts['seo_meta'] در layout.php می‌آید (پیش‌فرضِ بقیهٔ صفحه‌ها خاموش).
 */
$u = current_user();

$_joma_about_seo_desc = 'جوما یا جغد دانا، پلنر هوشمند برای برنامه‌ریزی، ثبت عملکرد، پایبندی به فعالیت‌ها و مشاهده مسیر رشد فردی است؛ طراحی و بنیانگذاری توسط جواد میربلوکی.';
$_joma_about_opts = ($u ? array() : array('public' => 1)) + array(
    'seo_canonical' => 'https://joma.mirbolouki.com/about',
    'seo_meta' => array(
        array('name' => 'description', 'content' => $_joma_about_seo_desc),
        array('name' => 'robots', 'content' => 'index, follow, max-image-preview:large'),
        array('property' => 'og:type', 'content' => 'website'),
        array('property' => 'og:title', 'content' => 'درباره جوما | جغد دانا؛ پلنر هوشمند رشد و عادت‌سازی'),
        array('property' => 'og:description', 'content' => $_joma_about_seo_desc),
        array('property' => 'og:url', 'content' => 'https://joma.mirbolouki.com/about'),
        array('property' => 'og:site_name', 'content' => 'جوما | جغد دانا'),
        array('property' => 'og:image', 'content' => 'https://joma.mirbolouki.com/assets/images/joma-owl-mirbolouki.jpg'),
        array('name' => 'twitter:card', 'content' => 'summary_large_image'),
    ),
);
joma_header('درباره جوما', array(), $_joma_about_opts);
unset($_joma_about_opts, $_joma_about_seo_desc);
?>
<div class="land">
  <section class="hero" style="padding-top:8px">
    <div>
      <span class="kicker">محصول مستقل خودمدیریتی</span>
      <h1>دربارهٔ جوما؛ جغد دانا</h1>
      <p class="lead">یک پلنر هوشمند برای ساختن تغییرات کوچک، ماندگار و واقعی در زندگی.</p>
      <p class="lede" style="margin-top:10px">جوما تلاش می‌کند فاصلهٔ میان «دانستن» و «عمل کردن» را کمتر کند؛ با تبدیل هدف‌ها و تصمیم‌های ذهنی به فعالیت‌هایی که بتوان آن‌ها را مشاهده، ثبت و دنبال کرد.</p>
    </div>
  </section>

  <section class="card">
    <div class="k">جوما چیست؟</div>
    <p class="lede" style="margin-top:6px">جوما یا «جغد دانا» یک پلنر هوشمند برای انتخاب فعالیت‌های مهم زندگی، ثبت عملکرد، ارزیابی میزان پایبندی و مشاهدهٔ مسیر رشد فردی است.</p>
    <p class="lede">در جوما قرار نیست فقط یک فهرست از کارهایی که باید انجام دهید داشته باشید؛ هدف این است که رفتارهای مؤثر زندگی را به فعالیت‌هایی قابل مشاهده، قابل ثبت و قابل پیگیری تبدیل کنید.</p>
    <p class="lede" style="margin-bottom:0">خواب کافی، ورزش، مطالعه، یادگیری، مدیریت زمان، سلامت روان، روابط، رشد فردی و بسیاری از رفتارهای مؤثر می‌توانند بخشی از مسیر شما در جوما باشند.</p>
  </section>

  <section class="card">
    <h2 style="margin:0 0 10px">چرا جوما ساخته شد؟</h2>
    <p class="lede">بسیاری از ما می‌دانیم چه چیزی برایمان خوب است، اما دانستن همیشه به معنای انجام دادن نیست.</p>
    <p class="lede">ممکن است فهرستی طولانی از اهداف داشته باشیم، دفتر برنامه‌ریزی بخریم، اپلیکیشن نصب کنیم و حتی برای خودمان تصمیم‌های جدی بگیریم؛ اما پس از مدتی بسیاری از این برنامه‌ها رها شوند.</p>
    <p class="lede">یکی از دلایل مهم این اتفاق، فاصلهٔ میان «دانستن» و «عمل کردن» است.</p>
    <p class="lede">جوما با هدف پر کردن همین فاصله شکل گرفت؛ این‌که برنامه‌ریزی از یک فهرست آرزوها و وظایف، به یک فرآیند قابل مشاهده برای ساخت رفتارهای جدید تبدیل شود.</p>
    <p class="lede" style="margin-bottom:0">در جوما تلاش شده به‌جای ایجاد فشار برای کامل بودن، توجه کاربر به روند واقعی تغییر معطوف شود؛ یعنی ببینیم امروز چه کرده‌ایم، چقدر به برنامه پایبند بوده‌ایم و در طول زمان چه تغییری ایجاد شده است.</p>
  </section>

  <section class="card">
    <h2 style="margin:0 0 10px">فلسفهٔ جوما</h2>
    <p class="lede">تغییر پایدار معمولاً از قدم‌های کوچک شروع می‌شود. جوما قرار نیست شما را مجبور کند یک‌شبه نسخهٔ جدیدی از خودتان بسازید؛ هدف کمک به ایجاد رفتارهایی است که بتوانید در زندگی واقعی ادامه دهید.</p>
    <div class="grid grid-3" style="margin-top:12px">
      <div class="card">
        <b style="display:block;margin-top:6px">کمتر کمال‌گرا، بیشتر پیوسته</b>
        <p class="lede" style="margin-top:6px;margin-bottom:0">یک روز ضعیف به معنای شکست کامل نیست و یک روز عالی به معنای رسیدن به مقصد. چیزی که اهمیت دارد مشاهدهٔ روند و ادامه دادن مسیر است.</p>
      </div>
      <div class="card">
        <b style="display:block;margin-top:6px">از هدف به رفتار</b>
        <p class="lede" style="margin-top:6px;margin-bottom:0">هدف‌ها مهم‌اند؛ اما هدف به‌تنهایی رفتار نمی‌سازد. جوما هدف‌های بزرگ را به فعالیت‌هایی تبدیل می‌کند که در زندگی روزمره قابل مشاهده و ثبت باشند.</p>
      </div>
      <div class="card">
        <b style="display:block;margin-top:6px">از برنامه روی کاغذ تا تغییر واقعی</b>
        <p class="lede" style="margin-top:6px;margin-bottom:0">برنامه‌ای ارزشمند است که وارد زندگی واقعی شود؛ جوما ارتباط میان برنامه، رفتار و استمرار را دیدنی می‌کند.</p>
      </div>
    </div>
  </section>

  <section class="card">
    <h2 style="margin:0 0 10px">جوما چگونه به شما کمک می‌کند؟</h2>
    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">
      <div class="card"><b>۱) انتخاب فعالیت‌ها</b><p class="lede" style="margin-bottom:0">فعالیت‌های متناسب با اهداف و اولویت‌های خود را انتخاب می‌کنید.</p></div>
      <div class="card"><b>۲) برنامه‌ریزی</b><p class="lede" style="margin-bottom:0">فعالیت‌های انتخاب‌شده را در برنامهٔ خود قرار می‌دهید و مسیر موردنظر را مشخص می‌کنید.</p></div>
      <div class="card"><b>۳) ثبت عملکرد</b><p class="lede" style="margin-bottom:0">میزان انجام فعالیت‌ها را در طول زمان ثبت می‌کنید.</p></div>
      <div class="card"><b>۴) مشاهدهٔ روند</b><p class="lede" style="margin-bottom:0">به‌جای حدس زدن دربارهٔ عملکرد خود، روند واقعی فعالیت‌ها و میزان پایبندی‌تان را می‌بینید.</p></div>
    </div>
  </section>

  <section class="card">
    <h2 style="margin:0 0 10px">جوما و روان‌شناسی رفتار</h2>
    <p class="lede">جوما با الهام از مفاهیم روان‌شناسی نوین، علوم رفتار و اصول شکل‌گیری عادت‌ها طراحی شده است.</p>
    <p class="lede">در طراحی جوما تلاش شده برنامه‌ریزی به ابزاری برای فشار و کمال‌گرایی تبدیل نشود؛ بلکه کاربر رفتار خودش را ببیند، عملکردش را بهتر بشناسد و برای ادامهٔ مسیر تصمیم‌های آگاهانه‌تری بگیرد.</p>
    <p class="lede">به همین دلیل تمرکز جوما فقط بر این نیست که «امروز چند کار انجام شد؟»؛ بلکه بر ایجاد یک نگاه بلندمدت به رفتار و استمرار نیز تأکید دارد.</p>
    <p class="tiny" style="margin-top:8px;margin-bottom:0">جوما ابزار خودمدیریتی است، نه درمان. اگر حال تو بد است یا فکر آسیب به خودت داری، همین حالا با اورژانس اجتماعی ۱۲۳ یا یک متخصص تماس بگیر.</p>
  </section>

  <section class="card">
    <h2 style="margin:0 0 10px">طراح و بنیان‌گذار</h2>
    <div class="btn-row" style="align-items:flex-start">
      <div style="flex:1;min-width:240px">
        <b style="font-size:14px">جواد میربلوکی</b>
        <p class="tiny" style="margin:2px 0 8px">روان‌شناس، روان‌درمانگر و متخصص زوج‌درمانی و سکس‌تراپی</p>
        <p class="lede">جوما توسط جواد میربلوکی طراحی شده است؛ ایده‌ای که حاصل پیوند میان دانش روان‌شناسی، تجربهٔ عملی و توجه به اصول برنامه‌ریزی رفتاری است. توسعه و اجرای جوما توسط ماهرخ چناقچی.</p>
        <p class="lede" style="margin-bottom:0">هدف از طراحی جوما این است که مفاهیم مرتبط با رشد فردی، تغییر رفتار و شکل‌گیری عادت‌ها بتوانند در قالب یک ابزار کاربردی وارد زندگی روزمره شوند. جوما تلاش می‌کند هویتی مستقل برای ایده‌ای ایجاد کند که در نقطهٔ اتصال روان‌شناسی، رشد فردی، برنامه‌ریزی و شکل‌گیری عادت‌ها قرار دارد.</p>
      </div>
    </div>
  </section>

  <section class="card">
    <h2 style="margin:0 0 10px">چرا «جغد دانا»؟</h2>
    <p class="lede">جغد در فرهنگ‌های مختلف با مفاهیمی مانند دانایی، مشاهده‌گری و نگاه عمیق پیوند خورده است.</p>
    <p class="lede" style="margin-bottom:0">«جغد دانا» در هویت جوما نمادی از این نگاه است: قبل از این‌که برای تغییر عجله کنیم، خودمان را ببینیم؛ رفتارمان را مشاهده کنیم؛ الگوها را بشناسیم؛ و سپس آگاهانه انتخاب کنیم.</p>
  </section>

  <section class="hero" style="text-align:center">
    <span class="kicker">JOMA | جوما | جغد دانا</span>
    <h2 style="margin:8px 0 6px">تغییر از جایی شروع می‌شود که خودمان را ببینیم.</h2>
    <p class="lede">جوما آمده است تا این مسیر را ساده‌تر، قابل مشاهده‌تر و آگاهانه‌تر طی کنیم.</p>
    <?php if ($u) { ?>
      <a class="btn" href="<?php echo e(joma_url('index.php?p=dashboard')); ?>">داشبورد من</a>
    <?php } else { ?>
      <a class="btn" href="<?php echo e(joma_url('index.php?p=register')); ?>">ساخت حساب رایگان</a>
    <?php } ?>
  </section>
</div>
<?php joma_footer(); ?>
