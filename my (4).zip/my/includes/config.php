<?php
/* فایل تنظیمات جوما — ساخته‌شده توسط نصب‌کننده در 2026-10-04 12:58:39 UTC */

define('DB_HOST', 'localhost');
define('DB_NAME', 'mirbolouki_clinic');
define('DB_USER', 'mirbolouki_clinicusr');
define('DB_PASS', 'c96._Fr)n4ko9@%C');

define('APP_BASE_URL', 'https://my.mirbolouki.com');

/* پیامک */
define('SMS_ENABLED', true);
define('SMS_PROVIDER', 'smsir');
define('SMSIR_API_KEY', 'firke0Yu4vCRnfPEi2h9B748jRsMtmH5yqW8iuVeeuP2BV8N');
define('SMSIR_OTP_TEMPLATE_ID', '748444');
define('SMSIR_LINE', '');

/* کد یک‌بارمصرف */
define('OTP_CODE_LENGTH', 6);
define('OTP_TTL_SECONDS', 120);
define('OTP_MAX_ATTEMPTS', 5);
define('OTP_RESEND_COOLDOWN', 90);

/* نشست و زمان */
define('SESSION_IDLE_TIMEOUT', 1800);
define('APP_TIMEZONE', 'Asia/Tehran');

/*تشخیص IP برای شمارش سقف پیامک*/
define('IP_HASH_KEY', '8e2fd087f9e4d8857adeab3c847c0a427f84dd7942987e6cd4fd984f2ebd10d5');
define('CLINIC_PHONE', '09967979471');