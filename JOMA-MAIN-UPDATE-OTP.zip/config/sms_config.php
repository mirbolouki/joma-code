<?php
/**
 * JOMA — تنظیمات پیامک (کد تأیید موبایل) · درگاه: SMS.ir
 * این پرونده جدا از config/config.php است و هرگز جایگزین آن نمی‌شود.
 *
 * حالت‌ها (کلید mode):
 *   production — ارسال واقعی پیامک با «کلید اصلی»
 *   sandbox    — محیط تست خودِ پیامکی (کلید سندباکس؛ بدون ارسال واقعی و بدون هزینه)
 *   mock       — شبیه‌سازی کامل داخل برنامه (بدون هیچ تماسی با پیامکی؛
 *                کد به‌جای پیامک در صفحه نشان داده می‌شود) — مناسب دمو
 *   off        — خاموش
 */

$JOMA_SMS = array(
    'enabled' => true,

    // حالت فعلی سایت اصلی = ارسال پیامک واقعی
    'mode' => 'production',

    // کلید اصلی پنل (نوع «عملیاتی»)
    'api_key' => 'firke0Yu4vCRnfPEi2h9B748jRsMtmH5yqW8iuVeeuP2BV8N',

    // کلید سندباکس (برای تست رایگان)
    'sandbox_api_key' => 'BIGCvEvF8oeYAm0pgBNzP6RkNBUQZi3I60S3NwdGCdBxXQV2',

    // شناسهٔ قالب تأییدشده + نام پارامتر داخل قالب (#OTP#)
    'template_id' => 180905,
    'parameter_name' => 'OTP',

    // فقط برای حالت نمایشی: کد در صفحه نشان داده شود
    'mock_show_code' => false,
);
