<?php
/**
 * JOMA — بازیابی رمز (B1 — مرحلهٔ ۲)
 * جریان: درخواست کاربر → صدور کد توسط پشتیبانی/مدیر → ورود کد + رمز تازه.
 * کد هرگز خام ذخیره نمی‌شود، ۱۵ دقیقه اعتبار دارد، یک‌بارمصرف است و ۵ تلاش.
 */
if (current_user()) joma_redirect('index.php?p=dashboard');
if (!function_exists('joma_recovery_issue')) {
    $__rf = dirname(__FILE__) . '/../functions/recovery.php';
    if (is_file($__rf)) require_once $__rf;
}

$step = 'ask';
$identifier = '';
$err = '';
$notice = '';
$contact = '09967979471';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $identifier = strtolower(trim(isset($_POST['identifier']) ? $_POST['identifier'] : ''));
    $sms_on = function_exists('joma_sms_enabled') && joma_sms_enabled();

    if ($action === 'ask') {
        if ($identifier === '') {
            $err = 'نام کاربری یا ایمیل را وارد کن.';
        } else {
            $u = function_exists('user_by_username') ? user_by_username($identifier) : null;
            if ($u && function_exists('joma_recovery_request_log')) joma_recovery_request_log((int) $u['id']);
            // (پیامک) اگر موبایل ثبت شده داریم و پیامک فعال است، کد همین حالا پیامک می‌شود
            $sent = false;
            if ($u && $sms_on && !empty($u['phone']) && function_exists('joma_sms_otp_issue_and_send')) {
                $r = joma_sms_otp_issue_and_send($u['phone']);
                if (!empty($r['ok'])) {
                    $step = 'smscode';
                    $notice = 'کد تأیید به شمارهٔ ' . joma_sms_mask_mobile($u['phone']) . ' پیامک شد. کد را همراه با رمز تازه وارد کن.';
                    if (!empty($r['mock'])) {
                        $__c = joma_sms_config();
                        if (!empty($__c['mock_show_code']) && isset($r['code'])) $notice = 'حالت نمایشی (بدون پیامک واقعی) — کد تأیید: ' . $r['code'];
                    }
                    $sent = true;
                } else {
                    // ارسال نشد (مثلاً فاصلهٔ دو ارسال هنوز پر نشده) — دلیل را نشان بده
                    $step = 'code';
                    $notice = $r['error'] . ' اگر کد قبلی را داری، همان را وارد کن؛ وگرنه از پشتیبانی کمک بگیر.';
                }
            }
            if (!$sent) {
                // پاسخ یکسان، حتی اگر حساب وجود نداشته باشد (بدون افشای حساب‌ها)
                $step = 'code';
                $notice = 'درخواست ثبت شد. حالا به پشتیبانی پیام بده تا پس از احراز هویت، کد یک‌بارمصرف برایت صادر شود.';
            }
        }
    } elseif ($action === 'resend') {
        // (پیامک) ارسال دوبارهٔ کد در گام پیامکی
        $u = function_exists('user_by_username') ? user_by_username($identifier) : null;
        if ($u && $sms_on && !empty($u['phone'])) {
            $r = joma_sms_otp_issue_and_send($u['phone']);
            $step = 'smscode';
            $notice = !empty($r['ok'])
                ? 'کد تازه به شمارهٔ ' . joma_sms_mask_mobile($u['phone']) . ' پیامک شد.'
                : $r['error'];
        } else {
            $step = 'code';
            $notice = 'درخواست ثبت شد. حالا به پشتیبانی پیام بده تا پس از احراز هویت، کد یک‌بارمصرف برایت صادر شود.';
        }
    } elseif ($action === 'smsreset') {
        // (پیامک) بازیابی رمز با کد پیامک‌شده
        $otp_code = isset($_POST['otp_code']) ? $_POST['otp_code'] : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $confirm = isset($_POST['confirm']) ? $_POST['confirm'] : '';
        $u = function_exists('user_by_username') ? user_by_username($identifier) : null;
        if (!$u || empty($u['phone']) || !$sms_on) {
            $err = 'بازیابی پیامکی برای این حساب در دسترس نیست؛ از مسیر پشتیبانی اقدام کن.';
            $step = 'code';
        } else {
            $vr = joma_sms_otp_verify($u['phone'], $otp_code);
            if (empty($vr['ok'])) {
                $err = $vr['error'];
                $step = 'smscode';
                $notice = 'کد تأیید به شمارهٔ ' . joma_sms_mask_mobile($u['phone']) . ' پیامک شده بود.';
            } elseif (strlen($password) < 6) {
                $err = 'رمز تازه باید حداقل ۶ نویسه باشد.';
                $step = 'smscode';
                // کد مصرف شده؛ نیاز به ارسال دوباره است
                $notice = 'کد قبلی مصرف شد؛ «ارسال دوبارهٔ کد» را بزن.';
            } elseif ($password !== $confirm) {
                $err = 'رمز تازه و تکرار آن یکسان نیستند.';
                $step = 'smscode';
                $notice = 'کد قبلی مصرف شد؛ «ارسال دوبارهٔ کد» را بزن.';
            } else {
                joma_recovery_store_password((int) $u['id'], $password);
                if (function_exists('joma_auth_epoch_bump')) joma_auth_epoch_bump((int) $u['id']);
                flash_set('ok', 'رمز عوض شد. همهٔ نشست‌های دیگر بسته شدند؛ با رمز تازه وارد شو.');
                joma_redirect('index.php?p=login');
            }
        }
    } elseif ($action === 'reset') {
        $code = isset($_POST['code']) ? $_POST['code'] : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $confirm = isset($_POST['confirm']) ? $_POST['confirm'] : '';
        $u = function_exists('user_by_username') ? user_by_username($identifier) : null;
        if (!$u) {
            $err = 'کد یا نام کاربری درست نیست.';
            $step = 'code';
        } else {
            $res = joma_recovery_complete((int) $u['id'], $code, $password, $confirm);
            if (empty($res['ok'])) {
                $err = $res['error'];
                $step = 'code';
            } else {
                flash_set('ok', 'رمز عوض شد. همهٔ نشست‌های دیگر بسته شدند؛ با رمز تازه وارد شو.');
                joma_redirect('index.php?p=login');
            }
        }
    }
}

joma_header('بازیابی رمز', array(), array('public' => 1));
?>
<div class="card auth-card" style="max-width:520px">
  <div style="text-align:center">
    <span class="logo-tile" style="margin:0 auto;width:48px;height:48px;border-radius:15px"><?php echo joma_v2_icon('i-lock', 'ic lg'); ?></span>
    <h1 style="margin-top:10px">بازیابی رمز عبور</h1>
    <p class="lede">برای امنیت، رمز را خودت عوض نمی‌کنی: پشتیبانی هویت را می‌سنجد و یک کد یک‌بارمصرف می‌دهد.</p>
  </div>

  <div class="mode-tabs">
    <a href="<?php echo e(joma_url('index.php?p=login')); ?>">ورود</a>
    <a href="<?php echo e(joma_url('index.php?p=register')); ?>">ثبت‌نام</a>
    <a class="on" href="<?php echo e(joma_url('index.php?p=forgot')); ?>">بازیابی رمز</a>
  </div>

  <?php if ($step === 'ask') { ?>
    <form method="post" action="<?php echo e(joma_url('index.php?p=forgot')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="ask">
      <label>نام کاربری یا ایمیل</label>
      <input name="identifier" aria-label="نام کاربری یا ایمیل" dir="ltr" autocomplete="username" value="<?php echo e($identifier); ?>" required>
      <?php if ($err) echo '<p class="bad">' . e($err) . '</p>'; ?>
      <p style="margin-top:12px"><button class="btn btn-block" type="submit">درخواست کد بازیابی</button></p>
    </form>
    <div class="joma-reg-gate-contacts">
      <div><span>پیامک:</span> <b dir="ltr"><?php echo e($contact); ?></b> <button type="button" class="btn ghost sm" data-copy="<?php echo e($contact); ?>" style="margin-inline-start:6px">کپی</button></div>
      <div><span>پیام‌رسان بله:</span> <b dir="ltr"><?php echo e($contact); ?></b></div>
    </div>
    <p class="lede" style="margin-top:8px">کد بازیابی فقط با احراز هویت پشتیبانی صادر می‌شود. هیچ پیامک خودکاری فرستاده نمی‌شود و ما هرگز رمز را از تو نمی‌پرسیم.</p>
  <?php } elseif ($step === 'smscode') { ?>
    <?php if ($notice) echo '<p class="ok">' . e($notice) . '</p>'; ?>
    <form method="post" action="<?php echo e(joma_url('index.php?p=forgot')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="smsreset">
      <input type="hidden" name="identifier" value="<?php echo e($identifier); ?>">
      <label>کد تأیید ۵ رقمی پیامک‌شده</label>
      <input name="otp_code" dir="ltr" inputmode="numeric" pattern="[0-9]{5,6}" maxlength="6" autocomplete="one-time-code" required>
      <label>رمز تازه</label>
      <div style="position:relative">
        <input id="new-pass-sms" type="password" name="password" autocomplete="new-password" required>
        <button type="button" class="icon-btn" data-pass-toggle="new-pass-sms" aria-label="نمایش رمز"
          style="position:absolute;inset-inline-start:6px;top:50%;transform:translateY(-50%);box-shadow:none;background:transparent;border:0">
          <?php echo joma_v2_icon('i-eye', 'ic'); ?>
        </button>
      </div>
      <label>تکرار رمز تازه</label>
      <input type="password" name="confirm" autocomplete="new-password" required>
      <?php if ($err) echo '<p class="bad">' . e($err) . '</p>'; ?>
      <p style="margin-top:12px"><button class="btn btn-block" type="submit">تغییر رمز با کد پیامکی</button></p>
    </form>
    <form method="post" action="<?php echo e(joma_url('index.php?p=forgot')); ?>" style="margin-top:8px">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="resend">
      <input type="hidden" name="identifier" value="<?php echo e($identifier); ?>">
      <button class="btn sec btn-block" type="submit">ارسال دوبارهٔ کد</button>
    </form>
    <p class="lede" style="margin-top:8px">اگر پیامک نیامد یا شمارهٔ ثبت‌شده دیگر مال تو نیست، با پشتیبانی تماس بگیر: <b dir="ltr"><?php echo e($contact); ?></b></p>
  <?php } else { ?>
    <?php if ($notice) echo '<p class="ok">' . e($notice) . '</p>'; ?>
    <div class="joma-reg-gate-contacts">
      <div><span>پیامک / بله:</span> <b dir="ltr"><?php echo e($contact); ?></b> <button type="button" class="btn ghost sm" data-copy="<?php echo e($contact); ?>" style="margin-inline-start:6px">کپی</button></div>
    </div>
    <p class="lede" style="margin-top:8px">کد ۱۵ دقیقه اعتبار دارد، فقط یک‌بار قابل استفاده است و حداکثر ۵ تلاش دارد.</p>
    <form method="post" action="<?php echo e(joma_url('index.php?p=forgot')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="reset">
      <input type="hidden" name="identifier" value="<?php echo e($identifier); ?>">
      <label>کد ۶ رقمی</label>
      <input name="code" dir="ltr" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required>
      <label>رمز تازه</label>
      <div style="position:relative">
        <input id="new-pass" type="password" name="password" autocomplete="new-password" required>
        <button type="button" class="icon-btn" data-pass-toggle="new-pass" aria-label="نمایش رمز"
          style="position:absolute;inset-inline-start:6px;top:50%;transform:translateY(-50%);box-shadow:none;background:transparent;border:0">
          <?php echo joma_v2_icon('i-eye', 'ic'); ?>
        </button>
      </div>
      <label>تکرار رمز تازه</label>
      <input type="password" name="confirm" autocomplete="new-password" required>
      <?php if ($err) echo '<p class="bad">' . e($err) . '</p>'; ?>
      <p style="margin-top:12px"><button class="btn btn-block" type="submit">تغییر رمز</button></p>
    </form>
    <p class="lede">پشتیبانی هرگز کد را از تو نمی‌پرسد؛ کد را در هیچ‌جای عمومی نگذار.</p>
  <?php } ?>

  <p style="margin-top:10px"><a class="btn sec btn-block" href="<?php echo e(joma_url('index.php?p=login')); ?>">بازگشت به ورود</a></p>
</div>
<?php joma_footer(); ?>
