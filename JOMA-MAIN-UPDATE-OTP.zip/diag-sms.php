<?php
/**
 * JOMA — تست اتصال پیامک (موقتی)
 * ⚠️ بعد از تست، این فایل را از روی هاست پاک کنید.
 * کاربرد: بررسی اعتبار پنل و ارسال یک پیامک آزمایشی واقعی/سندباکس.
 */
$cfgFile = __DIR__ . '/config/sms_config.php';
$cfg = null;
if (is_file($cfgFile)) { $JOMA_SMS = null; require $cfgFile; $cfg = $JOMA_SMS; }

$mode = isset($_GET['mode']) && $_GET['mode'] === 'sandbox' ? 'sandbox' : 'production';
$phone = isset($_GET['phone']) ? preg_replace('/[^0-9]/', '', $_GET['phone']) : '';
$do = isset($_GET['do']) ? $_GET['do'] : '';
$out = array();

function sms_ir_call($method, $url, $key, $body = null) {
    $ch = curl_init();
    $opts = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => array('Content-Type: application/json', 'Accept: text/plain', 'x-api-key: ' . $key),
    );
    if ($body !== null) { $opts[CURLOPT_POST] = true; $opts[CURLOPT_POSTFIELDS] = $body; }
    curl_setopt_array($ch, $opts);
    $r = curl_exec($ch);
    $err = curl_errno($ch) ? curl_error($ch) : '';
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return array('http' => $code, 'body' => $r === false ? '' : $r, 'err' => $err);
}

if (!$cfg || empty($cfg['enabled'])) {
    $out[] = 'تنظیمات پیامک پیدا نشد یا غیرفعال است (config/sms_config.php).';
} else {
    $key = ($mode === 'sandbox' && !empty($cfg['sandbox_api_key'])) ? $cfg['sandbox_api_key'] : $cfg['api_key'];
    if ($do === 'credit') {
        $r = sms_ir_call('GET', 'https://api.sms.ir/v1/credit', $key);
        $out[] = 'بررسی اعتبار (حالت ' . $mode . ') — HTTP ' . $r['http'];
        $out[] = $r['err'] ? 'خطای اتصال: ' . $r['err'] : $r['body'];
    }
    if ($do === 'send' && strlen($phone) >= 10) {
        $body = json_encode(array(
            'mobile' => $phone,
            'templateId' => (int) $cfg['template_id'],
            'parameters' => array(array('name' => (string) $cfg['parameter_name'], 'value' => '12345')),
        ), JSON_UNESCAPED_UNICODE);
        $r = sms_ir_call('POST', 'https://api.sms.ir/v1/send/verify', $key, $body);
        $out[] = 'ارسال تست (حالت ' . $mode . ') به ' . $phone . ' — HTTP ' . $r['http'];
        $out[] = $r['err'] ? 'خطای اتصال: ' . $r['err'] : $r['body'];
        if ($mode === 'sandbox') $out[] = '(سندباکس پیامکی واقعاً نمی‌فرستد؛ فقط موفقیت اتصال را نشان می‌دهد.)';
        else $out[] = 'اگر وضعیت "موفق" بود، پیامک «کد ارسالی را وارد کنید12345» باید به این شماره برسد.';
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>تست اتصال پیامک جوما</title>
<style>
body{font-family:Tahoma,Segoe UI,sans-serif;max-width:640px;margin:30px auto;padding:0 16px;color:#222}
h1{font-size:19px} pre{background:#f4f0ea;padding:12px;border-radius:10px;direction:ltr;text-align:left;white-space:pre-wrap}
input,button{padding:9px 12px;border-radius:10px;border:1px solid #ccc;font-size:14px}
button{background:#5c4682;color:#fff;border:0;cursor:pointer;margin-inline-start:6px}
.card{background:#fff;border:1px solid #e5ddd2;border-radius:14px;padding:16px;margin-top:14px}
</style></head>
<body>
<h1>🔌 تست اتصال پیامک (SMS.ir) — جوما</h1>
<p style="color:#a33;font-weight:bold">⚠️ بعد از اتمام تست، این فایل (diag-sms.php) را از هاست پاک کنید.</p>
<?php if ($cfg && !empty($cfg['enabled'])) { ?>
<div class="card">
  <b>تنظیمات فعلی:</b> حالت=<b><?php echo htmlspecialchars($cfg['mode']); ?></b>
  · قالب=<b dir="ltr"><?php echo (int) $cfg['template_id']; ?></b>
  · پارامتر=<b dir="ltr"><?php echo htmlspecialchars($cfg['parameter_name']); ?></b>
  · کلید اصلی: <b><?php echo $cfg['api_key'] ? '✅ دارد' : '❌ ندارد'; ?></b>
  · کلید سندباکس: <b><?php echo !empty($cfg['sandbox_api_key']) ? '✅ دارد' : '❌ ندارد'; ?></b>
</div>
<?php } ?>
<div class="card">
  <form method="get">
    <label>حالت: </label>
    <label><input type="radio" name="mode" value="sandbox" <?php echo $mode === 'sandbox' ? 'checked' : ''; ?>> سندباکس (تست، بدون هزینه)</label>
    <label><input type="radio" name="mode" value="production" <?php echo $mode === 'production' ? 'checked' : ''; ?>> واقعی</label>
    <div style="margin-top:10px">
      <button name="do" value="credit">بررسی اعتبار پنل</button>
    </div>
    <div style="margin-top:10px">
      شماره برای پیامک تست: <input name="phone" dir="ltr" placeholder="0912..." value="<?php echo htmlspecialchars($phone); ?>">
      <button name="do" value="send">ارسال پیامک تست</button>
    </div>
    <input type="hidden" name="sent" value="1">
  </form>
</div>
<?php if ($out) { ?>
<div class="card"><b>نتیجه:</b>
<?php foreach ($out as $line) echo '<pre>' . htmlspecialchars($line) . '</pre>'; ?>
</div>
<?php } ?>
</body>
</html>
