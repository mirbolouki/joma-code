<?php
/* ============================================================
 * JOMA — ماژول «پیامک و کد تأیید موبایل» (افزودنی؛ بدون تغییر رفتار قبلی)
 * ------------------------------------------------------------
 * درگاه: سامانهٔ پیامکی SMS.ir — متد «ارسال سریع/VERIFY»
 *   POST https://api.sms.ir/v1/send/verify
 *   هدر: x-api-key · بدنه: {mobile, templateId, parameters:[{name,value}]}
 * تنظیمات از پروندهٔ جداگانهٔ config/sms_config.php خوانده می‌شود
 * (هیچ دست‌کاری‌ای در config/config.php اصلی لازم نیست).
 * اگر آن پرونده نباشد، همهٔ چیز بی‌اثر است و ثبت‌نام مثل قبل می‌ماند.
 *
 * حالت‌ها (در تنظیمات، کلید mode):
 *   production — ارسال واقعی با کلید اصلی
 *   sandbox    — محیط تست پیامکی (بدون ارسال واقعی و بدون هزینه)
 *   mock       — شبیه‌سازی کامل داخل خود برنامه (برای دموی بدون هزینه؛
 *                کد به‌جای پیامک، در صفحه نمایش داده می‌شود)
 *   off        — خاموش (حتی اگر بقیهٔ تنظیمات باشد)
 * ============================================================ */

/* ------------------------- تنظیمات ------------------------- */

function joma_sms_config() {
    static $cfg = null;
    if ($cfg !== null) return $cfg;
    $cfg = array(
        'enabled' => false,
        'mode' => 'off',
        'api_key' => '',
        'sandbox_api_key' => '',
        'template_id' => 0,
        'parameter_name' => 'OTP',
        'mock_show_code' => false,
    );
    $file = dirname(__FILE__) . '/../config/sms_config.php';
    if (is_file($file)) {
        $JOMA_SMS = null;
        require $file;
        if (is_array($JOMA_SMS)) {
            foreach ($cfg as $k => $v) {
                if (array_key_exists($k, $JOMA_SMS)) $cfg[$k] = $JOMA_SMS[$k];
            }
        }
    }
    return $cfg;
}

function joma_sms_enabled() {
    $c = joma_sms_config();
    if (empty($c['enabled'])) return false;
    if (!in_array($c['mode'], array('production', 'sandbox', 'mock'), true)) return false;
    if ($c['mode'] !== 'mock' && trim((string) $c['api_key']) === '' && trim((string) $c['sandbox_api_key']) === '') return false;
    if ($c['mode'] !== 'mock' && (int) $c['template_id'] <= 0) return false;
    return true;
}

/* شمارهٔ موبایل را به قالب استاندارد ۰۹... تبدیل می‌کند */
function joma_sms_normalize_mobile($mobile) {
    $m = preg_replace('/[^0-9]/', '', (string) $mobile);
    if (strlen($m) === 12 && strpos($m, '98') === 0) $m = '0' . substr($m, 2);
    if (strlen($m) === 10 && $m[0] === '9') $m = '0' . $m;
    return $m;
}

/* ------------------------- ارسال ------------------------- */

/**
 * ارسال کد تأیید با قالب تأییدشده.
 * خروجی: array('ok' => bool, 'message' => string, 'mock' => bool, 'code' => string|null)
 * در حالت mock هیچ درخواستی به بیرون نمی‌رود.
 */
function joma_sms_send_verify_code($mobile, $code) {
    $c = joma_sms_config();
    if (!joma_sms_enabled()) {
        return array('ok' => false, 'message' => 'سرویس پیامک فعال نیست.', 'mock' => false, 'code' => null);
    }
    $mobile = joma_sms_normalize_mobile($mobile);
    if ($c['mode'] === 'mock') {
        return array('ok' => true, 'message' => 'حالت نمایشی: پیامکی ارسال نشد.', 'mock' => true, 'code' => (string) $code);
    }
    $key = ($c['mode'] === 'sandbox' && trim((string) $c['sandbox_api_key']) !== '')
        ? $c['sandbox_api_key']
        : $c['api_key'];
    $payload = json_encode(array(
        'mobile' => $mobile,
        'templateId' => (int) $c['template_id'],
        'parameters' => array(
            array('name' => (string) $c['parameter_name'], 'value' => (string) $code),
        ),
    ), JSON_UNESCAPED_UNICODE);

    if (!function_exists('curl_init')) {
        return array('ok' => false, 'message' => 'افزونهٔ cURL روی هاست فعال نیست؛ با پشتیبانی تماس بگیر.', 'mock' => false, 'code' => null);
    }
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => 'https://api.sms.ir/v1/send/verify',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Accept: text/plain',
            'x-api-key: ' . trim((string) $key),
        ),
    ));
    $raw = curl_exec($ch);
    $errno = curl_errno($ch);
    curl_close($ch);
    if ($raw === false || $errno !== 0) {
        return array('ok' => false, 'message' => 'اتصال به درگاه پیامک برقرار نشد. چند لحظه دیگر دوباره تلاش کن.', 'mock' => false, 'code' => null);
    }
    $j = json_decode((string) $raw, true);
    $status = is_array($j) && isset($j['status']) ? (int) $j['status'] : -1;
    if ($status === 1) {
        return array('ok' => true, 'message' => 'موفق', 'mock' => false, 'code' => null);
    }
    $msgs = array(
        0 => 'در سامانهٔ پیامک خطایی رخ داد؛ دوباره تلاش کن.',
        10 => 'کلید وب‌سرویس پیامک نامعتبر است.',
        11 => 'کلید وب‌سرویس پیامک غیرفعال است.',
        12 => 'کلید وب‌سرویس به آی‌پی‌های مشخص محدود شده است.',
        13 => 'حساب پنل پیامک غیرفعال است.',
        14 => 'حساب پنل پیامک در حالت تعلیق است.',
        20 => 'تعداد درخواست‌ها بیش از حد مجاز است؛ چند دقیقه صبر کن.',
        102 => 'اعتبار پنل پیامک کافی نیست.',
        103 => 'متن پیام خالی است.',
        104 => 'شمارهٔ موبایل نادرست است.',
        113 => 'قالب پیامک پیدا نشد.',
        114 => 'مقدار پارامتر قالب بیش از حد مجاز است.',
        115 => 'این شماره پیامک‌های خدماتی را مسدود کرده است.',
        117 => 'متن ارسالی مورد تأیید سامانه نیست.',
        119 => 'برای قالب شخصی‌سازی‌شده باید پلن پنل ارتقا یابد.',
        123 => 'خط ارسال نیاز به فعال‌سازی دارد.',
    );
    $why = isset($msgs[$status]) ? $msgs[$status] : 'خطای ناشناخته در ارسال پیامک (کد ' . $status . ').';
    return array('ok' => false, 'message' => $why, 'mock' => false, 'code' => null);
}

/* ------------------------- چرخهٔ حیات کد تأیید ------------------------- */
/* ذخیره‌سازی در همان انبار کلید/مقدار ماژول بازیابی (MySQL یا فایل).     */

function joma_sms_otp_ttl_minutes() { return 5; }       // اعتبار کد
function joma_sms_otp_max_attempts() { return 5; }      // تلاش اشتباه
function joma_sms_otp_cooldown_minutes() { return 2; }  // فاصلهٔ دو ارسال
function joma_sms_otp_hourly_limit() { return 4; }      // حداکثر ارسال در ساعت

function joma_sms_otp_key($mobile) {
    return 'sms_otp_' . joma_sms_normalize_mobile($mobile);
}

function joma_sms_otp_new_code() {
    return (string) random_int(10000, 99999); // پنج رقم
}

/**
 * ساخت کد، ذخیرهٔ هش و ارسال پیامک.
 * خروجی: array('ok'=>bool, 'error'=>string, 'mock'=>bool, 'code'=>string|null)
 */
function joma_sms_otp_issue_and_send($mobile) {
    if (!function_exists('joma_kv_get_json') || !function_exists('joma_kv_set_json')) {
        return array('ok' => false, 'error' => 'زیرساخت کد تأیید در دسترس نیست.', 'mock' => false, 'code' => null);
    }
    $mobile = joma_sms_normalize_mobile($mobile);
    if (!preg_match('/^09\d{9}$/', $mobile)) {
        return array('ok' => false, 'error' => 'شمارهٔ موبایل معتبر نیست.', 'mock' => false, 'code' => null);
    }
    $now = time();
    $rec = joma_kv_get_json(joma_sms_otp_key($mobile));
    if (is_array($rec)) {
        $cooldown = joma_sms_otp_cooldown_minutes() * 60;
        if (isset($rec['sent_at']) && ($now - (int) $rec['sent_at']) < $cooldown) {
            $left = (int) ceil(($cooldown - ($now - (int) $rec['sent_at'])) / 60);
            return array('ok' => false, 'error' => 'کد قبلی تازه ارسال شده؛ حدود ' . $left . ' دقیقه صبر کن.', 'mock' => false, 'code' => null);
        }
        $sends = isset($rec['sends']) && is_array($rec['sends']) ? $rec['sends'] : array();
        $sends = array_values(array_filter($sends, function ($t) use ($now) { return ($now - (int) $t) < 3600; }));
        if (count($sends) >= joma_sms_otp_hourly_limit()) {
            return array('ok' => false, 'error' => 'برای این شماره درخواست‌های زیادی ثبت شده؛ تا یک ساعت دیگر نمی‌شود.', 'mock' => false, 'code' => null);
        }
    }
    $code = joma_sms_otp_new_code();
    $sent = joma_sms_send_verify_code($mobile, $code);
    if (empty($sent['ok'])) {
        return array('ok' => false, 'error' => $sent['message'], 'mock' => false, 'code' => null);
    }
    $sends = (is_array($rec) && isset($rec['sends']) && is_array($rec['sends'])) ? $rec['sends'] : array();
    $sends = array_values(array_filter($sends, function ($t) use ($now) { return ($now - (int) $t) < 3600; }));
    $sends[] = $now;
    joma_kv_set_json(joma_sms_otp_key($mobile), array(
        'hash' => password_hash($code, PASSWORD_DEFAULT),
        'exp' => $now + joma_sms_otp_ttl_minutes() * 60,
        'attempts' => 0,
        'sent_at' => $now,
        'sends' => $sends,
    ));
    return array('ok' => true, 'error' => '', 'mock' => !empty($sent['mock']), 'code' => isset($sent['code']) ? $sent['code'] : null);
}

/**
 * بررسی کد واردشده. در صورت درست بودن، رکورد حذف می‌شود (یک‌بارمصرف).
 * خروجی: array('ok'=>bool, 'error'=>string)
 */
function joma_sms_otp_verify($mobile, $code) {
    if (!function_exists('joma_kv_get_json')) return array('ok' => false, 'error' => 'زیرساخت کد تأیید در دسترس نیست.');
    $mobile = joma_sms_normalize_mobile($mobile);
    $code = preg_replace('/[^0-9]/', '', (string) $code);
    $rec = joma_kv_get_json(joma_sms_otp_key($mobile));
    if (!is_array($rec) || !isset($rec['hash'])) {
        return array('ok' => false, 'error' => 'کدی برای این شماره ارسال نشده است.');
    }
    if (isset($rec['exp']) && time() > (int) $rec['exp']) {
        joma_kv_forget(joma_sms_otp_key($mobile));
        return array('ok' => false, 'error' => 'مهلت کد تمام شده؛ کد تازه بگیر.');
    }
    if (isset($rec['attempts']) && (int) $rec['attempts'] >= joma_sms_otp_max_attempts()) {
        joma_kv_forget(joma_sms_otp_key($mobile));
        return array('ok' => false, 'error' => 'تلاش‌های مجاز تمام شد؛ کد تازه بگیر.');
    }
    if (!password_verify($code, (string) $rec['hash'])) {
        $rec['attempts'] = isset($rec['attempts']) ? (int) $rec['attempts'] + 1 : 1;
        joma_kv_set_json(joma_sms_otp_key($mobile), $rec);
        $left = joma_sms_otp_max_attempts() - (int) $rec['attempts'];
        return array('ok' => false, 'error' => 'کد درست نیست.' . ($left > 0 ? ' (' . $left . ' تلاش مانده)' : ''));
    }
    // درست است — یک‌بارمصرف: خودِ کد باطل می‌شود ولی سابقهٔ ارسال برای
    // محدودیت ساعتی و فاصلهٔ دو ارسال باقی می‌ماند.
    $rec['hash'] = '';
    $rec['exp'] = 0;
    $rec['attempts'] = 0;
    joma_kv_set_json(joma_sms_otp_key($mobile), $rec);
    return array('ok' => true, 'error' => '');
}

/* برای بازیابی رمز: شمارهٔ کاربر را می‌پوشاند (۰۹۱۲***۴۵۶۷) */
function joma_sms_mask_mobile($mobile) {
    $m = joma_sms_normalize_mobile($mobile);
    if (!preg_match('/^09\d{9}$/', $m)) return '—';
    return substr($m, 0, 4) . '***' . substr($m, 7);
}
