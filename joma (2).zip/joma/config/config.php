<?php
$JOMA_CONFIG = array(
  'db_host' => 'localhost',
  'db_name' => 'mirbolouki_joma',
  'db_user' => 'mirbolouki_jomausr',
  'db_pass' => 'MCQWI*AvOkl4Bt1)',
  'base_url' => '/joma',
  'storage' => 'mysql',
);
