<?php
/**
 * JOMA — نسخهٔ دمو (joma.mirbolouki.com/test)
 * ------------------------------------------------------------------
 * فقط برای نمایش: ذخیره‌سازی با فایل؛ هیچ اتصال به دیتابیس ندارد
 * و هیچ تماسی با سایت اصلی یا دادهٔ واقعی ندارد.
 */

$JOMA_CONFIG = array(
    'db_host' => '',
    'db_name' => '',
    'db_user' => '',
    'db_pass' => '',
    'base_url' => '/test',
    'storage' => 'file',
    'registration_security_code_enabled' => false,
);
